# 📖 Guia de Uso - CRM Montador de Móveis

## Bem-vindo ao CRM Montador de Móveis!

Este é um sistema completo para gerenciar seu negócio de montagem de móveis, desde o primeiro contato até o recebimento do pagamento.

---

## 📋 Índice

1. [Como Começar](#como-começar)
2. [Dashboard](#dashboard)
3. [Atendimentos](#atendimentos)
4. [Clientes](#clientes)
5. [Serviços](#serviços)
6. [Ordens de Serviço](#ordens-de-serviço)
7. [Sincronização Multi-Dispositivos](#sincronização-multi-dispositivos)
8. [Relatórios](#relatórios)
9. [Dicas e Truques](#dicas-e-truques)
10. [Suporte](#suporte)

---

## 🚀 Como Começar

### 1. Fazer Login

Acesse o CRM e faça login com sua conta Manus. Se não tiver uma conta, crie uma em [https://manus.im](https://manus.im).

### 2. Explorar o Dashboard

Após o login, você verá o Dashboard com 4 métricas principais:
- **Total de Clientes** - Número de clientes cadastrados
- **Total de Ordens** - Número de ordens de serviço criadas
- **Em Progresso** - Ordens que estão sendo executadas
- **Receita Total** - Valor total recebido

### 3. Começar a Usar

Use o menu lateral para navegar entre as diferentes seções do CRM.

---

## 📊 Dashboard

O Dashboard é a página inicial do CRM e exibe:

**Métricas Principais:**
- Total de Clientes
- Total de Ordens
- Ordens em Progresso
- Receita Total

**Gráficos:**
- **Status das Ordens** - Quantas ordens estão em cada status (agendada, confirmada, em andamento, concluída, pendente, cancelada)
- **Receita por Forma de Pagamento** - Quanto você recebeu de cada forma de pagamento (Dinheiro, PIX, Cartão, Transferência, Outro)

**Como Usar:**
- Clique em qualquer métrica para ir para a página correspondente
- Passe o mouse sobre os gráficos para ver os valores exatos
- Use os gráficos para entender melhor seu negócio

---

## 📞 Atendimentos

Atendimentos são o primeiro contato com o cliente. Aqui você registra o pedido inicial.

### Criar um Novo Atendimento

1. Clique em **"Atendimentos"** no menu lateral
2. Clique em **"Novo Atendimento"**
3. Preencha os campos:
   - **Nome** - Nome do cliente (obrigatório)
   - **Telefone** - Telefone para contato
   - **WhatsApp** - WhatsApp do cliente
   - **Bairro** - Bairro onde o cliente mora
   - **Cidade** - Cidade
   - **Origem** - Como conheceu seu negócio (indicação, Google, redes sociais, etc)
   - **Tipo de Serviço** - Que tipo de serviço precisa (montagem, desmontagem, reparo, customização, outro)
   - **Descrição** - Descrição detalhada do serviço
   - **Urgência** - Quão urgente é o serviço (baixa, média, alta, crítica)
   - **Data Preferencial** - Quando o cliente prefere que seja feito
   - **Valor Estimado** - Quanto você estima cobrar
   - **Observações** - Anotações adicionais

4. Clique em **"Salvar"**

**O que acontece automaticamente:**
- Um novo cliente é criado com os dados do atendimento
- Uma ordem de serviço é criada automaticamente
- Os dados são sincronizados com seus outros dispositivos

### Editar um Atendimento

1. Clique em **"Atendimentos"** no menu lateral
2. Clique no atendimento que deseja editar
3. Clique em **"Editar"**
4. Faça as alterações desejadas
5. Clique em **"Salvar"**

### Deletar um Atendimento

1. Clique em **"Atendimentos"** no menu lateral
2. Clique no atendimento que deseja deletar
3. Clique em **"Deletar"**
4. Confirme a exclusão

### Filtrar Atendimentos

Use os filtros no topo da página para encontrar atendimentos específicos:
- **Buscar por Nome** - Digite o nome do cliente
- **Buscar por Telefone** - Digite o telefone
- **Filtrar por Status** - Selecione um status (pendente, confirmado, concluído, cancelado, etc)

---

## 👥 Clientes

Clientes são as pessoas que usam seus serviços. Aqui você gerencia informações de contato e histórico.

### Criar um Novo Cliente

1. Clique em **"Clientes"** no menu lateral
2. Clique em **"Novo Cliente"**
3. Preencha os campos:
   - **Nome** - Nome completo (obrigatório)
   - **Email** - Email do cliente
   - **Telefone** - Telefone para contato
   - **WhatsApp** - WhatsApp do cliente
   - **Endereço** - Endereço completo
   - **Bairro** - Bairro
   - **Cidade** - Cidade
   - **Origem** - Como conheceu seu negócio
   - **Indicado Por** - Se foi indicado, por quem

4. Clique em **"Salvar"**

### Ver Histórico do Cliente

Cada cliente tem um card mostrando:
- **Total de Serviços** - Quantos serviços você já fez para este cliente
- **Valor Total Gasto** - Quanto este cliente já gastou com você
- **Data da Última Compra** - Quando foi o último serviço

Essas informações são atualizadas automaticamente conforme você cria novas ordens.

### Editar um Cliente

1. Clique em **"Clientes"** no menu lateral
2. Clique no cliente que deseja editar
3. Clique em **"Editar"**
4. Faça as alterações desejadas
5. Clique em **"Salvar"**

### Deletar um Cliente

1. Clique em **"Clientes"** no menu lateral
2. Clique no cliente que deseja deletar
3. Clique em **"Deletar"**
4. Confirme a exclusão

---

## 🔧 Serviços

Serviços são os tipos de trabalho que você oferece. Aqui você gerencia preços e descrições.

### Usar Serviços Pré-definidos

O CRM vem com 22 serviços pré-definidos com valores de mercado reais:

**Montagem (10 serviços):**
- Montagem de Guarda-Roupa
- Montagem de Cama
- Montagem de Estante
- E mais...

**Desmontagem (3 serviços):**
- Desmontagem de Guarda-Roupa
- Desmontagem de Móvel Planejado
- E mais...

**Reparo (5 serviços):**
- Reparo de Gaveta
- Reparo de Dobradiça
- E mais...

**Customização (4 serviços):**
- Pintura de Móvel
- Envernizamento
- E mais...

**Outro (2 serviços):**
- Serviço Customizado
- Consultoria

### Gerenciar Serviços

1. Clique em **"Gerenciar Serviços"** no menu lateral
2. Você verá duas abas:
   - **Meus Serviços** - Serviços que você criou ou importou
   - **Serviços Pré-definidos** - Todos os 22 serviços disponíveis

### Importar um Serviço Pré-definido

1. Clique em **"Gerenciar Serviços"** no menu lateral
2. Clique na aba **"Serviços Pré-definidos"**
3. Encontre o serviço que deseja importar
4. Clique em **"Adicionar à Minha Lista"**
5. O serviço agora aparece em **"Meus Serviços"**

### Editar um Serviço

1. Clique em **"Gerenciar Serviços"** no menu lateral
2. Clique na aba **"Meus Serviços"**
3. Clique no serviço que deseja editar
4. Clique em **"Editar"**
5. Altere o preço, tempo estimado ou descrição
6. Clique em **"Salvar"**

### Duplicar um Serviço

1. Clique em **"Gerenciar Serviços"** no menu lateral
2. Clique na aba **"Meus Serviços"**
3. Clique no serviço que deseja duplicar
4. Clique em **"Duplicar"**
5. Uma cópia do serviço é criada com "(Cópia)" no nome

### Deletar um Serviço

1. Clique em **"Gerenciar Serviços"** no menu lateral
2. Clique na aba **"Meus Serviços"**
3. Clique no serviço que deseja deletar
4. Clique em **"Deletar"**
5. Confirme a exclusão

### Restaurar Serviços Padrão

Se você deletou todos os seus serviços e quer começar do zero:

1. Clique em **"Gerenciar Serviços"** no menu lateral
2. Clique em **"Restaurar Padrão"**
3. Todos os 22 serviços pré-definidos são importados novamente

---

## 📋 Ordens de Serviço

Ordens de Serviço são o registro completo do trabalho que você vai fazer para um cliente.

### Criar uma Nova Ordem

1. Clique em **"Ordens de Serviço"** no menu lateral
2. Clique em **"Nova Ordem"**
3. Preencha os campos:
   - **Cliente** - Selecione o cliente (obrigatório)
   - **Data de Agendamento** - Quando o serviço será feito
   - **Descrição** - Descrição do trabalho
   - **Serviços** - Selecione os serviços que serão feitos
   - **Forma de Pagamento** - Como o cliente vai pagar (Dinheiro, PIX, Cartão, Transferência, Outro)
   - **Status de Pagamento** - Se já foi pago (Pendente, Pago, Parcial)
   - **Descrição de Pagamento** - Detalhes do pagamento (ex: Parcelado em 3x)

4. Clique em **"Salvar"**

**O valor total é calculado automaticamente** com base nos serviços selecionados.

### Editar uma Ordem

1. Clique em **"Ordens de Serviço"** no menu lateral
2. Clique na ordem que deseja editar
3. Clique em **"Editar"**
4. Faça as alterações desejadas
5. Clique em **"Salvar"**

### Mudar Status de uma Ordem

1. Clique em **"Ordens de Serviço"** no menu lateral
2. Clique na ordem que deseja atualizar
3. Clique em **"Editar"**
4. Mude o status para:
   - **Agendada** - Ordem foi agendada
   - **Confirmada** - Cliente confirmou
   - **Em Andamento** - Você está fazendo o trabalho
   - **Concluída** - Trabalho foi finalizado
   - **Pendente** - Aguardando algo
   - **Cancelada** - Ordem foi cancelada

5. Clique em **"Salvar"**

### Registrar Pagamento

1. Clique em **"Ordens de Serviço"** no menu lateral
2. Clique na ordem que foi paga
3. Clique em **"Editar"**
4. Mude **"Status de Pagamento"** para **"Pago"**
5. Preencha **"Descrição de Pagamento"** se necessário (ex: PIX em 15/04/2026)
6. Clique em **"Salvar"**

### Deletar uma Ordem

1. Clique em **"Ordens de Serviço"** no menu lateral
2. Clique na ordem que deseja deletar
3. Clique em **"Deletar"**
4. Confirme a exclusão

### Exportar Ordem para PDF

1. Clique em **"Ordens de Serviço"** no menu lateral
2. Clique na ordem que deseja exportar
3. Clique em **"Exportar PDF"**
4. O PDF é baixado automaticamente

---

## 🔄 Sincronização Multi-Dispositivos

O CRM permite que você use o mesmo sistema em múltiplos dispositivos (computador, celular, tablet) e mantenha os dados sincronizados.

### Como Funciona

1. **Sincronização Automática** - A cada 5 minutos, o CRM tenta sincronizar seus dados automaticamente
2. **Sincronização Manual** - Você pode clicar em "↑ Enviar" ou "↓ Baixar" para sincronizar manualmente
3. **Resolução de Conflitos** - Se os mesmos dados forem modificados em dois dispositivos, o CRM avisa e você escolhe qual versão manter

### Usar Sincronização Manual

1. Procure pelo ícone de **"Sincronização"** no canto inferior esquerdo (próximo ao status online/offline)
2. Você verá dois botões:
   - **"↑ Enviar"** - Envia seus dados locais para o servidor
   - **"↓ Baixar"** - Baixa dados do servidor para seu dispositivo

3. Clique em um dos botões
4. Aguarde a sincronização terminar
5. Você verá um indicador visual mostrando o progresso

### Ver Histórico de Sincronizações

1. Clique no ícone de **"Sincronização"**
2. Clique em **"Ver Histórico"**
3. Você verá um histórico de todas as sincronizações com:
   - Data e hora
   - Taxa de sucesso
   - Número de itens sincronizados
   - Conflitos resolvidos

### Resolver Conflitos

Se os mesmos dados forem modificados em dois dispositivos:

1. Uma caixa de diálogo aparece mostrando as duas versões
2. Você pode ver as diferenças lado a lado
3. Escolha qual versão manter
4. Clique em **"Usar Esta Versão"**
5. Os dados são sincronizados

### Trabalhar Offline

O CRM funciona completamente offline:

1. Se você perder a conexão com a internet, o CRM continua funcionando
2. Todos os dados que você criar/editar são salvos localmente
3. Quando voltar online, clique em **"↑ Enviar"** para sincronizar os dados
4. O CRM tentará sincronizar automaticamente a cada 5 minutos

---

## 📊 Relatórios

Relatórios ajudam você a entender melhor seu negócio.

### Acessar Relatórios

1. Clique em **"Relatórios"** no menu lateral
2. Você verá vários relatórios disponíveis

### Análise Financeira

Mostra:
- Receita total
- Receita por período
- Receita por forma de pagamento
- Receita por cliente
- Receita por serviço

### Exportar Relatório

1. Clique em **"Relatórios"** no menu lateral
2. Clique em **"Exportar CSV"** ou **"Exportar PDF"**
3. O arquivo é baixado automaticamente

---

## 💡 Dicas e Truques

### 1. Use a Busca Global

Você pode buscar por clientes, ordens, serviços em qualquer página usando a barra de busca.

### 2. Importe Todos os Serviços de Uma Vez

Se quiser usar todos os 22 serviços pré-definidos:
1. Clique em **"Gerenciar Serviços"**
2. Clique em **"Restaurar Padrão"**
3. Todos os serviços são importados

### 3. Crie Categorias Personalizadas

Você pode criar suas próprias categorias de serviços além das pré-definidas para melhor organização.

### 4. Use o Tema Escuro

Se preferir, o CRM detecta automaticamente se seu dispositivo está em modo escuro e muda a aparência.

### 5. Instale como App

O CRM pode ser instalado como um app no seu celular:
1. Abra o CRM no navegador do celular
2. Clique em **"Instalar"** (ou procure pela opção "Adicionar à tela inicial")
3. O CRM agora funciona como um app nativo

### 6. Faça Backup Regular

Recomenda-se fazer backup regular dos seus dados:
1. Clique em **"Sincronização"**
2. Clique em **"↑ Enviar"**
3. Seus dados estão salvos no servidor

---

## 📞 Suporte

Se tiver dúvidas ou problemas:

1. **Verifique este guia** - A maioria das dúvidas está respondida aqui
2. **Verifique o Histórico de Sincronizações** - Se há problemas de sincronização
3. **Teste em Outro Navegador** - Se há problemas de interface
4. **Limpe o Cache** - Se há problemas de carregamento
5. **Contate o Suporte** - Se nada funcionar

---

## 🎓 Próximos Passos

Agora que você conhece o CRM:

1. **Crie alguns clientes de teste** - Para familiarizar-se com o sistema
2. **Importe alguns serviços** - Comece com os pré-definidos
3. **Crie algumas ordens de teste** - Para entender o fluxo completo
4. **Teste a sincronização** - Em outro dispositivo
5. **Explore os relatórios** - Para entender seus dados

---

## 📝 Changelog

**Versão 1.0 (20 de Abril de 2026)**
- ✅ Lançamento inicial
- ✅ Todas as funcionalidades implementadas
- ✅ 22 serviços pré-definidos
- ✅ Sincronização multi-dispositivos
- ✅ Gráficos e relatórios

---

**Bem-vindo ao CRM Montador de Móveis! Boa sorte com seu negócio! 🚀**
