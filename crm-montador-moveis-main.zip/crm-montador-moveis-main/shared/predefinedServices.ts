/**
 * Lista de serviços pré-definidos com valores baseados em mercado
 * Todos os valores são editáveis pelo usuário
 */

export interface PredefinedService {
  id: string;
  nome: string;
  descricao: string;
  precoBase: number; // em R$
  tempoEstimado: number; // em minutos
  categoria: 'montagem' | 'desmontagem' | 'reparo' | 'customizacao' | 'outro';
  exigeDupla: boolean;
  exigeDeslocamentoEspecial: boolean;
}

export const PREDEFINED_SERVICES: PredefinedService[] = [
  // MONTAGEM
  {
    id: 'srv-001',
    nome: 'Montagem de Guarda-roupa 2 Portas',
    descricao: 'Montagem completa de guarda-roupa com 2 portas, incluindo prateleiras e varão',
    precoBase: 150.00,
    tempoEstimado: 120,
    categoria: 'montagem',
    exigeDupla: true,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-002',
    nome: 'Montagem de Guarda-roupa 4 Portas',
    descricao: 'Montagem completa de guarda-roupa com 4 portas, incluindo prateleiras e varão',
    precoBase: 250.00,
    tempoEstimado: 180,
    categoria: 'montagem',
    exigeDupla: true,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-003',
    nome: 'Montagem de Cama Box',
    descricao: 'Montagem de cama box com base e colchão',
    precoBase: 100.00,
    tempoEstimado: 60,
    categoria: 'montagem',
    exigeDupla: true,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-004',
    nome: 'Montagem de Estante/Prateleira',
    descricao: 'Montagem de estante ou prateleira de parede com fixação',
    precoBase: 80.00,
    tempoEstimado: 45,
    categoria: 'montagem',
    exigeDupla: false,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-005',
    nome: 'Montagem de Mesa',
    descricao: 'Montagem de mesa de escritório, jantar ou trabalho',
    precoBase: 90.00,
    tempoEstimado: 60,
    categoria: 'montagem',
    exigeDupla: false,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-006',
    nome: 'Montagem de Cadeira/Poltrona',
    descricao: 'Montagem de cadeira, poltrona ou banqueta',
    precoBase: 50.00,
    tempoEstimado: 30,
    categoria: 'montagem',
    exigeDupla: false,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-007',
    nome: 'Montagem de Rack/Painel',
    descricao: 'Montagem de rack para TV ou painel suspenso',
    precoBase: 120.00,
    tempoEstimado: 90,
    categoria: 'montagem',
    exigeDupla: true,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-008',
    nome: 'Montagem de Cozinha Planejada',
    descricao: 'Montagem completa de cozinha planejada com armários e bancada',
    precoBase: 400.00,
    tempoEstimado: 480,
    categoria: 'montagem',
    exigeDupla: true,
    exigeDeslocamentoEspecial: true,
  },
  {
    id: 'srv-009',
    nome: 'Montagem de Closet',
    descricao: 'Montagem de closet com prateleiras, varões e gavetas',
    precoBase: 300.00,
    tempoEstimado: 240,
    categoria: 'montagem',
    exigeDupla: true,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-010',
    nome: 'Montagem de Beliche',
    descricao: 'Montagem de cama beliche com escada e proteção',
    precoBase: 180.00,
    tempoEstimado: 120,
    categoria: 'montagem',
    exigeDupla: true,
    exigeDeslocamentoEspecial: false,
  },

  // DESMONTAGEM
  {
    id: 'srv-101',
    nome: 'Desmontagem de Guarda-roupa',
    descricao: 'Desmontagem cuidadosa de guarda-roupa para mudança',
    precoBase: 100.00,
    tempoEstimado: 90,
    categoria: 'desmontagem',
    exigeDupla: true,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-102',
    nome: 'Desmontagem de Cozinha Planejada',
    descricao: 'Desmontagem completa de cozinha planejada',
    precoBase: 250.00,
    tempoEstimado: 240,
    categoria: 'desmontagem',
    exigeDupla: true,
    exigeDeslocamentoEspecial: true,
  },
  {
    id: 'srv-103',
    nome: 'Desmontagem de Móvel Genérico',
    descricao: 'Desmontagem de móvel (mesa, estante, etc)',
    precoBase: 60.00,
    tempoEstimado: 45,
    categoria: 'desmontagem',
    exigeDupla: false,
    exigeDeslocamentoEspecial: false,
  },

  // REPARO
  {
    id: 'srv-201',
    nome: 'Reparo de Dobradiça',
    descricao: 'Reparo ou substituição de dobradiça de porta',
    precoBase: 50.00,
    tempoEstimado: 30,
    categoria: 'reparo',
    exigeDupla: false,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-202',
    nome: 'Reparo de Gaveta',
    descricao: 'Reparo de trilho ou estrutura de gaveta',
    precoBase: 60.00,
    tempoEstimado: 45,
    categoria: 'reparo',
    exigeDupla: false,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-203',
    nome: 'Reparo de Prateleira',
    descricao: 'Reparo ou reforço de prateleira',
    precoBase: 70.00,
    tempoEstimado: 60,
    categoria: 'reparo',
    exigeDupla: false,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-204',
    nome: 'Reparo de Estrutura',
    descricao: 'Reparo de estrutura danificada ou reforço',
    precoBase: 100.00,
    tempoEstimado: 90,
    categoria: 'reparo',
    exigeDupla: true,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-205',
    nome: 'Substituição de Puxador',
    descricao: 'Substituição de puxador de porta ou gaveta',
    precoBase: 40.00,
    tempoEstimado: 20,
    categoria: 'reparo',
    exigeDupla: false,
    exigeDeslocamentoEspecial: false,
  },

  // CUSTOMIZAÇÃO
  {
    id: 'srv-301',
    nome: 'Pintura/Envernizamento',
    descricao: 'Pintura ou envernizamento de móvel',
    precoBase: 150.00,
    tempoEstimado: 120,
    categoria: 'customizacao',
    exigeDupla: false,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-302',
    nome: 'Revestimento em Papel de Parede',
    descricao: 'Revestimento de móvel com papel de parede ou adesivo',
    precoBase: 120.00,
    tempoEstimado: 90,
    categoria: 'customizacao',
    exigeDupla: false,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-303',
    nome: 'Instalação de Espelho',
    descricao: 'Instalação de espelho em móvel ou parede',
    precoBase: 80.00,
    tempoEstimado: 60,
    categoria: 'customizacao',
    exigeDupla: false,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-304',
    nome: 'Instalação de Iluminação LED',
    descricao: 'Instalação de fita LED ou iluminação em móvel',
    precoBase: 100.00,
    tempoEstimado: 60,
    categoria: 'customizacao',
    exigeDupla: false,
    exigeDeslocamentoEspecial: false,
  },

  // OUTRO
  {
    id: 'srv-401',
    nome: 'Consultoria de Projeto',
    descricao: 'Consultoria para projeto de móvel planejado',
    precoBase: 200.00,
    tempoEstimado: 120,
    categoria: 'outro',
    exigeDupla: false,
    exigeDeslocamentoEspecial: false,
  },
  {
    id: 'srv-402',
    nome: 'Medição de Espaço',
    descricao: 'Medição e análise de espaço para projeto',
    precoBase: 100.00,
    tempoEstimado: 60,
    categoria: 'outro',
    exigeDupla: false,
    exigeDeslocamentoEspecial: false,
  },
];

export function getPredefinedServiceById(id: string): PredefinedService | undefined {
  return PREDEFINED_SERVICES.find(s => s.id === id);
}

export function getPredefinedServicesByCategory(category: string): PredefinedService[] {
  return PREDEFINED_SERVICES.filter(s => s.categoria === category);
}

export function getServiceCategories(): string[] {
  return Array.from(new Set(PREDEFINED_SERVICES.map(s => s.categoria)));
}
