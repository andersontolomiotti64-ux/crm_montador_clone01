import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useCRM } from '@/contexts/CRMContext';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Users, Database, TrendingUp, AlertCircle, Edit2, Trash2, Shield, User } from 'lucide-react';
import { toast } from 'sonner';

export default function AdminDashboard() {
  const { obterTodosUsuarios, atualizarUsuario, deletarUsuario, alterarRoleUsuario, usuarioLogado } = useAuth();
  const { ordens, clientes, servicos } = useCRM();
  const [editandoUsuario, setEditandoUsuario] = useState<string | null>(null);
  const [dialogAberto, setDialogAberto] = useState(false);
  const [formData, setFormData] = useState({ nome: '', email: '' });

  const usuarios = obterTodosUsuarios();
  const totalUsuarios = usuarios.length;
  const totalAdmins = usuarios.filter(u => u.role === 'admin').length;
  const totalOrdensGlobal = ordens.length;
  const receitaTotal = ordens
    .filter(o => o.status === 'concluida')
    .reduce((sum, o) => sum + o.valor_total, 0);

  const handleEditar = (usuarioId: string) => {
    const usuario = usuarios.find(u => u.id === usuarioId);
    if (usuario) {
      setFormData({ nome: usuario.nome, email: usuario.email });
      setEditandoUsuario(usuarioId);
      setDialogAberto(true);
    }
  };

  const handleSalvar = () => {
    if (!formData.nome.trim() || !formData.email.trim()) {
      toast.error('Preencha todos os campos');
      return;
    }

    if (editandoUsuario) {
      atualizarUsuario(editandoUsuario, {
        nome: formData.nome,
        email: formData.email
      });
      toast.success('Usuário atualizado com sucesso');
      setDialogAberto(false);
      setEditandoUsuario(null);
      setFormData({ nome: '', email: '' });
    }
  };

  const handleDeletar = (usuarioId: string) => {
    if (usuarioId === usuarioLogado?.id) {
      toast.error('Você não pode deletar sua própria conta');
      return;
    }

    if (window.confirm('Tem certeza que deseja deletar este usuário?')) {
      deletarUsuario(usuarioId);
      toast.success('Usuário deletado com sucesso');
    }
  };

  const handleAlterarRole = (usuarioId: string, novoRole: 'admin' | 'user') => {
    if (usuarioId === usuarioLogado?.id) {
      toast.error('Você não pode alterar seu próprio role');
      return;
    }

    alterarRoleUsuario(usuarioId, novoRole);
    toast.success(`Usuário alterado para ${novoRole === 'admin' ? 'Administrador' : 'Usuário'}`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Painel de Administração</h1>
        <p className="text-muted-foreground mt-1">Gerenciar usuários e visualizar métricas do sistema</p>
      </div>

      {/* Cards de Métricas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Total de Usuários</p>
              <p className="text-3xl font-bold text-foreground mt-2">{totalUsuarios}</p>
            </div>
            <Users className="text-primary" size={32} />
          </div>
        </Card>

        <Card className="p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Administradores</p>
              <p className="text-3xl font-bold text-foreground mt-2">{totalAdmins}</p>
            </div>
            <Shield className="text-accent" size={32} />
          </div>
        </Card>

        <Card className="p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Total de Ordens</p>
              <p className="text-3xl font-bold text-foreground mt-2">{totalOrdensGlobal}</p>
            </div>
            <Database className="text-primary" size={32} />
          </div>
        </Card>

        <Card className="p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Receita Total</p>
              <p className="text-3xl font-bold text-foreground mt-2">R$ {receitaTotal.toFixed(2)}</p>
            </div>
            <TrendingUp className="text-green-600" size={32} />
          </div>
        </Card>
      </div>

      {/* Estatísticas Adicionais */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6 border border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">Dados do Sistema</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Total de Clientes</span>
              <span className="font-semibold text-foreground">{clientes.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Total de Serviços</span>
              <span className="font-semibold text-foreground">{servicos.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Ordens Concluídas</span>
              <span className="font-semibold text-foreground">{ordens.filter(o => o.status === 'concluida').length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Ordens Pendentes</span>
              <span className="font-semibold text-foreground">{ordens.filter(o => o.status === 'pendente').length}</span>
            </div>
          </div>
        </Card>

        <Card className="p-6 border border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">Informações de Usuários</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Usuários Normais</span>
              <span className="font-semibold text-foreground">{totalUsuarios - totalAdmins}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Taxa de Admin</span>
              <span className="font-semibold text-foreground">{totalUsuarios > 0 ? ((totalAdmins / totalUsuarios) * 100).toFixed(1) : 0}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Usuário Atual</span>
              <span className="font-semibold text-foreground">{usuarioLogado?.nome}</span>
            </div>
          </div>
        </Card>

        <Card className="p-6 border border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">Ticket Médio</h3>
          <div className="space-y-3">
            <div>
              <p className="text-muted-foreground text-sm mb-1">Valor Médio por Ordem</p>
              <p className="text-2xl font-bold text-foreground">
                R$ {totalOrdensGlobal > 0 ? (receitaTotal / ordens.filter(o => o.status === 'concluida').length || 0).toFixed(2) : '0.00'}
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* Gerenciamento de Usuários */}
      <Card className="p-6 border border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Gerenciar Usuários</h3>
        
        {usuarios.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Nome</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Email</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Role</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Data de Criação</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Ações</th>
                </tr>
              </thead>
              <tbody>
                {usuarios.map((usuario) => (
                  <tr key={usuario.id} className="border-b border-border hover:bg-muted/50 transition-colors">
                    <td className="py-3 px-4 font-medium text-foreground">{usuario.nome}</td>
                    <td className="py-3 px-4 text-muted-foreground">{usuario.email}</td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        {usuario.role === 'admin' ? (
                          <Shield size={16} className="text-accent" />
                        ) : (
                          <User size={16} className="text-muted-foreground" />
                        )}
                        <span className={usuario.role === 'admin' ? 'font-semibold text-accent' : 'text-muted-foreground'}>
                          {usuario.role === 'admin' ? 'Administrador' : 'Usuário'}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-muted-foreground">
                      {new Date(usuario.data_criacao).toLocaleDateString('pt-BR')}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        {usuario.id !== usuarioLogado?.id && (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEditar(usuario.id)}
                            >
                              <Edit2 size={16} />
                            </Button>
                            <Select
                              value={usuario.role}
                              onValueChange={(value: any) => handleAlterarRole(usuario.id, value)}
                            >
                              <SelectTrigger className="w-32">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="user">Usuário</SelectItem>
                                <SelectItem value="admin">Admin</SelectItem>
                              </SelectContent>
                            </Select>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDeletar(usuario.id)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 size={16} />
                            </Button>
                          </>
                        )}
                        {usuario.id === usuarioLogado?.id && (
                          <span className="text-xs text-muted-foreground italic">Você</span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-8">
            <AlertCircle size={32} className="mx-auto text-muted-foreground mb-2" />
            <p className="text-muted-foreground">Nenhum usuário encontrado</p>
          </div>
        )}
      </Card>

      {/* Dialog de Edição */}
      <Dialog open={dialogAberto} onOpenChange={setDialogAberto}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Usuário</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">Nome</label>
              <Input
                value={formData.nome}
                onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                placeholder="Nome do usuário"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">Email</label>
              <Input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="email@example.com"
              />
            </div>
            <div className="flex gap-2 pt-4">
              <Button
                onClick={handleSalvar}
                className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                Salvar
              </Button>
              <Button
                onClick={() => setDialogAberto(false)}
                variant="outline"
                className="flex-1"
              >
                Cancelar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
