import { useCRM, OrdemServico, Atendimento } from '@/contexts/CRMContext';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, Calendar, Clock, MapPin, User } from 'lucide-react';
import { useState } from 'react';

export default function Agenda() {
  const { ordens, atendimentos, clientes } = useCRM();
  const [viewMode, setViewMode] = useState<'dia' | 'semana'>('semana');
  const [dataAtual, setDataAtual] = useState(new Date());

  // Funções auxiliares
  const getWeekStart = (date: Date) => {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day;
    return new Date(d.setDate(diff));
  };

  const getDayName = (date: Date) => {
    return date.toLocaleDateString('pt-BR', { weekday: 'long' });
  };

  const getDateString = (date: Date) => {
    return date.toISOString().split('T')[0];
  };

  const isSameDay = (date1: Date, date2: Date) => {
    return getDateString(date1) === getDateString(date2);
  };

  // Agrupar ordens e atendimentos por data
  const agendasPorData: { [key: string]: (OrdemServico | Atendimento)[] } = {};

  ordens.forEach(ordem => {
    const data = getDateString(new Date(ordem.data_agendamento));
    if (!agendasPorData[data]) agendasPorData[data] = [];
    agendasPorData[data].push(ordem);
  });

  atendimentos.forEach(atendimento => {
    if (atendimento.data_preferencial) {
      const data = getDateString(new Date(atendimento.data_preferencial));
      if (!agendasPorData[data]) agendasPorData[data] = [];
      agendasPorData[data].push(atendimento);
    }
  });

  // Renderizar visualização por dia
  const renderDia = () => {
    const dataStr = getDateString(dataAtual);
    const itens = agendasPorData[dataStr] || [];

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground">
              {dataAtual.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
            </h2>
            <p className="text-sm text-muted-foreground">{itens.length} evento(s) agendado(s)</p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setDataAtual(new Date(dataAtual.getTime() - 86400000))}
            >
              <ChevronLeft size={16} />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setDataAtual(new Date())}
            >
              Hoje
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setDataAtual(new Date(dataAtual.getTime() + 86400000))}
            >
              <ChevronRight size={16} />
            </Button>
          </div>
        </div>

        {itens.length === 0 ? (
          <Card className="p-8 text-center">
            <Calendar size={48} className="mx-auto text-muted-foreground mb-4 opacity-50" />
            <p className="text-muted-foreground">Nenhum evento agendado para este dia</p>
          </Card>
        ) : (
          <div className="space-y-3">
            {itens.map((item, idx) => (
              <Card key={idx} className="p-4 border-l-4 border-l-blue-500">
                {'cliente_id' in item ? (
                  // É uma Ordem de Serviço
                  <div>
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-foreground">Ordem de Serviço #{item.id.slice(0, 6)}</h3>
                        <p className="text-sm text-muted-foreground">
                          {clientes.find(c => c.id === item.cliente_id)?.nome || 'Cliente desconhecido'}
                        </p>
                      </div>
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        item.status === 'confirmada' ? 'bg-green-100 text-green-800' :
                        item.status === 'em_andamento' ? 'bg-blue-100 text-blue-800' :
                        item.status === 'concluida' ? 'bg-emerald-100 text-emerald-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {item.status}
                      </span>
                    </div>
                    <div className="mt-3 space-y-2 text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Clock size={16} />
                        <span>{item.turno ? `Turno: ${item.turno}` : 'Horário não definido'}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <MapPin size={16} />
                        <span>{clientes.find(c => c.id === item.cliente_id)?.cidade || 'Cidade desconhecida'}</span>
                      </div>
                      <div className="text-foreground font-semibold">
                        Valor: R$ {item.valor_total.toFixed(2)}
                      </div>
                    </div>
                  </div>
                ) : (
                  // É um Atendimento
                  <div>
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-foreground">Atendimento - {item.nome_cliente}</h3>
                        <p className="text-sm text-muted-foreground">{item.tipo_servico}</p>
                      </div>
                      <span className="px-2 py-1 rounded text-xs font-medium bg-purple-100 text-purple-800">
                        {item.status}
                      </span>
                    </div>
                    <div className="mt-3 space-y-2 text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Clock size={16} />
                        <span>{item.telefone}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <MapPin size={16} />
                        <span>{item.bairro}, {item.cidade}</span>
                      </div>
                      {item.valor_estimado && (
                        <div className="text-foreground font-semibold">
                          Valor estimado: R$ {item.valor_estimado.toFixed(2)}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </Card>
            ))}
          </div>
        )}
      </div>
    );
  };

  // Renderizar visualização por semana
  const renderSemana = () => {
    const weekStart = getWeekStart(dataAtual);
    const dias = Array.from({ length: 7 }, (_, i) => new Date(weekStart.getTime() + i * 86400000));

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground">
              Semana de {dias[0].toLocaleDateString('pt-BR', { day: 'numeric', month: 'short' })} a {dias[6].toLocaleDateString('pt-BR', { day: 'numeric', month: 'short' })}
            </h2>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setDataAtual(new Date(dataAtual.getTime() - 7 * 86400000))}
            >
              <ChevronLeft size={16} />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setDataAtual(new Date())}
            >
              Hoje
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setDataAtual(new Date(dataAtual.getTime() + 7 * 86400000))}
            >
              <ChevronRight size={16} />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-7 gap-3">
          {dias.map((dia, idx) => {
            const dataStr = getDateString(dia);
            const itens = agendasPorData[dataStr] || [];
            const isHoje = isSameDay(dia, new Date());

            return (
              <Card
                key={idx}
                className={`p-4 ${isHoje ? 'border-2 border-blue-500 bg-blue-50' : ''}`}
              >
                <div className={`font-semibold mb-3 ${isHoje ? 'text-blue-600' : 'text-foreground'}`}>
                  <div>{getDayName(dia).substring(0, 3)}</div>
                  <div className="text-lg">{dia.getDate()}</div>
                </div>

                {itens.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-4">Sem eventos</p>
                ) : (
                  <div className="space-y-2">
                    {itens.map((item, itemIdx) => (
                      <div
                        key={itemIdx}
                        className={`text-xs p-2 rounded ${
                          'cliente_id' in item
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-purple-100 text-purple-800'
                        }`}
                      >
                        <div className="font-semibold truncate">
                          {'cliente_id' in item ? 'OS' : 'Atend.'}
                        </div>
                        <div className="truncate">
                          {'cliente_id' in item
                            ? clientes.find(c => c.id === item.cliente_id)?.nome?.substring(0, 10)
                            : item.nome_cliente.substring(0, 10)}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Agenda</h1>
          <p className="text-muted-foreground">Visualize seus atendimentos e ordens de serviço agendados</p>
        </div>
        <div className="flex gap-2">
          <Button
            variant={viewMode === 'dia' ? 'default' : 'outline'}
            onClick={() => setViewMode('dia')}
          >
            Por Dia
          </Button>
          <Button
            variant={viewMode === 'semana' ? 'default' : 'outline'}
            onClick={() => setViewMode('semana')}
          >
            Por Semana
          </Button>
        </div>
      </div>

      <Card className="p-6">
        {viewMode === 'dia' ? renderDia() : renderSemana()}
      </Card>
    </div>
  );
}
