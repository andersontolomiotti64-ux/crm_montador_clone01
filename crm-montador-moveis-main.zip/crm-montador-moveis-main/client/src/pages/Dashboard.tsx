import { useCRM } from '@/contexts/CRMContext';
import { Card } from '@/components/ui/card';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Users, FileText, DollarSign, TrendingUp } from 'lucide-react';

export default function Dashboard() {
  const { clientes, ordens, servicos } = useCRM();

  // Calcular métricas
  const totalClientes = clientes.length;
  const totalOrdens = ordens.length;
  const ordensEmProgresso = ordens.filter(o => o.status === 'em_andamento').length;
  const ordensConluidas = ordens.filter(o => o.status === 'concluida').length;
  const receitaTotal = ordens
    .filter(o => o.status === 'concluida')
    .reduce((sum, o) => sum + o.valor_total, 0);

  // Dados para gráfico de status
  const statusData = [
    { name: 'Agendada', value: ordens.filter(o => o.status === 'agendada').length },
    { name: 'Confirmada', value: ordens.filter(o => o.status === 'confirmada').length },
    { name: 'Em Andamento', value: ordensEmProgresso },
    { name: 'Concluída', value: ordensConluidas },
    { name: 'Cancelada', value: ordens.filter(o => o.status === 'cancelada').length }
  ];

  // Dados para gráfico de receita por serviço
  const receitaPorServico = servicos.map(servico => {
    const total = ordens
      .filter(o => o.status === 'concluida')
      .reduce((sum, ordem) => {
        const servicoNaOrdem = ordem.servicos.find(s => s.servico_id === servico.id);
        return sum + (servicoNaOrdem ? servicoNaOrdem.quantidade * servicoNaOrdem.preco_unitario : 0);
      }, 0);
    return {
      name: servico.nome,
      receita: total
    };
  }).filter(d => d.receita > 0);

  // Dados para gráfico de formas de pagamento
  const formasPagamento = ['dinheiro', 'pix', 'cartao', 'transferencia', 'outro'];
  const receitaPorFormaPagamento = formasPagamento.map(forma => {
    const total = ordens
      .filter(o => o.status === 'concluida' && o.forma_pagamento === forma)
      .reduce((sum, o) => sum + o.valor_total, 0);
    return {
      name: forma.charAt(0).toUpperCase() + forma.slice(1),
      valor: total
    };
  }).filter(d => d.valor > 0);

  // Últimas ordens
  const ultimasOrdens = ordens.slice(-5).reverse();

  const COLORS = ['#0066CC', '#FF6B35', '#10B981', '#EF4444', '#8B5CF6'];

  return (
    <div className="space-y-6">
      {/* Título */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground mt-1">Visão geral do seu negócio</p>
      </div>

      {/* Cards de Métricas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Total de Clientes</p>
              <p className="text-3xl font-bold text-foreground mt-2">{totalClientes}</p>
            </div>
            <Users className="text-primary" size={32} />
          </div>
        </Card>

        <Card className="p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Total de Ordens</p>
              <p className="text-3xl font-bold text-foreground mt-2">{totalOrdens}</p>
            </div>
            <FileText className="text-primary" size={32} />
          </div>
        </Card>

        <Card className="p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Em Progresso</p>
              <p className="text-3xl font-bold text-accent mt-2">{ordensEmProgresso}</p>
            </div>
            <TrendingUp className="text-accent" size={32} />
          </div>
        </Card>

        <Card className="p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Receita Total</p>
              <p className="text-3xl font-bold text-foreground mt-2">R$ {receitaTotal.toFixed(2)}</p>
            </div>
            <DollarSign className="text-primary" size={32} />
          </div>
        </Card>
      </div>

      {/* Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Gráfico de Status */}
        <Card className="p-6 border border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">Status das Ordens</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {statusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        {/* Gráfico de Receita por Serviço */}
        <Card className="p-6 border border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">Receita por Serviço</h3>
          {receitaPorServico.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={receitaPorServico}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                <YAxis />
                <Tooltip formatter={(value) => `R$ ${typeof value === 'number' ? value.toFixed(2) : value}`} />
                <Bar dataKey="receita" fill="#0066CC" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground">
              Nenhuma receita registrada ainda
            </div>
          )}
        </Card>
      </div>

      {/* Gráfico de Formas de Pagamento */}
      <Card className="p-6 border border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Receita por Forma de Pagamento</h3>
        {receitaPorFormaPagamento.length > 0 ? (
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={receitaPorFormaPagamento}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, valor }) => `${name}: R$ ${valor.toFixed(2)}`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="valor"
              >
                {receitaPorFormaPagamento.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => `R$ ${typeof value === 'number' ? value.toFixed(2) : value}`} />
            </PieChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[300px] flex items-center justify-center text-muted-foreground">
            Nenhuma receita registrada ainda
          </div>
        )}
      </Card>

      {/* Últimas Ordens */}
      <Card className="p-6 border border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Últimas Ordens</h3>
        {ultimasOrdens.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-semibold text-foreground">ID</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Cliente</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Status</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Valor</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Data</th>
                </tr>
              </thead>
              <tbody>
                {ultimasOrdens.map((ordem) => {
                  const cliente = clientes.find(c => c.id === ordem.cliente_id);
                  const statusColors = {
                    agendada: 'bg-blue-100 text-blue-800',
                    confirmada: 'bg-purple-100 text-purple-800',
                    em_andamento: 'bg-orange-100 text-orange-800',
                    concluida: 'bg-green-100 text-green-800',
                    pendente: 'bg-yellow-100 text-yellow-800',
                    cancelada: 'bg-red-100 text-red-800'
                  };
                  return (
                    <tr key={ordem.id} className="border-b border-border hover:bg-muted">
                      <td className="py-3 px-4">{ordem.id.slice(0, 8)}</td>
                      <td className="py-3 px-4">{cliente?.nome || 'Desconhecido'}</td>
                      <td className="py-3 px-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[ordem.status]}`}>
                          {ordem.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-semibold">R$ {ordem.valor_total.toFixed(2)}</td>
                      <td className="py-3 px-4">{new Date(ordem.data_criacao).toLocaleDateString('pt-BR')}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-muted-foreground text-center py-8">Nenhuma ordem registrada ainda</p>
        )}
      </Card>
    </div>
  );
}
