import { useState } from 'react';
import { useCRM, OrdemServico } from '@/contexts/CRMContext';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Edit2, Trash2, Eye, Download } from 'lucide-react';
import { toast } from 'sonner';
import { exportOrdensCSV } from '@/lib/exportCSV';

export default function Ordens() {
  const { ordens, clientes, servicos, adicionarOrdem, atualizarOrdem, deletarOrdem } = useCRM();
  const [open, setOpen] = useState(false);
  const [viewOpen, setViewOpen] = useState(false);
  const [editando, setEditando] = useState<string | null>(null);
  const [visualizando, setVisualizando] = useState<OrdemServico | null>(null);
  const [formData, setFormData] = useState<Omit<OrdemServico, 'id' | 'data_criacao'>>({
    cliente_id: '',
    servicos: [],
    status: 'agendada',
    data_agendamento: new Date().toISOString().split('T')[0],
    observacoes: '',
    valor_total: 0,
    forma_pagamento: 'dinheiro',
    status_pagamento: 'pendente',
    descricao_forma_pagamento: ''
  });
  const [servicoSelecionado, setServicoSelecionado] = useState('');
  const [quantidadeServico, setQuantidadeServico] = useState(1);

  const handleAdicionarServico = () => {
    if (!servicoSelecionado) {
      toast.error('Selecione um serviço');
      return;
    }

    const servico = servicos.find(s => s.id === servicoSelecionado);
    if (!servico) return;

    const servicoJaAdicionado = formData.servicos.find(s => s.servico_id === servicoSelecionado);
    if (servicoJaAdicionado) {
      servicoJaAdicionado.quantidade += quantidadeServico;
    } else {
      formData.servicos.push({
        servico_id: servicoSelecionado,
        quantidade: quantidadeServico,
        preco_unitario: servico.preco
      });
    }

    const novoTotal = formData.servicos.reduce((sum, s) => {
      return sum + (s.quantidade * s.preco_unitario);
    }, 0);

    setFormData({
      ...formData,
      valor_total: novoTotal
    });

    setServicoSelecionado('');
    setQuantidadeServico(1);
  };

  const handleRemoverServico = (servicoId: string) => {
    const novoServicos = formData.servicos.filter(s => s.servico_id !== servicoId);
    const novoTotal = novoServicos.reduce((sum, s) => {
      return sum + (s.quantidade * s.preco_unitario);
    }, 0);

    setFormData({
      ...formData,
      servicos: novoServicos,
      valor_total: novoTotal
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.cliente_id) {
      toast.error('Selecione um cliente');
      return;
    }

    if (formData.servicos.length === 0) {
      toast.error('Adicione pelo menos um serviço');
      return;
    }

    if (editando) {
      atualizarOrdem(editando, formData);
      toast.success('Ordem atualizada com sucesso');
    } else {
      adicionarOrdem(formData);
      toast.success('Ordem criada com sucesso');
    }

    setFormData({
      cliente_id: '',
      servicos: [],
      status: 'agendada',
      data_agendamento: new Date().toISOString().split('T')[0],
      observacoes: '',
      valor_total: 0,
      forma_pagamento: 'dinheiro',
      status_pagamento: 'pendente',
      descricao_forma_pagamento: ''
    });
    setEditando(null);
    setOpen(false);
  };

  const handleEditar = (ordem: OrdemServico) => {
    setFormData({
      cliente_id: ordem.cliente_id,
      servicos: ordem.servicos,
      status: ordem.status,
      data_agendamento: ordem.data_agendamento.split('T')[0],
      observacoes: ordem.observacoes,
      valor_total: ordem.valor_total,
      forma_pagamento: ordem.forma_pagamento || 'dinheiro',
      status_pagamento: ordem.status_pagamento || 'pendente',
      descricao_forma_pagamento: ordem.descricao_forma_pagamento || ''
    });
    setEditando(ordem.id);
    setOpen(true);
  };

  const handleDeletar = (id: string) => {
    if (window.confirm('Tem certeza que deseja deletar esta ordem?')) {
      deletarOrdem(id);
      toast.success('Ordem deletada com sucesso');
    }
  };

  const handleFecharDialog = () => {
    setOpen(false);
    setEditando(null);
    setFormData({
      cliente_id: '',
      servicos: [],
      status: 'agendada',
      data_agendamento: new Date().toISOString().split('T')[0],
      observacoes: '',
      valor_total: 0,
      forma_pagamento: 'dinheiro',
      status_pagamento: 'pendente',
      descricao_forma_pagamento: ''
    });
  };

  const statusColors = {
    agendada: 'bg-blue-100 text-blue-800',
    confirmada: 'bg-purple-100 text-purple-800',
    em_andamento: 'bg-orange-100 text-orange-800',
    concluida: 'bg-green-100 text-green-800',
    pendente: 'bg-yellow-100 text-yellow-800',
    cancelada: 'bg-red-100 text-red-800'
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Ordens de Serviço</h1>
          <p className="text-muted-foreground mt-1">Gerenciar ordens de trabalho</p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => {
              if (ordens.length === 0) {
                toast.error('Nenhuma ordem para exportar');
                return;
              }
              exportOrdensCSV(ordens, clientes, servicos);
              toast.success('Ordens exportadas com sucesso!');
            }}
            variant="outline"
            className="border-primary text-primary hover:bg-primary/10"
          >
            <Download size={18} className="mr-2" />
            Exportar CSV
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Plus size={18} className="mr-2" />
              Nova Ordem
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editando ? 'Editar Ordem' : 'Nova Ordem de Serviço'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground">Cliente *</label>
                <Select value={formData.cliente_id} onValueChange={(value) => setFormData({ ...formData, cliente_id: value })}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Selecione um cliente" />
                  </SelectTrigger>
                  <SelectContent>
                    {clientes.map(cliente => (
                      <SelectItem key={cliente.id} value={cliente.id}>
                        {cliente.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium text-foreground">Data de Agendamento</label>
                <Input
                  type="date"
                  value={formData.data_agendamento}
                  onChange={(e) => setFormData({ ...formData, data_agendamento: e.target.value })}
                  className="mt-1"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground">Status</label>
                <Select value={formData.status} onValueChange={(value: any) => setFormData({ ...formData, status: value })}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="agendada">Agendada</SelectItem>
                    <SelectItem value="confirmada">Confirmada</SelectItem>
                    <SelectItem value="em_andamento">Em Andamento</SelectItem>
                    <SelectItem value="concluida">Concluída</SelectItem>
                    <SelectItem value="pendente">Pendente</SelectItem>
                    <SelectItem value="cancelada">Cancelada</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="border-t border-border pt-4">
                <label className="text-sm font-medium text-foreground block mb-3">Serviços</label>
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <Select value={servicoSelecionado} onValueChange={setServicoSelecionado}>
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="Selecione um serviço" />
                      </SelectTrigger>
                      <SelectContent>
                        {servicos.map(servico => (
                          <SelectItem key={servico.id} value={servico.id}>
                            {servico.nome} - R$ {servico.preco.toFixed(2)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Input
                      type="number"
                      min="1"
                      value={quantidadeServico}
                      onChange={(e) => setQuantidadeServico(parseInt(e.target.value))}
                      className="w-20"
                    />
                    <Button type="button" onClick={handleAdicionarServico} variant="outline">
                      Adicionar
                    </Button>
                  </div>

                  {formData.servicos.length > 0 && (
                    <div className="bg-muted p-3 rounded space-y-2">
                      {formData.servicos.map(s => {
                        const servico = servicos.find(srv => srv.id === s.servico_id);
                        return (
                          <div key={s.servico_id} className="flex items-center justify-between text-sm">
                            <span>{servico?.nome} x{s.quantidade}</span>
                            <div className="flex items-center gap-2">
                              <span className="font-semibold">R$ {(s.quantidade * s.preco_unitario).toFixed(2)}</span>
                              <Button
                                type="button"
                                size="sm"
                                variant="ghost"
                                onClick={() => handleRemoverServico(s.servico_id)}
                                className="text-destructive"
                              >
                                ✕
                              </Button>
                            </div>
                          </div>
                        );
                      })}
                      <div className="border-t border-border pt-2 flex justify-between font-semibold">
                        <span>Total:</span>
                        <span>R$ {formData.valor_total.toFixed(2)}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="border-t border-border pt-4">
                <label className="text-sm font-medium text-foreground block mb-3">Forma de Pagamento</label>
                <div className="space-y-3">
                  <Select value={formData.forma_pagamento || 'dinheiro'} onValueChange={(value: any) => setFormData({ ...formData, forma_pagamento: value })}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dinheiro">Dinheiro</SelectItem>
                      <SelectItem value="pix">PIX</SelectItem>
                      <SelectItem value="cartao">Cartão</SelectItem>
                      <SelectItem value="transferencia">Transferência</SelectItem>
                      <SelectItem value="outro">Outro</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Select value={formData.status_pagamento || 'pendente'} onValueChange={(value: any) => setFormData({ ...formData, status_pagamento: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Status do Pagamento" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pendente">Pendente</SelectItem>
                      <SelectItem value="pago">Pago</SelectItem>
                      <SelectItem value="parcial">Parcial</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Input
                    value={formData.descricao_forma_pagamento || ''}
                    onChange={(e) => setFormData({ ...formData, descricao_forma_pagamento: e.target.value })}
                    placeholder="Descrição adicional (ex: Parcelado em 3x)"
                    className="mt-1"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-foreground">Observações</label>
                <Input
                  value={formData.observacoes}
                  onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                  placeholder="Observações adicionais"
                  className="mt-1"
                />
              </div>

              <div className="flex gap-2 pt-4">
                <Button type="submit" className="bg-primary hover:bg-primary/90 text-primary-foreground flex-1">
                  {editando ? 'Atualizar' : 'Criar Ordem'}
                </Button>
                <Button type="button" variant="outline" onClick={handleFecharDialog} className="flex-1">
                  Cancelar
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
        </div>
      </div>

      {/* Tabela de Ordens */}
      <Card className="border border-border overflow-hidden">
        {ordens.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted">
                  <th className="text-left py-4 px-6 font-semibold text-foreground">ID</th>
                  <th className="text-left py-4 px-6 font-semibold text-foreground">Cliente</th>
                  <th className="text-left py-4 px-6 font-semibold text-foreground">Status</th>
                  <th className="text-left py-4 px-6 font-semibold text-foreground">Data</th>
                  <th className="text-left py-4 px-6 font-semibold text-foreground">Valor</th>
                  <th className="text-left py-4 px-6 font-semibold text-foreground">Pagamento</th>
                  <th className="text-left py-4 px-6 font-semibold text-foreground">Ações</th>
                </tr>
              </thead>
              <tbody>
                {ordens.map((ordem) => {
                  const cliente = clientes.find(c => c.id === ordem.cliente_id);
                  return (
                    <tr key={ordem.id} className="border-b border-border hover:bg-muted/50 transition-colors">
                      <td className="py-4 px-6 font-mono text-xs">{ordem.id.slice(0, 8)}</td>
                      <td className="py-4 px-6">{cliente?.nome || 'Desconhecido'}</td>
                      <td className="py-4 px-6">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[ordem.status]}`}>
                          {ordem.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-4 px-6">{new Date(ordem.data_agendamento).toLocaleDateString('pt-BR')}</td>
                      <td className="py-4 px-6 font-semibold">R$ {ordem.valor_total.toFixed(2)}</td>
                      <td className="py-4 px-6 text-xs">
                        <div className="flex flex-col gap-1">
                          <span className="font-medium">{(ordem.forma_pagamento || 'dinheiro').charAt(0).toUpperCase() + (ordem.forma_pagamento || 'dinheiro').slice(1)}</span>
                          <span className="text-muted-foreground">{ordem.status_pagamento || 'Pendente'}</span>
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <div className="flex gap-2">
                          <Dialog open={viewOpen && visualizando?.id === ordem.id} onOpenChange={setViewOpen}>
                            <DialogTrigger asChild>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => setVisualizando(ordem)}
                              >
                                <Eye size={16} />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Detalhes da Ordem</DialogTitle>
                              </DialogHeader>
                              {visualizando && (
                                <div className="space-y-4">
                                  <div>
                                    <p className="text-sm text-muted-foreground">ID</p>
                                    <p className="font-mono">{visualizando.id}</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-muted-foreground">Cliente</p>
                                    <p>{clientes.find(c => c.id === visualizando.cliente_id)?.nome}</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-muted-foreground">Status</p>
                                    <p className="capitalize">{visualizando.status.replace('_', ' ')}</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-muted-foreground">Data de Agendamento</p>
                                    <p>{new Date(visualizando.data_agendamento).toLocaleDateString('pt-BR')}</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-muted-foreground">Serviços</p>
                                    <div className="space-y-1 mt-2">
                                      {visualizando.servicos.map(s => {
                                        const servico = servicos.find(srv => srv.id === s.servico_id);
                                        return (
                                          <p key={s.servico_id} className="text-sm">
                                            {servico?.nome} x{s.quantidade} - R$ {(s.quantidade * s.preco_unitario).toFixed(2)}
                                          </p>
                                        );
                                      })}
                                    </div>
                                  </div>
                                  <div className="border-t border-border pt-4">
                                    <p className="text-sm text-muted-foreground">Valor Total</p>
                                    <p className="text-xl font-bold">R$ {visualizando.valor_total.toFixed(2)}</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-muted-foreground">Forma de Pagamento</p>
                                    <p className="capitalize">{visualizando.forma_pagamento || 'Dinheiro'}</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-muted-foreground">Status do Pagamento</p>
                                    <p className="capitalize">{visualizando.status_pagamento || 'Pendente'}</p>
                                  </div>
                                  {visualizando.descricao_forma_pagamento && (
                                    <div>
                                      <p className="text-sm text-muted-foreground">Descrição do Pagamento</p>
                                      <p>{visualizando.descricao_forma_pagamento}</p>
                                    </div>
                                  )}
                                  {visualizando.observacoes && (
                                    <div>
                                      <p className="text-sm text-muted-foreground">Observações</p>
                                      <p>{visualizando.observacoes}</p>
                                    </div>
                                  )}
                                </div>
                              )}
                            </DialogContent>
                          </Dialog>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditar(ordem)}
                          >
                            <Edit2 size={16} />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDeletar(ordem.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 size={16} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-12 text-center">
            <p className="text-muted-foreground mb-4">Nenhuma ordem criada ainda</p>
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  <Plus size={18} className="mr-2" />
                  Criar Primeira Ordem
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Nova Ordem de Serviço</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-foreground">Cliente *</label>
                    <Select value={formData.cliente_id} onValueChange={(value) => setFormData({ ...formData, cliente_id: value })}>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Selecione um cliente" />
                      </SelectTrigger>
                      <SelectContent>
                        {clientes.map(cliente => (
                          <SelectItem key={cliente.id} value={cliente.id}>
                            {cliente.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-foreground">Data de Agendamento</label>
                    <Input
                      type="date"
                      value={formData.data_agendamento}
                      onChange={(e) => setFormData({ ...formData, data_agendamento: e.target.value })}
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-foreground">Status</label>
                    <Select value={formData.status} onValueChange={(value: any) => setFormData({ ...formData, status: value })}>
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="agendada">Agendada</SelectItem>
                        <SelectItem value="confirmada">Confirmada</SelectItem>
                        <SelectItem value="em_andamento">Em Andamento</SelectItem>
                        <SelectItem value="concluida">Concluída</SelectItem>
                        <SelectItem value="pendente">Pendente</SelectItem>
                        <SelectItem value="cancelada">Cancelada</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="border-t border-border pt-4">
                    <label className="text-sm font-medium text-foreground block mb-3">Serviços</label>
                    <div className="space-y-3">
                      <div className="flex gap-2">
                        <Select value={servicoSelecionado} onValueChange={setServicoSelecionado}>
                          <SelectTrigger className="flex-1">
                            <SelectValue placeholder="Selecione um serviço" />
                          </SelectTrigger>
                          <SelectContent>
                            {servicos.map(servico => (
                              <SelectItem key={servico.id} value={servico.id}>
                                {servico.nome} - R$ {servico.preco.toFixed(2)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Input
                          type="number"
                          min="1"
                          value={quantidadeServico}
                          onChange={(e) => setQuantidadeServico(parseInt(e.target.value))}
                          className="w-20"
                        />
                        <Button type="button" onClick={handleAdicionarServico} variant="outline">
                          Adicionar
                        </Button>
                      </div>

                      {formData.servicos.length > 0 && (
                        <div className="bg-muted p-3 rounded space-y-2">
                          {formData.servicos.map(s => {
                            const servico = servicos.find(srv => srv.id === s.servico_id);
                            return (
                              <div key={s.servico_id} className="flex items-center justify-between text-sm">
                                <span>{servico?.nome} x{s.quantidade}</span>
                                <div className="flex items-center gap-2">
                                  <span className="font-semibold">R$ {(s.quantidade * s.preco_unitario).toFixed(2)}</span>
                                  <Button
                                    type="button"
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => handleRemoverServico(s.servico_id)}
                                    className="text-destructive"
                                  >
                                    ✕
                                  </Button>
                                </div>
                              </div>
                            );
                          })}
                          <div className="border-t border-border pt-2 flex justify-between font-semibold">
                            <span>Total:</span>
                            <span>R$ {formData.valor_total.toFixed(2)}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="border-t border-border pt-4">
                    <label className="text-sm font-medium text-foreground block mb-3">Forma de Pagamento</label>
                    <div className="space-y-3">
                      <Select value={formData.forma_pagamento || 'dinheiro'} onValueChange={(value: any) => setFormData({ ...formData, forma_pagamento: value })}>
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="dinheiro">Dinheiro</SelectItem>
                          <SelectItem value="pix">PIX</SelectItem>
                          <SelectItem value="cartao">Cartão</SelectItem>
                          <SelectItem value="transferencia">Transferência</SelectItem>
                          <SelectItem value="outro">Outro</SelectItem>
                        </SelectContent>
                      </Select>
                      
                      <Select value={formData.status_pagamento || 'pendente'} onValueChange={(value: any) => setFormData({ ...formData, status_pagamento: value })}>
                        <SelectTrigger>
                          <SelectValue placeholder="Status do Pagamento" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pendente">Pendente</SelectItem>
                          <SelectItem value="pago">Pago</SelectItem>
                          <SelectItem value="parcial">Parcial</SelectItem>
                        </SelectContent>
                      </Select>
                      
                      <Input
                        value={formData.descricao_forma_pagamento || ''}
                        onChange={(e) => setFormData({ ...formData, descricao_forma_pagamento: e.target.value })}
                        placeholder="Descrição adicional (ex: Parcelado em 3x)"
                        className="mt-1"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-foreground">Observações</label>
                    <Input
                      value={formData.observacoes}
                      onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                      placeholder="Observações adicionais"
                      className="mt-1"
                    />
                  </div>

                  <div className="flex gap-2 pt-4">
                    <Button type="submit" className="bg-primary hover:bg-primary/90 text-primary-foreground flex-1">
                      Criar Ordem
                    </Button>
                    <Button type="button" variant="outline" onClick={handleFecharDialog} className="flex-1">
                      Cancelar
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        )}
      </Card>
    </div>
  );
}
