import { useState } from 'react';
import { useCRM, Cliente } from '@/contexts/CRMContext';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Edit2, Trash2, Phone, Mail, MapPin, Download, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';
import { exportClientesCSV } from '@/lib/exportCSV';

export default function Clientes() {
  const { clientes, ordens, adicionarCliente, atualizarCliente, deletarCliente, obterMetricasCliente } = useCRM();
  const [open, setOpen] = useState(false);
  const [editando, setEditando] = useState<string | null>(null);
  const [formData, setFormData] = useState<Omit<Cliente, 'id' | 'dataCadastro'>>({
    nome: '',
    telefone: '',
    email: '',
    endereco: '',
    cidade: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.nome.trim()) {
      toast.error('Nome do cliente é obrigatório');
      return;
    }

    if (editando) {
      atualizarCliente(editando, formData);
      toast.success('Cliente atualizado com sucesso');
    } else {
      adicionarCliente(formData);
      toast.success('Cliente adicionado com sucesso');
    }

    setFormData({
      nome: '',
      telefone: '',
      email: '',
      endereco: '',
      cidade: ''
    });
    setEditando(null);
    setOpen(false);
  };

  const handleEditar = (cliente: Cliente) => {
    setFormData({
      nome: cliente.nome,
      telefone: cliente.telefone,
      email: cliente.email,
      endereco: cliente.endereco,
      cidade: cliente.cidade
    });
    setEditando(cliente.id);
    setOpen(true);
  };

  const handleDeletar = (id: string) => {
    if (window.confirm('Tem certeza que deseja deletar este cliente?')) {
      deletarCliente(id);
      toast.success('Cliente deletado com sucesso');
    }
  };

  const handleFecharDialog = () => {
    setOpen(false);
    setEditando(null);
    setFormData({
      nome: '',
      telefone: '',
      email: '',
      endereco: '',
      cidade: ''
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Clientes</h1>
          <p className="text-muted-foreground mt-1">Gerenciar clientes da sua empresa</p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => {
              if (clientes.length === 0) {
                toast.error('Nenhum cliente para exportar');
                return;
              }
              exportClientesCSV(clientes);
              toast.success('Clientes exportados com sucesso!');
            }}
            variant="outline"
            className="border-primary text-primary hover:bg-primary/10"
          >
            <Download size={18} className="mr-2" />
            Exportar CSV
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Plus size={18} className="mr-2" />
              Novo Cliente
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editando ? 'Editar Cliente' : 'Novo Cliente'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground">Nome *</label>
                <Input
                  value={formData.nome}
                  onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                  placeholder="Nome completo"
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">Telefone</label>
                <Input
                  value={formData.telefone}
                  onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
                  placeholder="(11) 99999-9999"
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">Email</label>
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="email@example.com"
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">Endereço</label>
                <Input
                  value={formData.endereco}
                  onChange={(e) => setFormData({ ...formData, endereco: e.target.value })}
                  placeholder="Rua, número"
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">Cidade</label>
                <Input
                  value={formData.cidade}
                  onChange={(e) => setFormData({ ...formData, cidade: e.target.value })}
                  placeholder="Cidade"
                  className="mt-1"
                />
              </div>
              <div className="flex gap-2 pt-4">
                <Button type="submit" className="bg-primary hover:bg-primary/90 text-primary-foreground flex-1">
                  {editando ? 'Atualizar' : 'Adicionar'}
                </Button>
                <Button type="button" variant="outline" onClick={handleFecharDialog} className="flex-1">
                  Cancelar
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
        </div>
      </div>

      {/* Lista de Clientes */}
      {clientes.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {clientes.map((cliente) => {
            const metricas = obterMetricasCliente(cliente.id);
            return (
              <Card key={cliente.id} className="p-6 border border-border hover:shadow-md transition-shadow">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-foreground">{cliente.nome}</h3>

                  {cliente.telefone && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Phone size={16} />
                      <span>{cliente.telefone}</span>
                    </div>
                  )}

                  {cliente.email && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Mail size={16} />
                      <span>{cliente.email}</span>
                    </div>
                  )}

                  {cliente.endereco && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MapPin size={16} />
                      <span>{cliente.endereco}, {cliente.cidade}</span>
                    </div>
                  )}

                  {/* Histórico Visual */}
                  <div className="border-t border-border pt-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium text-muted-foreground">Total de Serviços</span>
                      <span className="text-sm font-bold text-foreground">{metricas.total_servicos}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium text-muted-foreground">Valor Total Gasto</span>
                      <span className="text-sm font-bold text-primary">R$ {metricas.valor_total.toFixed(2)}</span>
                    </div>
                    {metricas.ultima_data && (
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-medium text-muted-foreground">Última Compra</span>
                        <span className="text-xs text-muted-foreground">{new Date(metricas.ultima_data).toLocaleDateString('pt-BR')}</span>
                      </div>
                    )}
                  </div>

                  <div className="pt-2 flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEditar(cliente)}
                      className="flex-1"
                    >
                      <Edit2 size={16} className="mr-1" />
                      Editar
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDeletar(cliente.id)}
                      className="flex-1 text-destructive hover:text-destructive"
                    >
                      <Trash2 size={16} className="mr-1" />
                      Deletar
                    </Button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card className="p-12 border border-border text-center">
          <p className="text-muted-foreground mb-4">Nenhum cliente cadastrado ainda</p>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <Plus size={18} className="mr-2" />
                Adicionar Primeiro Cliente
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Novo Cliente</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-foreground">Nome *</label>
                  <Input
                    value={formData.nome}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    placeholder="Nome completo"
                    className="mt-1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Telefone</label>
                  <Input
                    value={formData.telefone}
                    onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
                    placeholder="(11) 99999-9999"
                    className="mt-1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Email</label>
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="email@example.com"
                    className="mt-1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Endereço</label>
                  <Input
                    value={formData.endereco}
                    onChange={(e) => setFormData({ ...formData, endereco: e.target.value })}
                    placeholder="Rua, número"
                    className="mt-1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Cidade</label>
                  <Input
                    value={formData.cidade}
                    onChange={(e) => setFormData({ ...formData, cidade: e.target.value })}
                    placeholder="Cidade"
                    className="mt-1"
                  />
                </div>
                <div className="flex gap-2 pt-4">
                  <Button type="submit" className="bg-primary hover:bg-primary/90 text-primary-foreground flex-1">
                    Adicionar
                  </Button>
                  <Button type="button" variant="outline" onClick={handleFecharDialog} className="flex-1">
                    Cancelar
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </Card>
      )}
    </div>
  );
}
