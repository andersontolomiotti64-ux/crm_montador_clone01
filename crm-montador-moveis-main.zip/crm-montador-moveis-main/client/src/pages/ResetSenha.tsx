import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Lock, Eye, EyeOff, CheckCircle, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { useLocation } from 'wouter';

export default function ResetSenha() {
  const { resetarSenha, validarTokenReset } = useAuth();
  const [, setLocation] = useLocation();
  const [token, setToken] = useState<string | null>(null);
  const [tokenValido, setTokenValido] = useState(false);
  const [loading, setLoading] = useState(true);
  const [enviando, setEnviando] = useState(false);
  const [resetado, setResetado] = useState(false);
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [mostrarConfirmar, setMostrarConfirmar] = useState(false);
  const [formData, setFormData] = useState({
    novaSenha: '',
    confirmarSenha: ''
  });

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const tokenDaURL = params.get('token');
    setToken(tokenDaURL);

    if (tokenDaURL) {
      const valido = validarTokenReset(tokenDaURL);
      setTokenValido(valido);
    }

    setLoading(false);
  }, [validarTokenReset]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.novaSenha.trim()) {
      toast.error('Digite uma nova senha');
      return;
    }

    if (formData.novaSenha.length < 6) {
      toast.error('Senha deve ter no mínimo 6 caracteres');
      return;
    }

    if (formData.novaSenha !== formData.confirmarSenha) {
      toast.error('As senhas não conferem');
      return;
    }

    if (!token) {
      toast.error('Token inválido');
      return;
    }

    setEnviando(true);

    try {
      const sucesso = resetarSenha(token, formData.novaSenha);

      if (sucesso) {
        setResetado(true);
        toast.success('Senha redefinida com sucesso!');

        // Redirecionar para login após 3 segundos
        setTimeout(() => {
          setLocation('/login');
        }, 3000);
      } else {
        toast.error('Erro ao redefinir senha');
      }
    } catch (erro) {
      toast.error('Erro ao processar solicitação');
    } finally {
      setEnviando(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 border border-border shadow-lg">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Validando link...</p>
          </div>
        </Card>
      </div>
    );
  }

  if (!tokenValido) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 border border-border shadow-lg">
          <div className="text-center space-y-4">
            <div className="flex justify-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center">
                <AlertCircle size={32} className="text-red-600" />
              </div>
            </div>
            <h1 className="text-2xl font-bold text-foreground">Link Inválido ou Expirado</h1>
            <p className="text-muted-foreground">
              O link de recuperação é válido por 24 horas. Se expirou, solicite um novo.
            </p>
            <Button
              onClick={() => setLocation('/recuperar-senha')}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground mt-6"
            >
              Solicitar Novo Link
            </Button>
            <Button
              onClick={() => setLocation('/login')}
              variant="outline"
              className="w-full border-border text-foreground hover:bg-muted"
            >
              Voltar ao Login
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  if (resetado) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 border border-border shadow-lg">
          <div className="text-center space-y-4">
            <div className="flex justify-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle size={32} className="text-green-600" />
              </div>
            </div>
            <h1 className="text-2xl font-bold text-foreground">Senha Redefinida!</h1>
            <p className="text-muted-foreground">
              Sua senha foi alterada com sucesso. Você será redirecionado para o login em breve.
            </p>
            <Button
              onClick={() => setLocation('/login')}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground mt-6"
            >
              Ir para Login
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-8 border border-border shadow-lg">
        <div className="space-y-6">
          {/* Header */}
          <div className="space-y-2">
            <h1 className="text-3xl font-bold text-foreground">Redefinir Senha</h1>
            <p className="text-muted-foreground">
              Digite sua nova senha abaixo
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Nova Senha */}
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Nova Senha
              </label>
              <div className="relative">
                <Lock size={18} className="absolute left-3 top-3 text-muted-foreground" />
                <Input
                  type={mostrarSenha ? 'text' : 'password'}
                  value={formData.novaSenha}
                  onChange={(e) => setFormData({ ...formData, novaSenha: e.target.value })}
                  placeholder="Mínimo 6 caracteres"
                  className="pl-10 pr-10"
                  disabled={enviando}
                />
                <button
                  type="button"
                  onClick={() => setMostrarSenha(!mostrarSenha)}
                  className="absolute right-3 top-3 text-muted-foreground hover:text-foreground"
                >
                  {mostrarSenha ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {/* Confirmar Senha */}
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Confirmar Senha
              </label>
              <div className="relative">
                <Lock size={18} className="absolute left-3 top-3 text-muted-foreground" />
                <Input
                  type={mostrarConfirmar ? 'text' : 'password'}
                  value={formData.confirmarSenha}
                  onChange={(e) => setFormData({ ...formData, confirmarSenha: e.target.value })}
                  placeholder="Confirme sua senha"
                  className="pl-10 pr-10"
                  disabled={enviando}
                />
                <button
                  type="button"
                  onClick={() => setMostrarConfirmar(!mostrarConfirmar)}
                  className="absolute right-3 top-3 text-muted-foreground hover:text-foreground"
                >
                  {mostrarConfirmar ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {/* Requisitos */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-800">
              <p className="font-semibold mb-2">Requisitos da senha:</p>
              <ul className="space-y-1 text-xs">
                <li>✓ Mínimo 6 caracteres</li>
                <li>✓ As senhas devem ser iguais</li>
              </ul>
            </div>

            <Button
              type="submit"
              disabled={enviando}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              {enviando ? 'Processando...' : 'Redefinir Senha'}
            </Button>
          </form>

          {/* Divider */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-muted-foreground">ou</span>
            </div>
          </div>

          {/* Back to Login */}
          <Button
            type="button"
            variant="outline"
            onClick={() => setLocation('/login')}
            className="w-full border-border text-foreground hover:bg-muted"
          >
            Voltar ao Login
          </Button>
        </div>
      </Card>
    </div>
  );
}
