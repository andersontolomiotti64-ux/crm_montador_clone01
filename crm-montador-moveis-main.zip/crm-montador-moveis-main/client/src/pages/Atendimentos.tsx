import { useState } from 'react';
import { useCRM, Atendimento } from '@/contexts/CRMContext';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Edit2, Trash2, Eye, Phone, MessageCircle, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

const ORIGENS = [
  { value: 'whatsapp', label: 'WhatsApp' },
  { value: 'indicacao', label: 'Indicação' },
  { value: 'instagram', label: 'Instagram' },
  { value: 'facebook', label: 'Facebook' },
  { value: 'marketplace', label: 'Marketplace' },
  { value: 'google', label: 'Google' },
  { value: 'loja_parceira', label: 'Loja Parceira' },
  { value: 'grupo_montadores', label: 'Grupo de Montadores' },
  { value: 'cliente_antigo', label: 'Cliente Antigo' },
  { value: 'outro', label: 'Outro' }
];

const STATUS_ATENDIMENTO = [
  { value: 'novo_contato', label: 'Novo Contato', color: 'bg-blue-100 text-blue-800' },
  { value: 'aguardando_info', label: 'Aguardando Informações', color: 'bg-yellow-100 text-yellow-800' },
  { value: 'orcamento_enviado', label: 'Orçamento Enviado', color: 'bg-purple-100 text-purple-800' },
  { value: 'aguardando_confirmacao', label: 'Aguardando Confirmação', color: 'bg-orange-100 text-orange-800' },
  { value: 'agendado', label: 'Agendado', color: 'bg-green-100 text-green-800' },
  { value: 'convertido_os', label: 'Convertido em OS', color: 'bg-emerald-100 text-emerald-800' },
  { value: 'perdido', label: 'Perdido', color: 'bg-red-100 text-red-800' },
  { value: 'cancelado', label: 'Cancelado', color: 'bg-gray-100 text-gray-800' }
];

export default function Atendimentos() {
  const { atendimentos, adicionarAtendimento, atualizarAtendimento, deletarAtendimento, converterAtendimentoEmOrdem } = useCRM();
  const [open, setOpen] = useState(false);
  const [viewOpen, setViewOpen] = useState(false);
  const [editando, setEditando] = useState<string | null>(null);
  const [visualizando, setVisualizando] = useState<Atendimento | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  
  const [formData, setFormData] = useState<Omit<Atendimento, 'id' | 'data_criacao'>>({
    nome_cliente: '',
    telefone: '',
    whatsapp: '',
    bairro: '',
    cidade: '',
    origem: 'whatsapp',
    tipo_servico: '',
    descricao: '',
    urgencia: 'media',
    data_preferencial: '',
    valor_estimado: undefined,
    observacoes: '',
    status: 'novo_contato'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.nome_cliente || !formData.telefone) {
      toast.error('Nome e telefone são obrigatórios');
      return;
    }

    if (editando) {
      atualizarAtendimento(editando, formData);
      toast.success('Atendimento atualizado com sucesso');
    } else {
      adicionarAtendimento(formData);
      toast.success('Atendimento registrado com sucesso');
    }

    setFormData({
      nome_cliente: '',
      telefone: '',
      whatsapp: '',
      bairro: '',
      cidade: '',
      origem: 'whatsapp',
      tipo_servico: '',
      descricao: '',
      urgencia: 'media',
      data_preferencial: '',
      valor_estimado: undefined,
      observacoes: '',
      status: 'novo_contato'
    });
    setEditando(null);
    setOpen(false);
  };

  const handleEditar = (atendimento: Atendimento) => {
    setFormData({
      nome_cliente: atendimento.nome_cliente,
      telefone: atendimento.telefone,
      whatsapp: atendimento.whatsapp,
      bairro: atendimento.bairro,
      cidade: atendimento.cidade,
      origem: atendimento.origem,
      tipo_servico: atendimento.tipo_servico,
      descricao: atendimento.descricao,
      urgencia: atendimento.urgencia,
      data_preferencial: atendimento.data_preferencial,
      valor_estimado: atendimento.valor_estimado,
      observacoes: atendimento.observacoes,
      status: atendimento.status
    });
    setEditando(atendimento.id);
    setOpen(true);
  };

  const handleDeletar = (id: string) => {
    if (window.confirm('Tem certeza que deseja deletar este atendimento?')) {
      deletarAtendimento(id);
      toast.success('Atendimento deletado com sucesso');
    }
  };

  const handleFecharDialog = () => {
    setOpen(false);
    setEditando(null);
    setFormData({
      nome_cliente: '',
      telefone: '',
      whatsapp: '',
      bairro: '',
      cidade: '',
      origem: 'whatsapp',
      tipo_servico: '',
      descricao: '',
      urgencia: 'media',
      data_preferencial: '',
      valor_estimado: undefined,
      observacoes: '',
      status: 'novo_contato'
    });
  };

  // Filtrar atendimentos
  const atendimentosFiltrados = atendimentos.filter(a => {
    const matchSearch = a.nome_cliente.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       a.telefone.includes(searchTerm) ||
                       a.tipo_servico.toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatus = filterStatus === 'all' || a.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const getStatusColor = (status: string) => {
    return STATUS_ATENDIMENTO.find(s => s.value === status)?.color || 'bg-gray-100 text-gray-800';
  };

  const getStatusLabel = (status: string) => {
    return STATUS_ATENDIMENTO.find(s => s.value === status)?.label || status;
  };

  const getOrigemLabel = (origem: string) => {
    return ORIGENS.find(o => o.value === origem)?.label || origem;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Atendimentos</h1>
          <p className="text-muted-foreground mt-1">Gerenciar contatos e orçamentos</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Plus size={18} className="mr-2" />
              Novo Atendimento
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editando ? 'Editar Atendimento' : 'Novo Atendimento'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-foreground">Nome do Cliente *</label>
                  <Input
                    value={formData.nome_cliente}
                    onChange={(e) => setFormData({ ...formData, nome_cliente: e.target.value })}
                    placeholder="Nome completo"
                    className="mt-1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Telefone *</label>
                  <Input
                    value={formData.telefone}
                    onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
                    placeholder="(11) 99999-9999"
                    className="mt-1"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-foreground">WhatsApp</label>
                  <Input
                    value={formData.whatsapp}
                    onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                    placeholder="(11) 99999-9999"
                    className="mt-1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Origem</label>
                  <Select value={formData.origem} onValueChange={(value: any) => setFormData({ ...formData, origem: value })}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {ORIGENS.map(origem => (
                        <SelectItem key={origem.value} value={origem.value}>
                          {origem.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-foreground">Bairro</label>
                  <Input
                    value={formData.bairro}
                    onChange={(e) => setFormData({ ...formData, bairro: e.target.value })}
                    placeholder="Bairro"
                    className="mt-1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Cidade</label>
                  <Input
                    value={formData.cidade}
                    onChange={(e) => setFormData({ ...formData, cidade: e.target.value })}
                    placeholder="Cidade"
                    className="mt-1"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-foreground">Tipo de Serviço</label>
                  <Input
                    value={formData.tipo_servico}
                    onChange={(e) => setFormData({ ...formData, tipo_servico: e.target.value })}
                    placeholder="Ex: Montagem de Guarda-roupa"
                    className="mt-1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Urgência</label>
                  <Select value={formData.urgencia} onValueChange={(value: any) => setFormData({ ...formData, urgencia: value })}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="baixa">Baixa</SelectItem>
                      <SelectItem value="media">Média</SelectItem>
                      <SelectItem value="alta">Alta</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-foreground">Descrição</label>
                <textarea
                  value={formData.descricao}
                  onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                  placeholder="Descreva o serviço solicitado"
                  className="mt-1 w-full p-2 border border-border rounded-md text-sm"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-foreground">Data Preferencial</label>
                  <Input
                    type="date"
                    value={formData.data_preferencial}
                    onChange={(e) => setFormData({ ...formData, data_preferencial: e.target.value })}
                    className="mt-1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Valor Estimado</label>
                  <Input
                    type="number"
                    value={formData.valor_estimado || ''}
                    onChange={(e) => setFormData({ ...formData, valor_estimado: e.target.value ? parseFloat(e.target.value) : undefined })}
                    placeholder="R$ 0,00"
                    className="mt-1"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-foreground">Status</label>
                <Select value={formData.status} onValueChange={(value: any) => setFormData({ ...formData, status: value })}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUS_ATENDIMENTO.map(status => (
                      <SelectItem key={status.value} value={status.value}>
                        {status.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium text-foreground">Observações</label>
                <textarea
                  value={formData.observacoes}
                  onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                  placeholder="Notas adicionais"
                  className="mt-1 w-full p-2 border border-border rounded-md text-sm"
                  rows={2}
                />
              </div>

              <div className="flex gap-2 justify-end pt-4 border-t border-border">
                <Button type="button" variant="outline" onClick={handleFecharDialog}>
                  Cancelar
                </Button>
                <Button type="submit" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  {editando ? 'Atualizar' : 'Registrar'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filtros */}
      <Card className="p-4">
        <div className="flex gap-2 flex-col md:flex-row">
          <Input
            placeholder="Buscar por nome, telefone ou serviço..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1"
          />
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Filtrar por status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os Status</SelectItem>
              {STATUS_ATENDIMENTO.map(status => (
                <SelectItem key={status.value} value={status.value}>
                  {status.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Tabela */}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted border-b border-border">
              <tr>
                <th className="py-3 px-4 text-left text-sm font-semibold text-foreground">Cliente</th>
                <th className="py-3 px-4 text-left text-sm font-semibold text-foreground">Contato</th>
                <th className="py-3 px-4 text-left text-sm font-semibold text-foreground">Serviço</th>
                <th className="py-3 px-4 text-left text-sm font-semibold text-foreground">Status</th>
                <th className="py-3 px-4 text-left text-sm font-semibold text-foreground">Urgência</th>
                <th className="py-3 px-4 text-left text-sm font-semibold text-foreground">Ações</th>
              </tr>
            </thead>
            <tbody>
              {atendimentosFiltrados.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 px-4 text-center text-muted-foreground">
                    Nenhum atendimento encontrado
                  </td>
                </tr>
              ) : (
                atendimentosFiltrados.map(atendimento => (
                  <tr key={atendimento.id} className="border-b border-border hover:bg-muted">
                    <td className="py-3 px-4 font-medium text-foreground">{atendimento.nome_cliente}</td>
                    <td className="py-3 px-4 text-sm">
                      <div className="flex items-center gap-2">
                        <Phone size={14} className="text-muted-foreground" />
                        <span>{atendimento.telefone}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-sm">{atendimento.tipo_servico}</td>
                    <td className="py-3 px-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(atendimento.status)}`}>
                        {getStatusLabel(atendimento.status)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm capitalize">
                      {atendimento.urgencia === 'alta' && <span className="text-red-600 font-semibold">Alta</span>}
                      {atendimento.urgencia === 'media' && <span className="text-orange-600 font-semibold">Média</span>}
                      {atendimento.urgencia === 'baixa' && <span className="text-green-600 font-semibold">Baixa</span>}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setVisualizando(atendimento);
                            setViewOpen(true);
                          }}
                          className="text-blue-600 hover:bg-blue-50"
                        >
                          <Eye size={16} />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleEditar(atendimento)}
                          className="text-orange-600 hover:bg-orange-50"
                        >
                          <Edit2 size={16} />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDeletar(atendimento.id)}
                          className="text-red-600 hover:bg-red-50"
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Dialog de Visualização */}
      <Dialog open={viewOpen} onOpenChange={setViewOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detalhes do Atendimento</DialogTitle>
          </DialogHeader>
          {visualizando && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Nome</p>
                  <p className="text-foreground font-semibold">{visualizando.nome_cliente}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Telefone</p>
                  <p className="text-foreground font-semibold">{visualizando.telefone}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Bairro</p>
                  <p className="text-foreground">{visualizando.bairro || '-'}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Cidade</p>
                  <p className="text-foreground">{visualizando.cidade || '-'}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Origem</p>
                  <p className="text-foreground">{getOrigemLabel(visualizando.origem)}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Tipo de Serviço</p>
                  <p className="text-foreground">{visualizando.tipo_servico}</p>
                </div>
              </div>

              <div>
                <p className="text-sm font-medium text-muted-foreground">Descrição</p>
                <p className="text-foreground">{visualizando.descricao}</p>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Status</p>
                  <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(visualizando.status)}`}>
                    {getStatusLabel(visualizando.status)}
                  </span>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Urgência</p>
                  <p className="text-foreground capitalize font-semibold">{visualizando.urgencia}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Valor Estimado</p>
                  <p className="text-foreground font-semibold">
                    {visualizando.valor_estimado ? `R$ ${visualizando.valor_estimado.toFixed(2)}` : '-'}
                  </p>
                </div>
              </div>

              {visualizando.data_preferencial && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Data Preferencial</p>
                  <p className="text-foreground">{new Date(visualizando.data_preferencial).toLocaleDateString('pt-BR')}</p>
                </div>
              )}

              {visualizando.observacoes && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Observações</p>
                  <p className="text-foreground">{visualizando.observacoes}</p>
                </div>
              )}

              <div className="flex gap-2 justify-end pt-4 border-t border-border">
                <Button variant="outline" onClick={() => setViewOpen(false)}>
                  Fechar
                </Button>
                {visualizando.status !== 'convertido_os' && (
                  <Button
                    className="bg-emerald-600 hover:bg-emerald-700 text-white"
                    onClick={() => {
                      const resultado = converterAtendimentoEmOrdem(visualizando.id);
                      if (resultado.sucesso) {
                        toast.success(resultado.mensagem);
                        setViewOpen(false);
                      } else {
                        toast.error(resultado.mensagem);
                      }
                    }}
                  >
                    <CheckCircle2 size={16} className="mr-2" />
                    Converter em OS
                  </Button>
                )}
                <Button
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                  onClick={() => {
                    handleEditar(visualizando);
                    setViewOpen(false);
                  }}
                >
                  <Edit2 size={16} className="mr-2" />
                  Editar
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
