import { useState } from 'react';
import { useCRM, Servico } from '@/contexts/CRMContext';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Edit2, Trash2, Save, X, Download } from 'lucide-react';
import { toast } from 'sonner';
import { exportServicosCSV } from '@/lib/exportCSV';

export default function Servicos() {
  const { servicos, adicionarServico, atualizarServico, deletarServico } = useCRM();
  const [open, setOpen] = useState(false);
  const [editando, setEditando] = useState<string | null>(null);
  const [editandoInline, setEditandoInline] = useState<string | null>(null);
  const [formData, setFormData] = useState<Omit<Servico, 'id'>>({
    nome: '',
    descricao: '',
    preco: 0,
    tempo_estimado: 0
  });
  const [editData, setEditData] = useState<Partial<Servico>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.nome.trim()) {
      toast.error('Nome do serviço é obrigatório');
      return;
    }

    if (formData.preco <= 0) {
      toast.error('Preço deve ser maior que zero');
      return;
    }

    if (editando) {
      atualizarServico(editando, formData);
      toast.success('Serviço atualizado com sucesso');
    } else {
      adicionarServico(formData);
      toast.success('Serviço adicionado com sucesso');
    }

    setFormData({
      nome: '',
      descricao: '',
      preco: 0,
      tempo_estimado: 0
    });
    setEditando(null);
    setOpen(false);
  };

  const handleEditar = (servico: Servico) => {
    setFormData({
      nome: servico.nome,
      descricao: servico.descricao,
      preco: servico.preco,
      tempo_estimado: servico.tempo_estimado
    });
    setEditando(servico.id);
    setOpen(true);
  };

  const handleEditarInline = (servico: Servico) => {
    setEditandoInline(servico.id);
    setEditData(servico);
  };

  const handleSalvarInline = (id: string) => {
    if (!editData.nome?.trim()) {
      toast.error('Nome do serviço é obrigatório');
      return;
    }

    if (!editData.preco || editData.preco <= 0) {
      toast.error('Preço deve ser maior que zero');
      return;
    }

    atualizarServico(id, editData);
    toast.success('Serviço atualizado com sucesso');
    setEditandoInline(null);
    setEditData({});
  };

  const handleCancelarInline = () => {
    setEditandoInline(null);
    setEditData({});
  };

  const handleDeletar = (id: string) => {
    if (window.confirm('Tem certeza que deseja deletar este serviço?')) {
      deletarServico(id);
      toast.success('Serviço deletado com sucesso');
    }
  };

  const handleFecharDialog = () => {
    setOpen(false);
    setEditando(null);
    setFormData({
      nome: '',
      descricao: '',
      preco: 0,
      tempo_estimado: 0
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Serviços</h1>
          <p className="text-muted-foreground mt-1">Tabela de preços e serviços oferecidos</p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => {
              if (servicos.length === 0) {
                toast.error('Nenhum serviço para exportar');
                return;
              }
              exportServicosCSV(servicos);
              toast.success('Serviços exportados com sucesso!');
            }}
            variant="outline"
            className="border-primary text-primary hover:bg-primary/10"
          >
            <Download size={18} className="mr-2" />
            Exportar CSV
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Plus size={18} className="mr-2" />
              Novo Serviço
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editando ? 'Editar Serviço' : 'Novo Serviço'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground">Nome do Serviço *</label>
                <Input
                  value={formData.nome}
                  onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                  placeholder="Ex: Montagem Básica"
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">Descrição</label>
                <Input
                  value={formData.descricao}
                  onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                  placeholder="Descrição do serviço"
                  className="mt-1"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-foreground">Preço (R$) *</label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.preco}
                    onChange={(e) => setFormData({ ...formData, preco: parseFloat(e.target.value) })}
                    placeholder="0.00"
                    className="mt-1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Tempo Estimado (min)</label>
                  <Input
                    type="number"
                    value={formData.tempo_estimado}
                    onChange={(e) => setFormData({ ...formData, tempo_estimado: parseInt(e.target.value) })}
                    placeholder="0"
                    className="mt-1"
                  />
                </div>
              </div>
              <div className="flex gap-2 pt-4">
                <Button type="submit" className="bg-primary hover:bg-primary/90 text-primary-foreground flex-1">
                  {editando ? 'Atualizar' : 'Adicionar'}
                </Button>
                <Button type="button" variant="outline" onClick={handleFecharDialog} className="flex-1">
                  Cancelar
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
        </div>
      </div>

      {/* Tabela de Serviços */}
      <Card className="border border-border overflow-hidden">
        {servicos.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted">
                  <th className="text-left py-4 px-6 font-semibold text-foreground">Serviço</th>
                  <th className="text-left py-4 px-6 font-semibold text-foreground">Descrição</th>
                  <th className="text-left py-4 px-6 font-semibold text-foreground">Preço</th>
                  <th className="text-left py-4 px-6 font-semibold text-foreground">Tempo Est.</th>
                  <th className="text-left py-4 px-6 font-semibold text-foreground">Ações</th>
                </tr>
              </thead>
              <tbody>
                {servicos.map((servico) => (
                  <tr key={servico.id} className="border-b border-border hover:bg-muted/50 transition-colors">
                    {editandoInline === servico.id ? (
                      <>
                        <td className="py-4 px-6">
                          <Input
                            value={editData.nome || ''}
                            onChange={(e) => setEditData({ ...editData, nome: e.target.value })}
                            className="w-full"
                          />
                        </td>
                        <td className="py-4 px-6">
                          <Input
                            value={editData.descricao || ''}
                            onChange={(e) => setEditData({ ...editData, descricao: e.target.value })}
                            className="w-full"
                          />
                        </td>
                        <td className="py-4 px-6">
                          <Input
                            type="number"
                            step="0.01"
                            value={editData.preco || 0}
                            onChange={(e) => setEditData({ ...editData, preco: parseFloat(e.target.value) })}
                            className="w-full"
                          />
                        </td>
                        <td className="py-4 px-6">
                          <Input
                            type="number"
                            value={editData.tempo_estimado || 0}
                            onChange={(e) => setEditData({ ...editData, tempo_estimado: parseInt(e.target.value) })}
                            className="w-full"
                          />
                        </td>
                        <td className="py-4 px-6">
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleSalvarInline(servico.id)}
                              className="text-primary"
                            >
                              <Save size={16} />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={handleCancelarInline}
                              className="text-destructive"
                            >
                              <X size={16} />
                            </Button>
                          </div>
                        </td>
                      </>
                    ) : (
                      <>
                        <td className="py-4 px-6 font-semibold text-foreground">{servico.nome}</td>
                        <td className="py-4 px-6 text-muted-foreground text-sm">{servico.descricao}</td>
                        <td className="py-4 px-6 font-semibold text-foreground">R$ {servico.preco.toFixed(2)}</td>
                        <td className="py-4 px-6 text-muted-foreground">{servico.tempo_estimado} min</td>
                        <td className="py-4 px-6">
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEditarInline(servico)}
                            >
                              <Edit2 size={16} />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDeletar(servico.id)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 size={16} />
                            </Button>
                          </div>
                        </td>
                      </>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-12 text-center">
            <p className="text-muted-foreground mb-4">Nenhum serviço cadastrado ainda</p>
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  <Plus size={18} className="mr-2" />
                  Adicionar Primeiro Serviço
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Novo Serviço</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-foreground">Nome do Serviço *</label>
                    <Input
                      value={formData.nome}
                      onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                      placeholder="Ex: Montagem Básica"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground">Descrição</label>
                    <Input
                      value={formData.descricao}
                      onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                      placeholder="Descrição do serviço"
                      className="mt-1"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-foreground">Preço (R$) *</label>
                      <Input
                        type="number"
                        step="0.01"
                        value={formData.preco}
                        onChange={(e) => setFormData({ ...formData, preco: parseFloat(e.target.value) })}
                        placeholder="0.00"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground">Tempo Estimado (min)</label>
                      <Input
                        type="number"
                        value={formData.tempo_estimado}
                        onChange={(e) => setFormData({ ...formData, tempo_estimado: parseInt(e.target.value) })}
                        placeholder="0"
                        className="mt-1"
                      />
                    </div>
                  </div>
                  <div className="flex gap-2 pt-4">
                    <Button type="submit" className="bg-primary hover:bg-primary/90 text-primary-foreground flex-1">
                      Adicionar
                    </Button>
                    <Button type="button" variant="outline" onClick={handleFecharDialog} className="flex-1">
                      Cancelar
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        )}
      </Card>
    </div>
  );
}
