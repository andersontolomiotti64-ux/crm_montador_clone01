import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Mail, ArrowLeft, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import { useLocation } from 'wouter';

export default function RecuperarSenha() {
  const { solicitarRecuperacaoSenha } = useAuth();
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [enviado, setEnviado] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!email.trim()) {
      toast.error('Por favor, digite seu email');
      return;
    }

    if (!email.includes('@')) {
      toast.error('Email inválido');
      return;
    }

    setLoading(true);

    try {
      const resultado = solicitarRecuperacaoSenha(email);
      
      if (resultado.sucesso) {
        setEnviado(true);
        toast.success(resultado.mensagem);
        
        // Se houver token (para demo), mostrar no console
        if (resultado.token) {
          console.log('Token de reset para demo:', resultado.token);
          console.log('Link de reset:', `${window.location.origin}/reset-senha?token=${resultado.token}`);
        }
      }
    } catch (erro) {
      toast.error('Erro ao processar solicitação');
    } finally {
      setLoading(false);
    }
  };

  if (enviado) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 border border-border shadow-lg">
          <div className="text-center space-y-4">
            <div className="flex justify-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle size={32} className="text-green-600" />
              </div>
            </div>
            <h1 className="text-2xl font-bold text-foreground">Email Enviado!</h1>
            <p className="text-muted-foreground">
              Se o email <span className="font-semibold">{email}</span> estiver registrado em nossa base, você receberá um link de recuperação em breve.
            </p>
            <p className="text-sm text-muted-foreground">
              O link é válido por 24 horas. Verifique também sua pasta de spam.
            </p>
            <Button
              onClick={() => setLocation('/login')}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground mt-6"
            >
              Voltar ao Login
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-8 border border-border shadow-lg">
        <div className="space-y-6">
          {/* Header */}
          <div className="space-y-2">
            <h1 className="text-3xl font-bold text-foreground">Recuperar Senha</h1>
            <p className="text-muted-foreground">
              Digite seu email para receber um link de recuperação
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Email
              </label>
              <div className="relative">
                <Mail size={18} className="absolute left-3 top-3 text-muted-foreground" />
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seu@email.com"
                  className="pl-10"
                  disabled={loading}
                />
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              {loading ? 'Processando...' : 'Enviar Link de Recuperação'}
            </Button>
          </form>

          {/* Divider */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-muted-foreground">ou</span>
            </div>
          </div>

          {/* Back to Login */}
          <Button
            type="button"
            variant="outline"
            onClick={() => setLocation('/login')}
            className="w-full border-border text-foreground hover:bg-muted"
          >
            <ArrowLeft size={18} className="mr-2" />
            Voltar ao Login
          </Button>

          {/* Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-800">
            <p className="font-semibold mb-1">Para fins de demonstração:</p>
            <p>Verifique o console do navegador (F12) para ver o link de recuperação gerado.</p>
          </div>
        </div>
      </Card>
    </div>
  );
}
