import { useState } from 'react';
import { useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Edit2, Plus, Trash2, Copy, RotateCcw } from 'lucide-react';
import { PREDEFINED_SERVICES, PredefinedService } from '@shared/predefinedServices';
import { useCRM } from '@/contexts/CRMContext';
import { toast } from 'sonner';

export default function GerenciarServicos() {
  const { servicos, adicionarServico, atualizarServico, deletarServico } = useCRM();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [formData, setFormData] = useState<Partial<PredefinedService>>({});
  const [activeTab, setActiveTab] = useState<'meus' | 'predefinidos'>('meus');

  const categories = ['montagem', 'desmontagem', 'reparo', 'customizacao', 'outro'];

  const filteredPredefined = PREDEFINED_SERVICES.filter(s => {
    const matchesSearch = s.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         s.descricao.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !categoryFilter || s.categoria === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const handleAddFromPredefined = (service: PredefinedService) => {
    const newService = {
      id: `srv-${Date.now()}`,
      nome: service.nome,
      descricao: service.descricao,
      preco: service.precoBase,
      tempo_estimado: service.tempoEstimado,
      exige_dupla: service.exigeDupla,
      exige_deslocamento_especial: service.exigeDeslocamentoEspecial,
    };

    adicionarServico(newService);
    toast.success(`Serviço "${service.nome}" adicionado!`);
  };

  const handleDuplicateService = (service: typeof servicos[0]) => {
    const newService = {
      ...service,
      id: `srv-${Date.now()}`,
      nome: `${service.nome} (Cópia)`,
    };

    adicionarServico(newService);
    toast.success('Serviço duplicado com sucesso!');
  };

  const handleEditService = (service: typeof servicos[0]) => {
    setEditingId(service.id);
    setFormData(service);
    setShowAddDialog(true);
  };

  const handleSaveService = () => {
    if (!formData.nome || !formData.preco) {
      toast.error('Preencha os campos obrigatórios');
      return;
    }

    if (editingId) {
      atualizarServico(editingId, formData as any);
      toast.success('Serviço atualizado com sucesso!');
    } else {
      const newService = {
        id: `srv-${Date.now()}`,
        nome: formData.nome || '',
        descricao: formData.descricao || '',
        preco: formData.preco || 0,
        tempo_estimado: formData.tempo_estimado || 60,
        exige_dupla: formData.exige_dupla || false,
        exige_deslocamento_especial: formData.exige_deslocamento_especial || false,
      };

      adicionarServico(newService);
      toast.success('Serviço adicionado com sucesso!');
    }

    setShowAddDialog(false);
    setEditingId(null);
    setFormData({});
  };

  const handleResetToDefault = () => {
    if (confirm('Isso irá substituir todos os serviços pelos pré-definidos. Continuar?')) {
      servicos.forEach(s => deletarServico(s.id));
      PREDEFINED_SERVICES.forEach(s => {
        adicionarServico({
          id: `srv-${Date.now()}-${Math.random()}`,
          nome: s.nome,
          descricao: s.descricao,
          preco: s.precoBase,
          tempo_estimado: s.tempoEstimado,
          exige_dupla: s.exigeDupla,
          exige_deslocamento_especial: s.exigeDeslocamentoEspecial,
        });
      });
      toast.success('Serviços restaurados aos valores padrão!');
    }
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Gerenciar Serviços</h1>
          <p className="text-gray-600 mt-1">Adicione, edite ou remova serviços da sua lista</p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={handleResetToDefault}
            variant="outline"
            className="gap-2"
          >
            <RotateCcw size={18} />
            Restaurar Padrão
          </Button>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button
                onClick={() => {
                  setEditingId(null);
                  setFormData({});
                }}
                className="gap-2"
              >
                <Plus size={18} />
                Novo Serviço
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  {editingId ? 'Editar Serviço' : 'Adicionar Novo Serviço'}
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Nome *</label>
                  <Input
                    value={formData.nome || ''}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    placeholder="Nome do serviço"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">Descrição</label>
                  <Textarea
                    value={formData.descricao || ''}
                    onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                    placeholder="Descrição do serviço"
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Preço (R$) *</label>
                    <Input
                      type="number"
                      value={formData.preco || ''}
                      onChange={(e) => setFormData({ ...formData, preco: parseFloat(e.target.value) })}
                      placeholder="0.00"
                      step="0.01"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium">Tempo Estimado (min)</label>
                    <Input
                      type="number"
                      value={formData.tempo_estimado || ''}
                      onChange={(e) => setFormData({ ...formData, tempo_estimado: parseInt(e.target.value) })}
                      placeholder="60"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={formData.exige_dupla || false}
                      onChange={(e) => setFormData({ ...formData, exige_dupla: e.target.checked })}
                      className="rounded"
                    />
                    <span className="text-sm">Exige dupla de montadores</span>
                  </label>

                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={formData.exige_deslocamento_especial || false}
                      onChange={(e) => setFormData({ ...formData, exige_deslocamento_especial: e.target.checked })}
                      className="rounded"
                    />
                    <span className="text-sm">Exige deslocamento especial</span>
                  </label>
                </div>

                <div className="flex gap-2 justify-end pt-4">
                  <Button variant="outline" onClick={() => setShowAddDialog(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={handleSaveService}>
                    {editingId ? 'Atualizar' : 'Adicionar'}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b">
        <button
          onClick={() => setActiveTab('meus')}
          className={`px-4 py-2 font-medium border-b-2 ${
            activeTab === 'meus'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-gray-600 hover:text-gray-900'
          }`}
        >
          Meus Serviços ({servicos.length})
        </button>
        <button
          onClick={() => setActiveTab('predefinidos')}
          className={`px-4 py-2 font-medium border-b-2 ${
            activeTab === 'predefinidos'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-gray-600 hover:text-gray-900'
          }`}
        >
          Serviços Pré-definidos ({PREDEFINED_SERVICES.length})
        </button>
      </div>

      {/* Meus Serviços */}
      {activeTab === 'meus' && (
        <div className="space-y-4">
          {servicos.length === 0 ? (
            <Card className="p-8 text-center text-gray-500">
              <p>Nenhum serviço adicionado ainda</p>
              <p className="text-sm mt-2">Adicione um novo serviço ou importe dos pré-definidos</p>
            </Card>
          ) : (
            servicos.map((servico) => (
              <Card key={servico.id} className="p-4">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg">{servico.nome}</h3>
                    <p className="text-sm text-gray-600 mt-1">{servico.descricao}</p>
                    <div className="flex gap-4 mt-3 text-sm">
                      <span className="font-medium">R$ {servico.preco?.toFixed(2)}</span>
                      <span className="text-gray-600">{servico.tempo_estimado} min</span>
                      {servico.exige_dupla && <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded">Dupla</span>}
                      {servico.exige_deslocamento_especial && <span className="bg-orange-100 text-orange-800 px-2 py-1 rounded">Deslocamento</span>}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDuplicateService(servico)}
                    >
                      <Copy size={16} />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEditService(servico)}
                    >
                      <Edit2 size={16} />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => {
                        deletarServico(servico.id);
                        toast.success('Serviço removido');
                      }}
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      )}

      {/* Serviços Pré-definidos */}
      {activeTab === 'predefinidos' && (
        <div className="space-y-4">
          {/* Filtros */}
          <div className="flex gap-4">
            <Input
              placeholder="Buscar serviço..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
            />
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filtrar por categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="predefined">Todas</SelectItem>
                {categories.map(cat => (
                  <SelectItem key={cat} value={cat}>
                    {cat.charAt(0).toUpperCase() + cat.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Grid de Serviços */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredPredefined.map((service) => (
              <Card key={service.id} className="p-4 hover:shadow-lg transition">
                <div className="space-y-3">
                  <div>
                    <h3 className="font-semibold">{service.nome}</h3>
                    <p className="text-sm text-gray-600 mt-1">{service.descricao}</p>
                  </div>

                  <div className="flex gap-4 text-sm">
                    <span className="font-medium text-green-600">R$ {service.precoBase.toFixed(2)}</span>
                    <span className="text-gray-600">{service.tempoEstimado} min</span>
                    <span className="text-xs bg-gray-100 px-2 py-1 rounded">
                      {service.categoria}
                    </span>
                  </div>

                  <div className="flex gap-2 text-xs">
                    {service.exigeDupla && <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded">Dupla</span>}
                    {service.exigeDeslocamentoEspecial && <span className="bg-orange-100 text-orange-800 px-2 py-1 rounded">Deslocamento</span>}
                  </div>

                  <Button
                    size="sm"
                    onClick={() => handleAddFromPredefined(service)}
                    className="w-full"
                  >
                    <Plus size={16} className="mr-2" />
                    Adicionar à Minha Lista
                  </Button>
                </div>
              </Card>
            ))}
          </div>

          {filteredPredefined.length === 0 && (
            <Card className="p-8 text-center text-gray-500">
              <p>Nenhum serviço encontrado</p>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
