import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Download, TrendingUp, TrendingDown } from 'lucide-react';
import { usePriceHistory } from '@/hooks/usePriceHistory';
import { useCRM } from '@/contexts/CRMContext';

export default function HistoricoPrecos() {
  const { history, obterEstatisticas, exportarCSV, obterHistoricoServico } = usePriceHistory();
  const { servicos } = useCRM();
  const [servicoSelecionado, setServicoSelecionado] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');

  const stats = obterEstatisticas();
  const historicoFiltrado = servicoSelecionado 
    ? obterHistoricoServico(servicoSelecionado)
    : history;

  const getServico = (servicoId: string) => {
    return servicos.find(s => s.id === servicoId);
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Histórico de Preços</h1>
          <p className="text-gray-600 mt-1">Acompanhe as mudanças de preços dos seus serviços</p>
        </div>
        <Button onClick={exportarCSV} className="gap-2">
          <Download size={18} />
          Exportar CSV
        </Button>
      </div>

      {/* Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="text-sm text-gray-600">Total de Mudanças</div>
          <div className="text-2xl font-bold mt-2">{stats.totalMudancas}</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-gray-600">Aumento Médio</div>
          <div className="text-2xl font-bold text-green-600 mt-2">
            R$ {stats.aumentosMedio.toFixed(2)}
          </div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-gray-600">Redução Média</div>
          <div className="text-2xl font-bold text-red-600 mt-2">
            R$ {stats.reducoesMedio.toFixed(2)}
          </div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-gray-600">Serviços Alterados</div>
          <div className="text-2xl font-bold mt-2">{stats.servicosMaisAlterados.length}</div>
        </Card>
      </div>

      {/* Filtros */}
      <Card className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium">Buscar por Serviço</label>
            <Input
              placeholder="Digite o nome do serviço..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="mt-2"
            />
          </div>
          <div>
            <label className="text-sm font-medium">Filtrar por Serviço</label>
            <select
              value={servicoSelecionado}
              onChange={(e) => setServicoSelecionado(e.target.value)}
              className="w-full mt-2 px-3 py-2 border rounded-md"
            >
              <option value="">Todos os serviços</option>
              {servicos.map(s => (
                <option key={s.id} value={s.id}>
                  {s.nome}
                </option>
              ))}
            </select>
          </div>
        </div>
      </Card>

      {/* Histórico */}
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4">Histórico de Mudanças</h2>
        
        {historicoFiltrado.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <p>Nenhuma mudança de preço registrada</p>
          </div>
        ) : (
          <div className="space-y-3">
            {historicoFiltrado.map(entrada => {
              const servico = getServico(entrada.servicoId);
              const variacao = entrada.precoNovo - entrada.precoAnterior;
              const percentual = (variacao / entrada.precoAnterior) * 100;
              const isAumento = variacao > 0;

              return (
                <div
                  key={entrada.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                >
                  <div className="flex-1">
                    <div className="font-semibold">
                      {servico?.nome || 'Serviço Desconhecido'}
                    </div>
                    <div className="text-sm text-gray-600 mt-1">
                      {new Date(entrada.data).toLocaleDateString('pt-BR')}
                      {entrada.motivo && ` - ${entrada.motivo}`}
                    </div>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <div className="text-sm text-gray-600">De</div>
                      <div className="font-semibold">R$ {entrada.precoAnterior.toFixed(2)}</div>
                    </div>

                    <div className="text-right">
                      <div className="text-sm text-gray-600">Para</div>
                      <div className="font-semibold">R$ {entrada.precoNovo.toFixed(2)}</div>
                    </div>

                    <div className={`text-right ${isAumento ? 'text-green-600' : 'text-red-600'}`}>
                      <div className="flex items-center gap-1 justify-end">
                        {isAumento ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
                        <span className="font-semibold">
                          {isAumento ? '+' : ''}{percentual.toFixed(1)}%
                        </span>
                      </div>
                      <div className="text-sm">
                        {isAumento ? '+' : ''}R$ {variacao.toFixed(2)}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>

      {/* Serviços Mais Alterados */}
      {stats.servicosMaisAlterados.length > 0 && (
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Serviços Mais Alterados</h2>
          <div className="space-y-3">
            {stats.servicosMaisAlterados.map(({ servicoId, count }) => {
              const servico = getServico(servicoId);
              return (
                <div
                  key={servicoId}
                  className="flex items-center justify-between p-3 border rounded-lg"
                >
                  <div className="font-semibold">
                    {servico?.nome || 'Serviço Desconhecido'}
                  </div>
                  <div className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-semibold">
                    {count} mudança{count > 1 ? 's' : ''}
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      )}
    </div>
  );
}
