import { useCRM } from '@/contexts/CRMContext';
import { Card } from '@/components/ui/card';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Download, TrendingUp, TrendingDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { exportRelatorioFinanceiroCSV } from '@/lib/exportCSV';

export default function Relatorios() {
  const { ordens, clientes, servicos } = useCRM();

  // Dados financeiros
  const ordensConluidas = ordens.filter(o => o.status === 'concluida');
  const receitaTotal = ordensConluidas.reduce((sum, o) => sum + o.valor_total, 0);
  const ticketMedio = ordensConluidas.length > 0 ? receitaTotal / ordensConluidas.length : 0;

  // Receita por mês
  const receitaPorMes = Array.from({ length: 12 }, (_, i) => {
    const mes = new Date();
    mes.setMonth(i);
    const mesStr = mes.toLocaleString('pt-BR', { month: 'short' });
    const mesNum = i + 1;
    const anoAtual = new Date().getFullYear();
    
    const receita = ordensConluidas
      .filter(o => {
        const dataParts = o.data_criacao.split('T')[0].split('-');
        return parseInt(dataParts[1]) === mesNum && parseInt(dataParts[0]) === anoAtual;
      })
      .reduce((sum, o) => sum + o.valor_total, 0);

    return {
      mes: mesStr,
      receita: receita
    };
  }).filter(d => d.receita > 0 || Array.from({ length: 12 }, (_, i) => i + 1).indexOf(new Date().getMonth() + 1) >= Array.from({ length: 12 }, (_, i) => i + 1).indexOf(new Date().getMonth() + 1));

  // Top clientes
  const topClientes = clientes
    .map(cliente => {
      const receitaCliente = ordensConluidas
        .filter(o => o.cliente_id === cliente.id)
        .reduce((sum, o) => sum + o.valor_total, 0);
      return {
        nome: cliente.nome,
        receita: receitaCliente
      };
    })
    .filter(c => c.receita > 0)
    .sort((a, b) => b.receita - a.receita)
    .slice(0, 5);

  // Serviços mais vendidos
  const servicosMaisVendidos = servicos
    .map(servico => {
      const quantidade = ordensConluidas.reduce((sum, ordem) => {
        const s = ordem.servicos.find(srv => srv.servico_id === servico.id);
        return sum + (s ? s.quantidade : 0);
      }, 0);
      const receita = ordensConluidas.reduce((sum, ordem) => {
        const s = ordem.servicos.find(srv => srv.servico_id === servico.id);
        return sum + (s ? s.quantidade * s.preco_unitario : 0);
      }, 0);
      return {
        nome: servico.nome,
        quantidade,
        receita
      };
    })
    .filter(s => s.quantidade > 0)
    .sort((a, b) => b.receita - a.receita);

  // Status das ordens
  const statusData = [
    { name: 'Agendada', value: ordens.filter(o => o.status === 'agendada').length },
    { name: 'Confirmada', value: ordens.filter(o => o.status === 'confirmada').length },
    { name: 'Em Andamento', value: ordens.filter(o => o.status === 'em_andamento').length },
    { name: 'Concluída', value: ordens.filter(o => o.status === 'concluida').length },
    { name: 'Cancelada', value: ordens.filter(o => o.status === 'cancelada').length }
  ];

  const COLORS = ['#FBBF24', '#0066CC', '#10B981', '#EF4444'];

  const handleExportarPDF = () => {
    const conteudo = `
CRM MONTADOR DE MÓVEIS - RELATÓRIO
Data: ${new Date().toLocaleDateString('pt-BR')}

RESUMO FINANCEIRO
================
Receita Total: R$ ${receitaTotal.toFixed(2)}
Ticket Médio: R$ ${ticketMedio.toFixed(2)}
Ordens Concluídas: ${ordensConluidas.length}

STATUS DAS ORDENS
================
Pendentes: ${statusData[0].value}
Em Progresso: ${statusData[1].value}
Concluídas: ${statusData[2].value}
Canceladas: ${statusData[3].value}

TOP CLIENTES
============
${topClientes.map((c, i) => `${i + 1}. ${c.nome}: R$ ${c.receita.toFixed(2)}`).join('\n')}

SERVIÇOS MAIS VENDIDOS
=====================
${servicosMaisVendidos.slice(0, 5).map((s, i) => `${i + 1}. ${s.nome}: ${s.quantidade} unidades (R$ ${s.receita.toFixed(2)})`).join('\n')}
    `;

    const blob = new Blob([conteudo], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `relatorio-crm-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Relatórios</h1>
          <p className="text-muted-foreground mt-1">Análise e insights do seu negócio</p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => {
              if (ordens.length === 0) {
                toast.error('Nenhum dado para exportar');
                return;
              }
              exportRelatorioFinanceiroCSV(ordens, clientes, servicos);
              toast.success('Relatório exportado com sucesso!');
            }}
            variant="outline"
            className="border-primary text-primary hover:bg-primary/10"
          >
            <Download size={18} className="mr-2" />
            Exportar CSV
          </Button>
          <Button onClick={handleExportarPDF} className="bg-primary hover:bg-primary/90 text-primary-foreground">
            <Download size={18} className="mr-2" />
            Exportar TXT
          </Button>
        </div>
      </div>

      {/* Cards de Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Receita Total</p>
              <p className="text-3xl font-bold text-foreground mt-2">R$ {receitaTotal.toFixed(2)}</p>
            </div>
            <TrendingUp className="text-primary" size={32} />
          </div>
        </Card>

        <Card className="p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Ticket Médio</p>
              <p className="text-3xl font-bold text-foreground mt-2">R$ {ticketMedio.toFixed(2)}</p>
            </div>
            <TrendingDown className="text-accent" size={32} />
          </div>
        </Card>

        <Card className="p-6 border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Ordens Concluídas</p>
              <p className="text-3xl font-bold text-foreground mt-2">{ordensConluidas.length}</p>
            </div>
            <div className="text-primary text-3xl">✓</div>
          </div>
        </Card>
      </div>

      {/* Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Receita por Mês */}
        <Card className="p-6 border border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">Receita por Mês</h3>
          {receitaPorMes.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={receitaPorMes}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="mes" />
                <YAxis />
                <Tooltip formatter={(value) => `R$ ${typeof value === 'number' ? value.toFixed(2) : value}`} />
                <Line type="monotone" dataKey="receita" stroke="#0066CC" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground">
              Sem dados de receita
            </div>
          )}
        </Card>

        {/* Status das Ordens */}
        <Card className="p-6 border border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">Distribuição de Status</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {statusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Top Clientes */}
      <Card className="p-6 border border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Top 5 Clientes</h3>
        {topClientes.length > 0 ? (
          <div className="space-y-3">
            {topClientes.map((cliente, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-muted rounded">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-semibold text-sm">
                    {index + 1}
                  </div>
                  <span className="font-medium">{cliente.nome}</span>
                </div>
                <span className="font-semibold">R$ {cliente.receita.toFixed(2)}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground text-center py-8">Sem dados disponíveis</p>
        )}
      </Card>

      {/* Serviços Mais Vendidos */}
      <Card className="p-6 border border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Serviços Mais Vendidos</h3>
        {servicosMaisVendidos.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Serviço</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Quantidade</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Receita</th>
                </tr>
              </thead>
              <tbody>
                {servicosMaisVendidos.map((servico) => (
                  <tr key={servico.nome} className="border-b border-border hover:bg-muted">
                    <td className="py-3 px-4">{servico.nome}</td>
                    <td className="py-3 px-4">{servico.quantidade}</td>
                    <td className="py-3 px-4 font-semibold">R$ {servico.receita.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-muted-foreground text-center py-8">Sem dados disponíveis</p>
        )}
      </Card>
    </div>
  );
}
