import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useLocation } from 'wouter';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { LogIn, UserPlus } from 'lucide-react';
import { toast } from 'sonner';

export default function Login() {
  const { login, registrar } = useAuth();
  const [, setLocation] = useLocation();
  const [modo, setModo] = useState<'login' | 'registro'>('login');
  const [carregando, setCarregando] = useState(false);

  const [formLogin, setFormLogin] = useState({
    email: '',
    senha: ''
  });

  const [formRegistro, setFormRegistro] = useState({
    nome: '',
    email: '',
    senha: '',
    confirmarSenha: ''
  });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setCarregando(true);

    if (!formLogin.email.trim() || !formLogin.senha.trim()) {
      toast.error('Preencha todos os campos');
      setCarregando(false);
      return;
    }

    const sucesso = login(formLogin.email, formLogin.senha);

    if (sucesso) {
      toast.success('Login realizado com sucesso!');
      setFormLogin({ email: '', senha: '' });
      setLocation('/');
    } else {
      toast.error('Email ou senha incorretos');
    }

    setCarregando(false);
  };

  const handleRegistro = async (e: React.FormEvent) => {
    e.preventDefault();
    setCarregando(true);

    if (!formRegistro.nome.trim() || !formRegistro.email.trim() || !formRegistro.senha.trim()) {
      toast.error('Preencha todos os campos');
      setCarregando(false);
      return;
    }

    if (formRegistro.senha !== formRegistro.confirmarSenha) {
      toast.error('As senhas não correspondem');
      setCarregando(false);
      return;
    }

    if (formRegistro.senha.length < 6) {
      toast.error('A senha deve ter pelo menos 6 caracteres');
      setCarregando(false);
      return;
    }

    const sucesso = registrar(formRegistro.nome, formRegistro.email, formRegistro.senha);

    if (sucesso) {
      toast.success('Conta criada com sucesso! Bem-vindo!');
      setFormRegistro({ nome: '', email: '', senha: '', confirmarSenha: '' });
      setLocation('/');
    } else {
      toast.error('Erro ao criar conta. Este email já pode estar registrado.');
    }

    setCarregando(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 to-accent/5 p-4">
      <Card className="w-full max-w-md border border-border shadow-lg">
        <div className="p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-primary rounded-lg flex items-center justify-center mx-auto mb-4">
              <span className="text-primary-foreground font-bold text-2xl">M</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground">CRM Móveis</h1>
            <p className="text-muted-foreground text-sm mt-2">
              {modo === 'login' ? 'Acesse sua conta' : 'Crie uma nova conta'}
            </p>
          </div>

          {/* Abas */}
          <div className="flex gap-2 mb-6">
            <button
              onClick={() => setModo('login')}
              className={`flex-1 py-2 px-4 rounded font-medium transition-colors ${
                modo === 'login'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              <LogIn size={16} className="inline mr-2" />
              Login
            </button>
            <button
              onClick={() => setModo('registro')}
              className={`flex-1 py-2 px-4 rounded font-medium transition-colors ${
                modo === 'registro'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              <UserPlus size={16} className="inline mr-2" />
              Registrar
            </button>
          </div>

          {/* Formulário de Login */}
          {modo === 'login' && (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">Email</label>
                <Input
                  type="email"
                  value={formLogin.email}
                  onChange={(e) => setFormLogin({ ...formLogin, email: e.target.value })}
                  placeholder="seu@email.com"
                  disabled={carregando}
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground block mb-2">Senha</label>
                <Input
                  type="password"
                  value={formLogin.senha}
                  onChange={(e) => setFormLogin({ ...formLogin, senha: e.target.value })}
                  placeholder="••••••••"
                  disabled={carregando}
                />
              </div>

              <Button
                type="submit"
                disabled={carregando}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                {carregando ? 'Entrando...' : 'Entrar'}
              </Button>

              {/* Link de Recuperação de Senha */}
              <div className="text-center">
                <button
                  type="button"
                  onClick={() => setLocation('/recuperar-senha')}
                  className="text-sm text-primary hover:text-primary/80 font-medium transition-colors"
                >
                  Esqueci minha senha
                </button>
              </div>

              {/* Dados de teste */}
              <div className="mt-6 p-4 bg-muted rounded text-sm text-muted-foreground">
                <p className="font-semibold mb-2">Dados de teste:</p>
                <p>Email: teste@example.com</p>
                <p>Senha: 123456</p>
              </div>
            </form>
          )}

          {/* Formulário de Registro */}
          {modo === 'registro' && (
            <form onSubmit={handleRegistro} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">Nome Completo</label>
                <Input
                  type="text"
                  value={formRegistro.nome}
                  onChange={(e) => setFormRegistro({ ...formRegistro, nome: e.target.value })}
                  placeholder="Seu nome"
                  disabled={carregando}
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground block mb-2">Email</label>
                <Input
                  type="email"
                  value={formRegistro.email}
                  onChange={(e) => setFormRegistro({ ...formRegistro, email: e.target.value })}
                  placeholder="seu@email.com"
                  disabled={carregando}
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground block mb-2">Senha</label>
                <Input
                  type="password"
                  value={formRegistro.senha}
                  onChange={(e) => setFormRegistro({ ...formRegistro, senha: e.target.value })}
                  placeholder="Mínimo 6 caracteres"
                  disabled={carregando}
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground block mb-2">Confirmar Senha</label>
                <Input
                  type="password"
                  value={formRegistro.confirmarSenha}
                  onChange={(e) => setFormRegistro({ ...formRegistro, confirmarSenha: e.target.value })}
                  placeholder="Confirme sua senha"
                  disabled={carregando}
                />
              </div>

              <Button
                type="submit"
                disabled={carregando}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                {carregando ? 'Criando conta...' : 'Criar Conta'}
              </Button>
            </form>
          )}
        </div>
      </Card>
    </div>
  );
}
