import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { CRMProvider } from "./contexts/CRMContext";
import { Layout } from "./components/Layout";
import { InitializeApp } from "./components/InitializeApp";
import { OfflineIndicator } from "./components/OfflineIndicator";
import Dashboard from "./pages/Dashboard";
import Atendimentos from "./pages/Atendimentos";
import Clientes from "./pages/Clientes";
import Servicos from "./pages/Servicos";
import GerenciarServicos from "./pages/GerenciarServicos";
import Ordens from "./pages/Ordens";
import Relatorios from "./pages/Relatorios";
import Agenda from "./pages/Agenda";
import AdminDashboard from "./pages/AdminDashboard";
import Login from "./pages/Login";
import RecuperarSenha from "./pages/RecuperarSenha";
import ResetSenha from "./pages/ResetSenha";
import NotFound from "./pages/NotFound";
import { useEffect } from "react";



function Router() {
  const { isAutenticado, isAdmin } = useAuth();

  return (
    <Switch>
      <Route path={"/login"} component={Login} />
      <Route path={"/recuperar-senha"} component={RecuperarSenha} />
      <Route path={"/reset-senha"} component={ResetSenha} />
      
      {isAutenticado && (
        <Layout>
          <Switch>
            <Route path={"/"} component={Dashboard} />
            <Route path={"/atendimentos"} component={Atendimentos} />
            <Route path={"/clientes"} component={Clientes} />
            <Route path={"/servicos"} component={Servicos} />
            <Route path={"/gerenciar-servicos"} component={GerenciarServicos} />
            <Route path={"/ordens"} component={Ordens} />
            <Route path={"/relatorios"} component={Relatorios} />
            <Route path={"/agenda"} component={Agenda} />
            {isAdmin && <Route path={"/admin"} component={AdminDashboard} />}
            <Route path={"/404"} component={NotFound} />
            <Route component={NotFound} />
          </Switch>
        </Layout>
      )}

      {!isAutenticado && (
        <Route path="*" component={Login} />
      )}
    </Switch>
  );
}

function App() {
  // Detectar evento beforeinstallprompt para PWA
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      (window as any).deferredPrompt = e;
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <AuthProvider>
          <InitializeApp />
          <CRMProvider>
            <TooltipProvider>
              <Toaster />
              <OfflineIndicator />
              <Router />
            </TooltipProvider>
          </CRMProvider>
        </AuthProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
