/**
 * Utilitário para exportar dados em formato CSV
 */

export interface CSVExportOptions {
  filename: string;
  data: Record<string, any>[];
  columns?: string[];
}

/**
 * Escapa valores CSV para evitar problemas com vírgulas e quebras de linha
 */
function escapeCSV(value: any): string {
  if (value === null || value === undefined) {
    return '';
  }

  const stringValue = String(value);

  // Se contém vírgula, aspas ou quebra de linha, envolve em aspas
  if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n')) {
    return `"${stringValue.replace(/"/g, '""')}"`;
  }

  return stringValue;
}

/**
 * Converte array de objetos para string CSV
 */
function convertToCSV(data: Record<string, any>[], columns?: string[]): string {
  if (data.length === 0) {
    return '';
  }

  // Determinar colunas
  const cols = columns || Object.keys(data[0]);

  // Criar cabeçalho
  const header = cols.map(col => escapeCSV(col)).join(',');

  // Criar linhas
  const rows = data.map(row =>
    cols.map(col => escapeCSV(row[col])).join(',')
  );

  return [header, ...rows].join('\n');
}

/**
 * Exporta dados para arquivo CSV
 */
export function exportToCSV(options: CSVExportOptions): void {
  const { filename, data, columns } = options;

  const csv = convertToCSV(data, columns);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);

  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}.csv`);
  link.style.visibility = 'hidden';

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Exporta clientes para CSV
 */
export function exportClientesCSV(clientes: any[]): void {
  const data = clientes.map(cliente => ({
    'ID': cliente.id,
    'Nome': cliente.nome,
    'Telefone': cliente.telefone,
    'Email': cliente.email,
    'Endereço': cliente.endereco,
    'Cidade': cliente.cidade,
    'Data de Cadastro': new Date(cliente.dataCadastro).toLocaleDateString('pt-BR')
  }));

  exportToCSV({
    filename: `clientes_${new Date().toISOString().split('T')[0]}`,
    data,
    columns: ['ID', 'Nome', 'Telefone', 'Email', 'Endereço', 'Cidade', 'Data de Cadastro']
  });
}

/**
 * Exporta serviços para CSV
 */
export function exportServicosCSV(servicos: any[]): void {
  const data = servicos.map(servico => ({
    'ID': servico.id,
    'Nome': servico.nome,
    'Descrição': servico.descricao,
    'Preço (R$)': servico.preco.toFixed(2),
    'Tempo Estimado (min)': servico.tempo_estimado
  }));

  exportToCSV({
    filename: `servicos_${new Date().toISOString().split('T')[0]}`,
    data,
    columns: ['ID', 'Nome', 'Descrição', 'Preço (R$)', 'Tempo Estimado (min)']
  });
}

/**
 * Exporta ordens de serviço para CSV
 */
export function exportOrdensCSV(
  ordens: any[],
  clientes: any[],
  servicos: any[]
): void {
  const data = ordens.map(ordem => {
    const cliente = clientes.find(c => c.id === ordem.cliente_id);
    const servicosNome = ordem.servicos
      .map((s: any) => {
        const servico = servicos.find((srv: any) => srv.id === s.servico_id);
        return `${servico?.nome || 'Desconhecido'} (x${s.quantidade})`;
      })
      .join('; ');

    return {
      'ID': ordem.id,
      'Cliente': cliente?.nome || 'Desconhecido',
      'Serviços': servicosNome,
      'Status': ordem.status.replace('_', ' '),
      'Data de Agendamento': new Date(ordem.data_agendamento).toLocaleDateString('pt-BR'),
      'Valor Total (R$)': ordem.valor_total.toFixed(2),
      'Observações': ordem.observacoes
    };
  });

  exportToCSV({
    filename: `ordens_${new Date().toISOString().split('T')[0]}`,
    data,
    columns: ['ID', 'Cliente', 'Serviços', 'Status', 'Data de Agendamento', 'Valor Total (R$)', 'Observações']
  });
}

/**
 * Exporta relatório financeiro completo para CSV
 */
export function exportRelatorioFinanceiroCSV(
  ordens: any[],
  clientes: any[],
  servicos: any[]
): void {
  const ordensConluidas = ordens.filter(o => o.status === 'concluida');
  const receitaTotal = ordensConluidas.reduce((sum, o) => sum + o.valor_total, 0);
  const ticketMedio = ordensConluidas.length > 0 ? receitaTotal / ordensConluidas.length : 0;

  // Resumo geral
  const resumo = [
    {
      'Métrica': 'Receita Total',
      'Valor': `R$ ${receitaTotal.toFixed(2)}`
    },
    {
      'Métrica': 'Ticket Médio',
      'Valor': `R$ ${ticketMedio.toFixed(2)}`
    },
    {
      'Métrica': 'Ordens Concluídas',
      'Valor': ordensConluidas.length
    },
    {
      'Métrica': 'Ordens Pendentes',
      'Valor': ordens.filter(o => o.status === 'pendente').length
    },
    {
      'Métrica': 'Ordens em Progresso',
      'Valor': ordens.filter(o => o.status === 'em_progresso').length
    },
    {
      'Métrica': 'Ordens Canceladas',
      'Valor': ordens.filter(o => o.status === 'cancelada').length
    }
  ];

  const csv = convertToCSV(resumo, ['Métrica', 'Valor']) + '\n\n';

  // Receita por cliente
  const receitaPorCliente = clientes
    .map(cliente => {
      const receita = ordensConluidas
        .filter(o => o.cliente_id === cliente.id)
        .reduce((sum, o) => sum + o.valor_total, 0);
      return {
        'Cliente': cliente.nome,
        'Receita (R$)': receita.toFixed(2)
      };
    })
    .filter(c => parseFloat(c['Receita (R$)']) > 0)
    .sort((a, b) => parseFloat(b['Receita (R$)']) - parseFloat(a['Receita (R$)']));

  const csvClientes = '\nRECEITA POR CLIENTE\n' + convertToCSV(receitaPorCliente, ['Cliente', 'Receita (R$)']) + '\n\n';

  // Receita por serviço
  const receitaPorServico = servicos
    .map(servico => {
      const receita = ordensConluidas.reduce((sum, ordem) => {
        const s = ordem.servicos.find((srv: any) => srv.servico_id === servico.id);
        return sum + (s ? s.quantidade * s.preco_unitario : 0);
      }, 0);
      return {
        'Serviço': servico.nome,
        'Receita (R$)': receita.toFixed(2)
      };
    })
    .filter(s => parseFloat(s['Receita (R$)']) > 0)
    .sort((a, b) => parseFloat(b['Receita (R$)']) - parseFloat(a['Receita (R$)']));

  const csvServicos = '\nRECEITA POR SERVIÇO\n' + convertToCSV(receitaPorServico, ['Serviço', 'Receita (R$)']);

  const conteudoCompleto = csv + csvClientes + csvServicos;
  const blob = new Blob([conteudoCompleto], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);

  link.setAttribute('href', url);
  link.setAttribute('download', `relatorio_financeiro_${new Date().toISOString().split('T')[0]}.csv`);
  link.style.visibility = 'hidden';

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
