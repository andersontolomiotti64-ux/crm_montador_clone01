import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { AlertCircle } from 'lucide-react';

export interface ConflictItem {
  id: string;
  type: 'cliente' | 'ordem' | 'servico' | 'atendimento';
  localData: any;
  serverData: any;
  field?: string;
}

interface ConflictResolutionDialogProps {
  open: boolean;
  conflicts: ConflictItem[];
  onResolve: (resolution: { [key: string]: 'local' | 'server' }) => void;
  onCancel: () => void;
}

export function ConflictResolutionDialog({
  open,
  conflicts,
  onResolve,
  onCancel,
}: ConflictResolutionDialogProps) {
  const [resolution, setResolution] = useState<{ [key: string]: 'local' | 'server' }>({});

  const handleResolveConflict = (conflictId: string, choice: 'local' | 'server') => {
    setResolution(prev => ({
      ...prev,
      [conflictId]: choice,
    }));
  };

  const handleSubmit = () => {
    if (Object.keys(resolution).length === conflicts.length) {
      onResolve(resolution);
      setResolution({});
    }
  };

  const getTypeLabel = (type: string) => {
    const labels: { [key: string]: string } = {
      cliente: 'Cliente',
      ordem: 'Ordem de Serviço',
      servico: 'Serviço',
      atendimento: 'Atendimento',
    };
    return labels[type] || type;
  };

  const formatData = (data: any) => {
    if (typeof data === 'object') {
      return JSON.stringify(data, null, 2);
    }
    return String(data);
  };

  return (
    <Dialog open={open} onOpenChange={onCancel}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertCircle className="text-yellow-600" size={24} />
            Conflitos de Sincronização Detectados
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <p className="text-sm text-gray-600">
            Foram detectados {conflicts.length} conflito(s) entre os dados locais e do servidor.
            Escolha qual versão manter para cada item:
          </p>

          {conflicts.map((conflict, index) => (
            <Card key={conflict.id} className="p-4 border-yellow-200 bg-yellow-50">
              <div className="space-y-3">
                <div className="font-semibold text-sm">
                  Conflito {index + 1}: {getTypeLabel(conflict.type)}
                  {conflict.field && ` - Campo: ${conflict.field}`}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {/* Versão Local */}
                  <div className="border border-blue-200 rounded p-3 bg-blue-50">
                    <div className="font-semibold text-xs text-blue-900 mb-2">
                      Versão Local (seu dispositivo)
                    </div>
                    <pre className="text-xs overflow-auto max-h-32 text-blue-800">
                      {formatData(conflict.localData)}
                    </pre>
                    <Button
                      size="sm"
                      variant={resolution[conflict.id] === 'local' ? 'default' : 'outline'}
                      onClick={() => handleResolveConflict(conflict.id, 'local')}
                      className="mt-2 w-full"
                    >
                      {resolution[conflict.id] === 'local' ? '✓ Selecionado' : 'Usar Esta Versão'}
                    </Button>
                  </div>

                  {/* Versão do Servidor */}
                  <div className="border border-green-200 rounded p-3 bg-green-50">
                    <div className="font-semibold text-xs text-green-900 mb-2">
                      Versão do Servidor
                    </div>
                    <pre className="text-xs overflow-auto max-h-32 text-green-800">
                      {formatData(conflict.serverData)}
                    </pre>
                    <Button
                      size="sm"
                      variant={resolution[conflict.id] === 'server' ? 'default' : 'outline'}
                      onClick={() => handleResolveConflict(conflict.id, 'server')}
                      className="mt-2 w-full"
                    >
                      {resolution[conflict.id] === 'server' ? '✓ Selecionado' : 'Usar Esta Versão'}
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onCancel}>
            Cancelar
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={Object.keys(resolution).length !== conflicts.length}
          >
            Resolver Conflitos
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
