import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Menu, X, Home, Users, Wrench, FileText, BarChart3, Download, LogOut, User, Shield, Wifi, WifiOff, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger, DropdownMenuItem } from '@/components/ui/dropdown-menu';
import { useAutoSync } from '@/hooks/useAutoSync';

export function Layout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [location] = useLocation();
  const { usuarioLogado, logout, isAdmin } = useAuth();
  
  // Iniciar sincronização automática
  try {
    useAutoSync();
  } catch (error) {
    // Ignorar erro se CRMContext não estiver disponível
  }

  const navItems = [
    { href: '/', label: 'Dashboard', icon: Home },
    { href: '/atendimentos', label: 'Atendimentos', icon: Users },
    { href: '/clientes', label: 'Clientes', icon: Users },
    { href: '/servicos', label: 'Serviços', icon: Wrench },
    { href: '/gerenciar-servicos', label: 'Gerenciar Serviços', icon: Wrench },
    { href: '/ordens', label: 'Ordens de Serviço', icon: FileText },
    { href: '/agenda', label: 'Agenda', icon: Calendar },
    { href: '/relatorios', label: 'Relatórios', icon: BarChart3 },
    ...(isAdmin ? [{ href: '/admin', label: 'Administração', icon: Shield }] : [])
  ];

  // Detectar mudanças de tamanho de tela
  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (mobile) {
        setSidebarOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Detectar status online/offline
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const isActive = (href: string) => location === href;

  const handleInstallPWA = async () => {
    const deferredPrompt = (window as any).deferredPrompt;
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      console.log(`User response to the install prompt: ${outcome}`);
      (window as any).deferredPrompt = null;
    }
  };

  const handleLogout = () => {
    logout();
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="flex h-screen bg-background flex-col">
      {/* Indicador de Status Online/Offline */}
      {!isOnline && (
        <div className="bg-yellow-100 border-b border-yellow-300 text-yellow-800 px-4 py-2 flex items-center gap-2 text-sm">
          <WifiOff size={16} />
          <span className="hidden sm:inline">Modo offline - Alterações serão sincronizadas quando conectado</span>
          <span className="sm:hidden">Modo offline</span>
        </div>
      )}

      {/* Header Mobile/Desktop */}
      <header className="bg-sidebar text-sidebar-foreground border-b border-sidebar-border px-4 py-3 flex items-center justify-between flex-shrink-0 md:hidden">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-sidebar-primary rounded flex items-center justify-center">
            <span className="text-sidebar-primary-foreground font-bold text-sm">M</span>
          </div>
          <span className="font-bold text-sm">CRM Móveis</span>
        </div>
        <button
          onClick={toggleSidebar}
          className="p-2 hover:bg-sidebar-accent/10 rounded transition-colors"
        >
          {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </header>

      {/* Overlay para mobile */}
      {isMobile && sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar - Desktop sempre visível, Mobile como drawer */}
        <aside
          className={`${
            isMobile
              ? `fixed left-0 top-0 h-full w-64 z-40 transition-transform duration-300 ${
                  sidebarOpen ? 'translate-x-0' : '-translate-x-full'
                }`
              : 'relative w-64'
          } bg-sidebar text-sidebar-foreground flex flex-col border-r border-sidebar-border overflow-y-auto`}
          style={isMobile ? { marginTop: !isOnline ? '48px' : '0' } : {}}
        >
          {/* Header do Sidebar - Desktop */}
          {!isMobile && (
            <div className="p-4 border-b border-sidebar-border flex items-center justify-between flex-shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-sidebar-primary rounded flex items-center justify-center flex-shrink-0">
                  <span className="text-sidebar-primary-foreground font-bold text-lg">M</span>
                </div>
                <h1 className="font-bold text-lg truncate">CRM Móveis</h1>
              </div>
            </div>
          )}

          {/* Navegação */}
          <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
            {navItems.map(({ href, label, icon: Icon }) => (
              <Link key={href} href={href}>
                <a
                  className={`flex items-center gap-3 px-4 py-3 rounded transition-colors whitespace-nowrap ${
                    isActive(href)
                      ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                      : 'text-sidebar-foreground hover:bg-sidebar-accent/10'
                  }`}
                  onClick={() => isMobile && setSidebarOpen(false)}
                >
                  <Icon size={20} className="flex-shrink-0" />
                  <span className="font-medium truncate">{label}</span>
                </a>
              </Link>
            ))}
          </nav>

          {/* Seção de Usuário e Ações */}
          <div className="p-4 border-t border-sidebar-border space-y-3 flex-shrink-0">
            {/* Informação do Usuário */}
            {usuarioLogado && (
              <div className="bg-sidebar-accent/10 rounded p-3 min-w-0">
                <p className="text-xs text-sidebar-foreground/70 mb-1">Logado como:</p>
                <p className="text-sm font-semibold text-sidebar-foreground truncate">{usuarioLogado.nome}</p>
                <p className="text-xs text-sidebar-foreground/60 truncate">{usuarioLogado.email}</p>
              </div>
            )}

            {/* Botões de Ação */}
            <div className="space-y-2">
              <Button
                onClick={handleInstallPWA}
                variant="outline"
                size="sm"
                className="w-full"
                title="Instalar aplicativo"
              >
                <Download size={18} className="flex-shrink-0" />
                <span className="ml-2">Instalar</span>
              </Button>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full"
                    title="Menu do usuário"
                  >
                    <User size={18} className="flex-shrink-0" />
                    <span className="ml-2">Conta</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem onClick={handleLogout} className="text-destructive">
                    <LogOut size={16} className="mr-2" />
                    Sair da Conta
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </aside>

        {/* Conteúdo Principal */}
        <main className="flex-1 overflow-auto w-full">
          <div className="p-4 md:p-6 max-w-7xl mx-auto w-full">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
