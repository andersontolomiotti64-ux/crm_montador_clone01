import { useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';

/**
 * Componente que inicializa o aplicativo com dados de teste
 * Cria usuários de teste se não houver nenhum usuário registrado
 */
export function InitializeApp() {
  const { obterTodosUsuarios, registrar, alterarRoleUsuario } = useAuth();

  useEffect(() => {
    const usuarios = obterTodosUsuarios();
    
    // Se não houver usuários, criar usuário admin e usuário teste
    if (usuarios.length === 0) {
      // Criar usuário admin
      registrar('Administrador', 'admin@example.com', '123456');
      
      // Criar usuário teste
      registrar('Usuário Teste', 'teste@example.com', '123456');
      
      // Aguardar um pouco para os usuários serem criados
      setTimeout(() => {
        const usuariosAtualizados = obterTodosUsuarios();
        const admin = usuariosAtualizados.find(u => u.email === 'admin@example.com');
        if (admin) {
          alterarRoleUsuario(admin.id, 'admin');
        }
      }, 100);
    }
  }, []);

  return null;
}
