import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { History, Trash2, CheckCircle, XCircle, Clock } from 'lucide-react';
import { useSyncHistory } from '@/hooks/useSyncHistory';
import { format } from 'date-fns';
import { pt } from 'date-fns/locale';

export function SyncHistoryPanel() {
  const { history, clearHistory, getLastSync, getSuccessRate, getTotalItemsSynced, getTotalConflictsResolved } = useSyncHistory();
  const [open, setOpen] = useState(false);

  const getTypeLabel = (type: string) => {
    const labels: { [key: string]: string } = {
      upload: '↑ Envio',
      download: '↓ Download',
      conflict_resolution: '⚔️ Conflito Resolvido',
    };
    return labels[type] || type;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="text-green-600" size={16} />;
      case 'failed':
        return <XCircle className="text-red-600" size={16} />;
      case 'pending':
        return <Clock className="text-yellow-600 animate-spin" size={16} />;
      default:
        return null;
    }
  };

  const lastSync = getLastSync();
  const successRate = getSuccessRate();
  const totalItems = getTotalItemsSynced();
  const totalConflicts = getTotalConflictsResolved();

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className="gap-2"
          title="Ver histórico de sincronizações"
        >
          <History size={16} />
          <span className="hidden sm:inline">Histórico</span>
        </Button>
      </DialogTrigger>

      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <History size={24} />
            Histórico de Sincronizações
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Estatísticas */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <Card className="p-3 text-center">
              <div className="text-2xl font-bold text-blue-600">{successRate}%</div>
              <div className="text-xs text-gray-600">Taxa de Sucesso</div>
            </Card>
            <Card className="p-3 text-center">
              <div className="text-2xl font-bold text-green-600">{totalItems}</div>
              <div className="text-xs text-gray-600">Itens Sincronizados</div>
            </Card>
            <Card className="p-3 text-center">
              <div className="text-2xl font-bold text-yellow-600">{totalConflicts}</div>
              <div className="text-xs text-gray-600">Conflitos Resolvidos</div>
            </Card>
            <Card className="p-3 text-center">
              <div className="text-sm font-bold text-purple-600">
                {lastSync ? format(lastSync, 'HH:mm', { locale: pt }) : 'Nunca'}
              </div>
              <div className="text-xs text-gray-600">Última Sincronização</div>
            </Card>
          </div>

          {/* Histórico */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold text-sm">Últimas Sincronizações ({history.length})</h3>
              {history.length > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    clearHistory();
                    setOpen(false);
                  }}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 size={14} />
                  Limpar
                </Button>
              )}
            </div>

            {history.length === 0 ? (
              <Card className="p-4 text-center text-gray-500">
                <p>Nenhuma sincronização registrada ainda</p>
              </Card>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {history.map((entry) => (
                  <Card key={entry.id} className="p-3 border-l-4" style={{
                    borderLeftColor: entry.status === 'success' ? '#10b981' : entry.status === 'failed' ? '#ef4444' : '#f59e0b'
                  }}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          {getStatusIcon(entry.status)}
                          <span className="font-semibold text-sm">{getTypeLabel(entry.type)}</span>
                          <span className="text-xs text-gray-500">
                            {format(new Date(entry.timestamp), 'dd/MM/yyyy HH:mm:ss', { locale: pt })}
                          </span>
                        </div>

                        <div className="text-xs text-gray-600 space-y-1">
                          <p>
                            <span className="font-medium">Itens:</span> {entry.itemsCount}
                            {entry.conflictsResolved !== undefined && entry.conflictsResolved > 0 && (
                              <span className="ml-2">
                                <span className="font-medium">Conflitos:</span> {entry.conflictsResolved}
                              </span>
                            )}
                          </p>

                          {entry.resolutions && Object.keys(entry.resolutions).length > 0 && (
                            <details className="cursor-pointer">
                              <summary className="font-medium hover:text-gray-700">
                                Ver resoluções ({Object.keys(entry.resolutions).length})
                              </summary>
                              <div className="mt-1 pl-2 border-l-2 border-gray-300 space-y-1">
                                {Object.entries(entry.resolutions).map(([key, value]) => (
                                  <div key={key} className="text-xs">
                                    <span className="font-mono text-gray-700">{key}:</span>
                                    <span className={`ml-1 px-1 rounded ${value === 'local' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'}`}>
                                      {value === 'local' ? 'Local' : 'Servidor'}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </details>
                          )}

                          {entry.errorMessage && (
                            <p className="text-red-600 font-medium">
                              Erro: {entry.errorMessage}
                            </p>
                          )}

                          <p className="text-gray-500">
                            Duração: {entry.duration}ms
                          </p>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
