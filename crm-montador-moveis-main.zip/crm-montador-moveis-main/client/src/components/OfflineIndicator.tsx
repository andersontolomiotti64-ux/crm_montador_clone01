import { useEffect, useState } from 'react';
import { Wifi, WifiOff, RefreshCw, Cloud, CloudOff } from 'lucide-react';
import { useOfflineSync } from '@/hooks/useOfflineSync';
import { useSyncData } from '@/hooks/useSyncData';
import { useCRM } from '@/contexts/CRMContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { ConflictResolutionDialog } from './ConflictResolutionDialog';
import { useConflictDetection } from '@/hooks/useConflictDetection';
import { SyncHistoryPanel } from './SyncHistoryPanel';
import { useSyncHistory } from '@/hooks/useSyncHistory';
import { toast } from 'sonner';

export function OfflineIndicator() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const { pendingCount, isSyncing, syncWhenOnline } = useOfflineSync();
  const { syncToServer, downloadFromServer, syncStatus } = useSyncData();
  const { usuarioLogado } = useAuth();
  const [showSyncMenu, setShowSyncMenu] = useState(false);
  const { detectConflicts, resolveConflicts, conflicts } = useConflictDetection();
  const [showConflictDialog, setShowConflictDialog] = useState(false);
  const [pendingConflictResolution, setPendingConflictResolution] = useState<any>(null);
  const { addEntry, updateEntry } = useSyncHistory();
  
  // Usar useCRM apenas se houver usuário autenticado
  let crmData: any = { clientes: [], ordens: [], servicos: [], atendimentos: [] };
  let sincronizarDados: any = () => {};
  try {
    if (usuarioLogado) {
      const crm = useCRM();
      crmData = { clientes: crm.clientes, ordens: crm.ordens, servicos: crm.servicos, atendimentos: crm.atendimentos };
      sincronizarDados = crm.sincronizarDados;
    }
  } catch (error) {
    // Ignorar erro se useCRM não estiver disponível
  }
  
  const { clientes, ordens, servicos, atendimentos } = crmData;

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
    };

    const handleOffline = () => {
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleUploadData = async () => {
    if (!usuarioLogado) return;
    
    const startTime = Date.now();
    const entryId = addEntry({
      timestamp: Date.now(),
      type: 'upload',
      status: 'pending',
      itemsCount: crmData.clientes.length + crmData.ordens.length + crmData.servicos.length + crmData.atendimentos.length,
      duration: 0,
    }).id;
    
    try {
      const data = {
        clientes: crmData.clientes,
        ordens: crmData.ordens,
        servicos: crmData.servicos,
        atendimentos: crmData.atendimentos,
      };

      await syncToServer(usuarioLogado.id, data);
      
      const duration = Date.now() - startTime;
      updateEntry(entryId, {
        status: 'success',
        duration,
      });
      
      toast.success('Dados enviados com sucesso!');
    } catch (error) {
      const duration = Date.now() - startTime;
      updateEntry(entryId, {
        status: 'failed',
        duration,
        errorMessage: error instanceof Error ? error.message : 'Erro desconhecido',
      });
      
      toast.error('Erro ao enviar dados');
    }
  };

  const handleDownloadData = async () => {
    if (!usuarioLogado) return;
    
    const startTime = Date.now();
    const entryId = addEntry({
      timestamp: Date.now(),
      type: 'download',
      status: 'pending',
      itemsCount: 0,
      duration: 0,
    }).id;
    
    try {
      const data = await downloadFromServer(usuarioLogado.id);
      if (data) {
        // Detectar conflitos
        const detectedConflicts = detectConflicts(crmData, data);
        
        if (detectedConflicts.length > 0) {
          // Mostrar dialog de resolução de conflitos
          setPendingConflictResolution(data);
          setShowConflictDialog(true);
          
          updateEntry(entryId, {
            status: 'pending',
            itemsCount: (data.clientes?.length || 0) + (data.ordens?.length || 0) + (data.servicos?.length || 0) + (data.atendimentos?.length || 0),
            conflictsResolved: detectedConflicts.length,
          });
          
          toast.info(`${detectedConflicts.length} conflito(s) detectado(s). Resolva-os para continuar.`);
        } else {
          // Sem conflitos, sincronizar diretamente
          sincronizarDados(data);
          
          const duration = Date.now() - startTime;
          updateEntry(entryId, {
            status: 'success',
            itemsCount: (data.clientes?.length || 0) + (data.ordens?.length || 0) + (data.servicos?.length || 0) + (data.atendimentos?.length || 0),
            duration,
          });
          
          toast.success('Dados sincronizados com sucesso!');
          console.log('Dados sincronizados com sucesso');
        }
      }
    } catch (error) {
      const duration = Date.now() - startTime;
      updateEntry(entryId, {
        status: 'failed',
        duration,
        errorMessage: error instanceof Error ? error.message : 'Erro desconhecido',
      });
      
      toast.error('Erro ao baixar dados');
    }
  };

  const handleResolveConflicts = (resolution: { [key: string]: 'local' | 'server' }) => {
    if (pendingConflictResolution) {
      const startTime = Date.now();
      const entryId = addEntry({
        timestamp: Date.now(),
        type: 'conflict_resolution',
        status: 'success',
        itemsCount: Object.keys(resolution).length,
        conflictsResolved: Object.keys(resolution).length,
        resolutions: resolution,
        duration: 0,
      }).id;
      
      const resolvedData = resolveConflicts(crmData, pendingConflictResolution, resolution);
      sincronizarDados(resolvedData);
      
      const duration = Date.now() - startTime;
      updateEntry(entryId, { duration });
      
      setShowConflictDialog(false);
      setPendingConflictResolution(null);
      toast.success('Conflitos resolvidos e dados sincronizados!');
      console.log('Conflitos resolvidos e dados sincronizados');
    }
  };

  if (isOnline && pendingCount === 0 && !syncStatus.isSyncing && !showConflictDialog) {
    return null;
  }

  if (!isOnline) {
    return (
      <div className="fixed bottom-4 right-4 bg-yellow-100 border border-yellow-300 text-yellow-800 px-4 py-3 rounded-lg shadow-lg flex items-center gap-2 max-w-sm z-50">
        <WifiOff size={20} className="flex-shrink-0" />
        <div className="flex-1">
          <p className="font-semibold text-sm">Modo Offline</p>
          <p className="text-xs">Alterações serão sincronizadas quando conectado</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="fixed bottom-4 right-4 z-50">
        <div className="bg-blue-100 border border-blue-300 text-blue-800 px-4 py-3 rounded-lg shadow-lg flex items-center gap-3 max-w-sm">
          {syncStatus.isSyncing || isSyncing ? (
            <RefreshCw size={20} className="flex-shrink-0 animate-spin" />
          ) : (
            <Cloud size={20} className="flex-shrink-0" />
          )}
          <div className="flex-1">
            <p className="font-semibold text-sm">
              {syncStatus.isSyncing || isSyncing ? 'Sincronizando...' : 'Sincronização Manual'}
            </p>
            {!syncStatus.isSyncing && !isSyncing && (
              <p className="text-xs text-blue-700 mt-1">
                {pendingCount > 0 ? `${pendingCount} alteração${pendingCount > 1 ? 's' : ''} pendente${pendingCount > 1 ? 's' : ''}` : 'Dados sincronizados'}
              </p>
            )}
          </div>
          
          {!syncStatus.isSyncing && !isSyncing && (
            <div className="flex gap-2 ml-2">
              <Button
                size="sm"
                variant="outline"
                onClick={handleUploadData}
                disabled={syncStatus.isSyncing}
                className="text-xs"
              >
                ↑ Enviar
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={handleDownloadData}
                disabled={syncStatus.isSyncing}
                className="text-xs"
              >
                ↓ Baixar
              </Button>
              <SyncHistoryPanel />
            </div>
          )}
        </div>
      </div>

      {/* Dialog de Resolução de Conflitos */}
      <ConflictResolutionDialog
        open={showConflictDialog}
        conflicts={conflicts}
        onResolve={handleResolveConflicts}
        onCancel={() => {
          setShowConflictDialog(false);
          setPendingConflictResolution(null);
        }}
      />
    </>
  );
}
