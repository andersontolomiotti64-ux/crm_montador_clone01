import { createContext, useContext, useState, useEffect } from 'react';

export type UserRole = 'admin' | 'user';

export interface Usuario {
  id: string;
  nome: string;
  email: string;
  senha_hash: string;
  data_criacao: string;
  role: UserRole;
}

export interface TokenReset {
  id: string;
  usuario_id: string;
  token: string;
  data_criacao: string;
  data_expiracao: string;
  utilizado: boolean;
}

interface AuthContextType {
  usuarioLogado: Usuario | null;
  isAutenticado: boolean;
  isAdmin: boolean;
  login: (email: string, senha: string) => boolean;
  registrar: (nome: string, email: string, senha: string) => boolean;
  logout: () => void;
  obterTodosUsuarios: () => Usuario[];
  atualizarUsuario: (id: string, dados: Partial<Usuario>) => boolean;
  deletarUsuario: (id: string) => boolean;
  alterarRoleUsuario: (id: string, role: UserRole) => boolean;
  solicitarRecuperacaoSenha: (email: string) => { sucesso: boolean; token?: string; mensagem: string };
  resetarSenha: (token: string, novaSenha: string) => boolean;
  validarTokenReset: (token: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Função simples de hash para senha (não é criptografia real, apenas para demo)
// Em produção, use bcrypt ou similar no backend
function hashSenha(senha: string): string {
  let hash = 0;
  for (let i = 0; i < senha.length; i++) {
    const char = senha.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Converter para inteiro 32-bit
  }
  return Math.abs(hash).toString(16);
}

// Função para simular envio de email (em produção, integrar com serviço real)
export function enviarEmailRecuperacao(email: string, token: string): void {
  // Simular envio de email
  const linkRecuperacao = `${window.location.origin}/reset-senha?token=${token}`;
  console.log(`Email de recuperação enviado para ${email}`);
  console.log(`Link: ${linkRecuperacao}`);
  // Em produção, fazer requisição para backend que envia email real
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [usuarioLogado, setUsuarioLogado] = useState<Usuario | null>(null);
  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [tokensReset, setTokensReset] = useState<TokenReset[]>([]);

  // Carregar dados do localStorage ao iniciar
  useEffect(() => {
    const usuariosSalvos = localStorage.getItem('crm_usuarios');
    const usuarioLogadoSalvo = localStorage.getItem('crm_usuario_logado');
    const tokensResetSalvos = localStorage.getItem('crm_tokens_reset');

    if (usuariosSalvos) {
      try {
        setUsuarios(JSON.parse(usuariosSalvos));
      } catch (e) {
        console.error('Erro ao carregar usuários:', e);
      }
    }

    if (usuarioLogadoSalvo) {
      try {
        setUsuarioLogado(JSON.parse(usuarioLogadoSalvo));
      } catch (e) {
        console.error('Erro ao carregar usuário logado:', e);
      }
    }

    if (tokensResetSalvos) {
      try {
        setTokensReset(JSON.parse(tokensResetSalvos));
      } catch (e) {
        console.error('Erro ao carregar tokens:', e);
      }
    }
  }, []);

  // Salvar usuários no localStorage
  useEffect(() => {
    localStorage.setItem('crm_usuarios', JSON.stringify(usuarios));
  }, [usuarios]);

  // Salvar usuário logado no localStorage
  useEffect(() => {
    if (usuarioLogado) {
      localStorage.setItem('crm_usuario_logado', JSON.stringify(usuarioLogado));
    } else {
      localStorage.removeItem('crm_usuario_logado');
    }
  }, [usuarioLogado]);

  // Salvar tokens de reset no localStorage
  useEffect(() => {
    localStorage.setItem('crm_tokens_reset', JSON.stringify(tokensReset));
  }, [tokensReset]);

  // Sincronizar dados entre abas/dispositivos
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'crm_usuarios' && e.newValue) {
        try {
          setUsuarios(JSON.parse(e.newValue));
        } catch (err) {
          console.error('Erro ao sincronizar usuários:', err);
        }
      }
      if (e.key === 'crm_usuario_logado') {
        if (e.newValue) {
          try {
            setUsuarioLogado(JSON.parse(e.newValue));
          } catch (err) {
            console.error('Erro ao sincronizar usuário logado:', err);
          }
        } else {
          setUsuarioLogado(null);
        }
      }
      if (e.key === 'crm_tokens_reset' && e.newValue) {
        try {
          setTokensReset(JSON.parse(e.newValue));
        } catch (err) {
          console.error('Erro ao sincronizar tokens:', err);
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const login = (email: string, senha: string): boolean => {
    // Recarregar usuários do localStorage para garantir dados atualizados
    const usuariosSalvos = localStorage.getItem('crm_usuarios');
    let usuariosAtuais = usuarios;
    
    if (usuariosSalvos) {
      try {
        usuariosAtuais = JSON.parse(usuariosSalvos);
        setUsuarios(usuariosAtuais);
      } catch (e) {
        console.error('Erro ao carregar usuários:', e);
      }
    }

    const usuario = usuariosAtuais.find(u => u.email === email);

    if (!usuario) {
      console.error('Usuário não encontrado:', email);
      return false;
    }

    const senhaHash = hashSenha(senha);
    if (usuario.senha_hash !== senhaHash) {
      console.error('Senha incorreta para:', email);
      return false;
    }

    setUsuarioLogado(usuario);
    return true;
  };

  const registrar = (nome: string, email: string, senha: string): boolean => {
    // Recarregar usuários do localStorage para garantir dados atualizados
    const usuariosSalvos = localStorage.getItem('crm_usuarios');
    let usuariosAtuais = usuarios;
    
    if (usuariosSalvos) {
      try {
        usuariosAtuais = JSON.parse(usuariosSalvos);
        setUsuarios(usuariosAtuais);
      } catch (e) {
        console.error('Erro ao carregar usuários:', e);
      }
    }

    // Verificar se email já existe
    if (usuariosAtuais.some(u => u.email === email)) {
      return false;
    }

    // Validações básicas
    if (!nome.trim() || !email.trim() || !senha.trim()) {
      return false;
    }

    if (senha.length < 6) {
      return false;
    }

    const novoUsuario: Usuario = {
      id: Date.now().toString(),
      nome,
      email,
      senha_hash: hashSenha(senha),
      data_criacao: new Date().toISOString(),
      role: 'user'
    };

    const usuariosAtualizados = [...usuariosAtuais, novoUsuario];
    setUsuarios(usuariosAtualizados);
    setUsuarioLogado(novoUsuario);
    return true;
  };

  const logout = () => {
    setUsuarioLogado(null);
  };

  const obterTodosUsuarios = () => {
    return usuarios;
  };

  const atualizarUsuario = (id: string, dados: Partial<Usuario>): boolean => {
    const usuariosAtualizados = usuarios.map(u =>
      u.id === id
        ? { ...u, ...dados, id: u.id, senha_hash: u.senha_hash } // Não permitir alterar ID ou senha aqui
        : u
    );

    setUsuarios(usuariosAtualizados);

    // Atualizar usuário logado se for ele mesmo
    if (usuarioLogado?.id === id) {
      const usuarioAtualizado = usuariosAtualizados.find(u => u.id === id);
      if (usuarioAtualizado) {
        setUsuarioLogado(usuarioAtualizado);
      }
    }

    return true;
  };

  const deletarUsuario = (id: string): boolean => {
    // Não permitir deletar o próprio usuário
    if (usuarioLogado?.id === id) {
      return false;
    }

    const usuariosAtualizados = usuarios.filter(u => u.id !== id);
    setUsuarios(usuariosAtualizados);
    return true;
  };

  const alterarRoleUsuario = (id: string, role: UserRole): boolean => {
    // Não permitir alterar o próprio role
    if (usuarioLogado?.id === id) {
      return false;
    }

    return atualizarUsuario(id, { role });
  };

  // Gerar token aleatório
  const gerarToken = (): string => {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  };

  const solicitarRecuperacaoSenha = (email: string): { sucesso: boolean; token?: string; mensagem: string } => {
    const usuario = usuarios.find(u => u.email === email);

    if (!usuario) {
      // Não revelar se o email existe ou não (segurança)
      return {
        sucesso: true,
        mensagem: 'Se o email existe em nossa base, você receberá um link de recuperação'
      };
    }

    // Remover tokens antigos do mesmo usuário
    const tokensAntigos = tokensReset.filter(t => t.usuario_id !== usuario.id);

    // Criar novo token
    const novoToken = gerarToken();
    const agora = new Date();
    const expiracao = new Date(agora.getTime() + 24 * 60 * 60 * 1000); // 24 horas

    const tokenReset: TokenReset = {
      id: Date.now().toString(),
      usuario_id: usuario.id,
      token: novoToken,
      data_criacao: agora.toISOString(),
      data_expiracao: expiracao.toISOString(),
      utilizado: false
    };

    setTokensReset([...tokensAntigos, tokenReset]);

    // Simular envio de email
    enviarEmailRecuperacao(email, novoToken);

    return {
      sucesso: true,
      token: novoToken,
      mensagem: 'Link de recuperação gerado com sucesso'
    };
  };

  const validarTokenReset = (token: string): boolean => {
    const tokenReset = tokensReset.find(t => t.token === token && !t.utilizado);

    if (!tokenReset) {
      return false;
    }

    // Verificar se expirou
    const agora = new Date();
    const dataExpiracao = new Date(tokenReset.data_expiracao);

    if (agora > dataExpiracao) {
      return false;
    }

    return true;
  };

  const resetarSenha = (token: string, novaSenha: string): boolean => {
    if (!validarTokenReset(token)) {
      return false;
    }

    if (!novaSenha.trim() || novaSenha.length < 6) {
      return false;
    }

    const tokenReset = tokensReset.find(t => t.token === token && !t.utilizado);
    if (!tokenReset) {
      return false;
    }

    // Atualizar senha do usuário
    const usuariosAtualizados = usuarios.map(u =>
      u.id === tokenReset.usuario_id
        ? { ...u, senha_hash: hashSenha(novaSenha) }
        : u
    );

    setUsuarios(usuariosAtualizados);

    // Marcar token como utilizado
    const tokensAtualizados = tokensReset.map(t =>
      t.id === tokenReset.id
        ? { ...t, utilizado: true }
        : t
    );

    setTokensReset(tokensAtualizados);

    // Se for o usuário logado, atualizar também
    if (usuarioLogado?.id === tokenReset.usuario_id) {
      const usuarioAtualizado = usuariosAtualizados.find(u => u.id === tokenReset.usuario_id);
      if (usuarioAtualizado) {
        setUsuarioLogado(usuarioAtualizado);
      }
    }

    return true;
  };

  const value: AuthContextType = {
    usuarioLogado,
    isAutenticado: !!usuarioLogado,
    isAdmin: usuarioLogado?.role === 'admin',
    login,
    registrar,
    logout,
    obterTodosUsuarios,
    atualizarUsuario,
    deletarUsuario,
    alterarRoleUsuario,
    solicitarRecuperacaoSenha,
    resetarSenha,
    validarTokenReset
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth deve ser usado dentro de AuthProvider');
  }
  return context;
}
