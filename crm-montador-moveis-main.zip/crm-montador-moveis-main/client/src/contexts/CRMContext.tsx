import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { useOfflineSync } from '@/hooks/useOfflineSync';

export interface Atendimento {
  id: string;
  descricao: string;
  data_agendamento: string;
  status: 'pendente' | 'confirmado' | 'concluido' | 'cancelado';
  cliente_id?: string;
  data_criacao: string;
}

export interface Cliente {
  id: string;
  nome: string;
  email: string;
  telefone: string;
  endereco: string;
  dataCadastro: string;
}

export interface Servico {
  id: string;
  nome: string;
  descricao: string;
  valor?: number;
  preco?: number;
  tempo_estimado?: number;
}

export interface OrdemServico {
  id: string;
  cliente_id: string;
  data_agendamento: string;
  descricao: string;
  status: 'pendente' | 'em_progresso' | 'concluida' | 'cancelada';
  valor_total: number;
  servicos: Servico[];
  forma_pagamento?: 'dinheiro' | 'pix' | 'cartao' | 'transferencia' | 'outro';
  status_pagamento?: 'pendente' | 'pago' | 'parcial';
  descricao_pagamento?: string;
  data_criacao: string;
}

export interface CRMContextType {
  atendimentos: Atendimento[];
  clientes: Cliente[];
  servicos: Servico[];
  ordens: OrdemServico[];
  
  // Atendimentos
  adicionarAtendimento: (atendimento: Omit<Atendimento, 'id' | 'data_criacao'>) => void;
  atualizarAtendimento: (id: string, atendimento: Partial<Atendimento>) => void;
  deletarAtendimento: (id: string) => void;
  obterAtendimentosPorStatus: (status: Atendimento['status']) => Atendimento[];
  
  // Clientes
  adicionarCliente: (cliente: Omit<Cliente, 'id' | 'dataCadastro'>) => void;
  atualizarCliente: (id: string, cliente: Partial<Cliente>) => void;
  deletarCliente: (id: string) => void;
  
  // Serviços
  adicionarServico: (servico: Omit<Servico, 'id'>) => void;
  atualizarServico: (id: string, servico: Partial<Servico>) => void;
  deletarServico: (id: string) => void;
  
  // Ordens
  adicionarOrdem: (ordem: Omit<OrdemServico, 'id' | 'data_criacao'>) => void;
  atualizarOrdem: (id: string, ordem: Partial<OrdemServico>) => void;
  deletarOrdem: (id: string) => void;
  obterOrdensPorCliente: (cliente_id: string) => OrdemServico[];
  obterOrdensPorStatus: (status: OrdemServico['status']) => OrdemServico[];
  converterAtendimentoEmOrdem: (atendimentoId: string) => { sucesso: boolean; ordemId?: string; mensagem: string };
  obterMetricasCliente: (cliente_id: string) => { total_servicos: number; valor_total: number; ultima_data: string | null };
  
  // Sincronização
  sincronizarDados: (dados: { clientes: Cliente[]; ordens: OrdemServico[]; servicos: Servico[]; atendimentos: Atendimento[] }) => void;
}

const CRMContext = createContext<CRMContextType | undefined>(undefined);

// Dados iniciais de exemplo
const dadosIniciais = {
  atendimentos: [] as Atendimento[],
  clientes: [] as Cliente[],
  servicos: [] as Servico[],
  ordens: [] as OrdemServico[],
};

export function CRMProvider({ children }: { children: React.ReactNode }) {
  const { usuarioLogado } = useAuth();
  const { addToQueue } = useOfflineSync();
  
  const [atendimentos, setAtendimentos] = useState<Atendimento[]>(dadosIniciais.atendimentos);
  const [clientes, setClientes] = useState<Cliente[]>(dadosIniciais.clientes);
  const [servicos, setServicos] = useState<Servico[]>(dadosIniciais.servicos);
  const [ordens, setOrdens] = useState<OrdemServico[]>(dadosIniciais.ordens);

  // Carregar dados do localStorage ao iniciar
  useEffect(() => {
    if (!usuarioLogado) return;

    const key = `crm_data_${usuarioLogado.id}`;
    const dados = localStorage.getItem(key);
    if (dados) {
      try {
        const parsed = JSON.parse(dados);
        setAtendimentos(parsed.atendimentos || []);
        setClientes(parsed.clientes || []);
        setServicos(parsed.servicos || []);
        setOrdens(parsed.ordens || []);
      } catch (error) {
        console.error('Erro ao carregar dados do localStorage:', error);
      }
    }
  }, [usuarioLogado]);

  // Salvar dados no localStorage sempre que mudarem
  useEffect(() => {
    if (!usuarioLogado) return;

    const key = `crm_data_${usuarioLogado.id}`;
    const dados = { atendimentos, clientes, servicos, ordens };
    localStorage.setItem(key, JSON.stringify(dados));
  }, [atendimentos, clientes, servicos, ordens, usuarioLogado]);

  // Atendimentos
  const adicionarAtendimento = (atendimento: Omit<Atendimento, 'id' | 'data_criacao'>) => {
    const novoAtendimento: Atendimento = {
      ...atendimento,
      id: Date.now().toString(),
      data_criacao: new Date().toISOString(),
    };
    setAtendimentos([...atendimentos, novoAtendimento]);
    addToQueue('atendimento', 'add', novoAtendimento);
  };

  const atualizarAtendimento = (id: string, atendimento: Partial<Atendimento>) => {
    setAtendimentos(atendimentos.map(a => a.id === id ? { ...a, ...atendimento } : a));
    addToQueue('atendimento', 'update', { id, ...atendimento });
  };

  const deletarAtendimento = (id: string) => {
    setAtendimentos(atendimentos.filter(a => a.id !== id));
    addToQueue('atendimento', 'delete', { id });
  };

  const obterAtendimentosPorStatus = (status: Atendimento['status']) => {
    return atendimentos.filter(a => a.status === status);
  };

  // Clientes
  const adicionarCliente = (cliente: Omit<Cliente, 'id' | 'dataCadastro'>) => {
    const novoCliente: Cliente = {
      ...cliente,
      id: Date.now().toString(),
      dataCadastro: new Date().toISOString(),
    };
    setClientes([...clientes, novoCliente]);
    addToQueue('cliente', 'add', novoCliente);
  };

  const atualizarCliente = (id: string, cliente: Partial<Cliente>) => {
    setClientes(clientes.map(c => c.id === id ? { ...c, ...cliente } : c));
    addToQueue('cliente', 'update', { id, ...cliente });
  };

  const deletarCliente = (id: string) => {
    setClientes(clientes.filter(c => c.id !== id));
    addToQueue('cliente', 'delete', { id });
  };

  // Serviços
  const adicionarServico = (servico: Omit<Servico, 'id'>) => {
    const novoServico: Servico = {
      ...servico,
      id: Date.now().toString(),
    };
    setServicos([...servicos, novoServico]);
    addToQueue('servico', 'add', novoServico);
  };

  const atualizarServico = (id: string, servico: Partial<Servico>) => {
    setServicos(servicos.map(s => s.id === id ? { ...s, ...servico } : s));
    addToQueue('servico', 'update', { id, ...servico });
  };

  const deletarServico = (id: string) => {
    setServicos(servicos.filter(s => s.id !== id));
    addToQueue('servico', 'delete', { id });
  };

  // Ordens
  const adicionarOrdem = (ordem: Omit<OrdemServico, 'id' | 'data_criacao'>) => {
    const novaOrdem: OrdemServico = {
      ...ordem,
      id: Date.now().toString(),
      data_criacao: new Date().toISOString(),
    };
    setOrdens([...ordens, novaOrdem]);
    addToQueue('ordem', 'add', novaOrdem);
  };

  const atualizarOrdem = (id: string, ordem: Partial<OrdemServico>) => {
    setOrdens(ordens.map(o => o.id === id ? { ...o, ...ordem } : o));
    addToQueue('ordem', 'update', { id, ...ordem });
  };

  const deletarOrdem = (id: string) => {
    setOrdens(ordens.filter(o => o.id !== id));
    addToQueue('ordem', 'delete', { id });
  };

  const obterOrdensPorCliente = (cliente_id: string) => {
    return ordens.filter(o => o.cliente_id === cliente_id);
  };

  const obterOrdensPorStatus = (status: OrdemServico['status']) => {
    return ordens.filter(o => o.status === status);
  };

  const converterAtendimentoEmOrdem = (atendimentoId: string) => {
    const atendimento = atendimentos.find(a => a.id === atendimentoId);
    if (!atendimento) {
      return { sucesso: false, mensagem: 'Atendimento não encontrado' };
    }

    // Criar cliente se não existir
    let clienteId = atendimento.cliente_id;
    if (!clienteId) {
      const novoCliente: Cliente = {
        id: Date.now().toString(),
        nome: 'Cliente do Atendimento ' + atendimentoId,
        email: '',
        telefone: '',
        endereco: '',
        dataCadastro: new Date().toISOString(),
      };
      setClientes([...clientes, novoCliente]);
      clienteId = novoCliente.id;
    }

    // Criar ordem
    const novaOrdem: OrdemServico = {
      id: Date.now().toString(),
      cliente_id: clienteId,
      data_agendamento: atendimento.data_agendamento,
      descricao: atendimento.descricao,
      status: 'pendente',
      valor_total: 0,
      servicos: [],
      forma_pagamento: 'dinheiro',
      status_pagamento: 'pendente',
      data_criacao: new Date().toISOString(),
    };

    setOrdens([...ordens, novaOrdem]);
    addToQueue('ordem', 'add', novaOrdem);

    return { sucesso: true, ordemId: novaOrdem.id, mensagem: 'Ordem criada com sucesso!' };
  };

  const obterMetricasCliente = (cliente_id: string) => {
    const ordensCliente = ordens.filter(o => o.cliente_id === cliente_id);
    const total_servicos = ordensCliente.reduce((acc, o) => acc + o.servicos.length, 0);
    const valor_total = ordensCliente.reduce((acc, o) => acc + o.valor_total, 0);
    const ultima_data = ordensCliente.length > 0 
      ? new Date(Math.max(...ordensCliente.map(o => new Date(o.data_agendamento).getTime()))).toISOString()
      : null;

    return { total_servicos, valor_total, ultima_data };
  };

  const sincronizarDados = (dados: { clientes: Cliente[]; ordens: OrdemServico[]; servicos: Servico[]; atendimentos: Atendimento[] }) => {
    // Mesclar dados do servidor com dados locais
    // Priorizar dados do servidor (mais recentes)
    
    if (dados.clientes) {
      const clientesMesclados = [...dados.clientes];
      clientes.forEach(clienteLocal => {
        const existe = clientesMesclados.find(c => c.id === clienteLocal.id);
        if (!existe) {
          clientesMesclados.push(clienteLocal);
        }
      });
      setClientes(clientesMesclados);
    }

    if (dados.ordens) {
      const ordensMescladas = [...dados.ordens];
      ordens.forEach(ordemLocal => {
        const existe = ordensMescladas.find(o => o.id === ordemLocal.id);
        if (!existe) {
          ordensMescladas.push(ordemLocal);
        }
      });
      setOrdens(ordensMescladas);
    }

    if (dados.servicos) {
      const servicosMesclados = [...dados.servicos];
      servicos.forEach(servicoLocal => {
        const existe = servicosMesclados.find(s => s.id === servicoLocal.id);
        if (!existe) {
          servicosMesclados.push(servicoLocal);
        }
      });
      setServicos(servicosMesclados);
    }

    if (dados.atendimentos) {
      const atendimentosMesclados = [...dados.atendimentos];
      atendimentos.forEach(atendimentoLocal => {
        const existe = atendimentosMesclados.find(a => a.id === atendimentoLocal.id);
        if (!existe) {
          atendimentosMesclados.push(atendimentoLocal);
        }
      });
      setAtendimentos(atendimentosMesclados);
    }
  };

  const value: CRMContextType = {
    atendimentos,
    clientes,
    servicos,
    ordens,
    adicionarAtendimento,
    atualizarAtendimento,
    deletarAtendimento,
    obterAtendimentosPorStatus,
    adicionarCliente,
    atualizarCliente,
    deletarCliente,
    adicionarServico,
    atualizarServico,
    deletarServico,
    adicionarOrdem,
    atualizarOrdem,
    deletarOrdem,
    obterOrdensPorCliente,
    obterOrdensPorStatus,
    converterAtendimentoEmOrdem,
    obterMetricasCliente,
    sincronizarDados,
  };

  return <CRMContext.Provider value={value}>{children}</CRMContext.Provider>;
}

export function useCRM() {
  const context = useContext(CRMContext);
  if (!context) {
    throw new Error('useCRM deve ser usado dentro de CRMProvider');
  }
  const { usuarioLogado } = useAuth();
  if (!usuarioLogado) {
    throw new Error('useCRM requer usuário autenticado');
  }
  return context;
}
