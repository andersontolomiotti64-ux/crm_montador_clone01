import { describe, it, expect, beforeEach } from 'vitest';

describe('CRMContext', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  describe('Clientes', () => {
    it('deve adicionar um cliente', () => {
      const novoCliente = {
        nome: 'João Silva',
        email: 'joao@example.com',
        telefone: '11999999999',
        endereco: 'Rua A, 123',
        dataCadastro: new Date().toISOString()
      };

      // Simular adição
      const clientes = [{ id: '1', ...novoCliente }];
      expect(clientes).toHaveLength(1);
      expect(clientes[0].nome).toBe('João Silva');
    });

    it('deve atualizar um cliente', () => {
      const cliente = { id: '1', nome: 'João', email: 'joao@example.com', telefone: '123', endereco: 'Rua A', dataCadastro: '2026-04-20' };
      const clienteAtualizado = { ...cliente, nome: 'João Silva' };

      expect(clienteAtualizado.nome).toBe('João Silva');
    });

    it('deve deletar um cliente', () => {
      const clientes = [
        { id: '1', nome: 'João', email: 'joao@example.com', telefone: '123', endereco: 'Rua A', dataCadastro: '2026-04-20' },
        { id: '2', nome: 'Maria', email: 'maria@example.com', telefone: '456', endereco: 'Rua B', dataCadastro: '2026-04-20' }
      ];

      const clientesFiltrados = clientes.filter(c => c.id !== '1');
      expect(clientesFiltrados).toHaveLength(1);
      expect(clientesFiltrados[0].nome).toBe('Maria');
    });
  });

  describe('Ordens', () => {
    it('deve criar uma ordem com múltiplos serviços', () => {
      const ordem = {
        id: '1',
        cliente_id: '1',
        data_agendamento: '2026-04-25',
        descricao: 'Montagem de guarda-roupa',
        status: 'agendada' as const,
        valor_total: 500,
        servicos: [
          { id: '1', nome: 'Montagem', descricao: 'Montagem completa', preco: 300, tempo_estimado: 120 },
          { id: '2', nome: 'Deslocamento', descricao: 'Deslocamento especial', preco: 200, tempo_estimado: 60 }
        ],
        forma_pagamento: 'dinheiro' as const,
        status_pagamento: 'pendente' as const,
        data_criacao: new Date().toISOString()
      };

      expect(ordem.servicos).toHaveLength(2);
      expect(ordem.valor_total).toBe(500);
    });

    it('deve calcular valor total corretamente', () => {
      const servicos = [
        { id: '1', nome: 'Serviço 1', descricao: 'Desc', preco: 100, tempo_estimado: 60 },
        { id: '2', nome: 'Serviço 2', descricao: 'Desc', preco: 200, tempo_estimado: 120 }
      ];

      const valorTotal = servicos.reduce((acc, s) => acc + (s.preco || 0), 0);
      expect(valorTotal).toBe(300);
    });

    it('deve registrar forma de pagamento', () => {
      const ordem = {
        id: '1',
        cliente_id: '1',
        data_agendamento: '2026-04-25',
        descricao: 'Montagem',
        status: 'concluida' as const,
        valor_total: 500,
        servicos: [],
        forma_pagamento: 'pix' as const,
        status_pagamento: 'pago' as const,
        descricao_pagamento: 'PIX em 20/04/2026',
        data_criacao: new Date().toISOString()
      };

      expect(ordem.forma_pagamento).toBe('pix');
      expect(ordem.status_pagamento).toBe('pago');
      expect(ordem.descricao_pagamento).toBe('PIX em 20/04/2026');
    });
  });

  describe('Serviços', () => {
    it('deve adicionar um serviço', () => {
      const servico = {
        id: '1',
        nome: 'Montagem de Guarda-Roupa',
        descricao: 'Montagem completa com parafusos',
        preco: 300,
        tempo_estimado: 120
      };

      expect(servico.nome).toBe('Montagem de Guarda-Roupa');
      expect(servico.preco).toBe(300);
    });

    it('deve validar preço positivo', () => {
      const preco = 300;
      expect(preco).toBeGreaterThan(0);
    });

    it('deve validar tempo estimado positivo', () => {
      const tempo = 120;
      expect(tempo).toBeGreaterThan(0);
    });
  });

  describe('Atendimentos', () => {
    it('deve criar um atendimento', () => {
      const atendimento = {
        id: '1',
        descricao: 'Cliente quer montar guarda-roupa',
        data_agendamento: '2026-04-25',
        status: 'pendente' as const,
        cliente_id: '1',
        data_criacao: new Date().toISOString()
      };

      expect(atendimento.status).toBe('pendente');
      expect(atendimento.cliente_id).toBe('1');
    });

    it('deve atualizar status de atendimento', () => {
      const atendimento = {
        id: '1',
        descricao: 'Cliente quer montar guarda-roupa',
        data_agendamento: '2026-04-25',
        status: 'confirmado' as const,
        cliente_id: '1',
        data_criacao: new Date().toISOString()
      };

      expect(atendimento.status).toBe('confirmado');
    });
  });

  describe('Métricas', () => {
    it('deve calcular total de clientes', () => {
      const clientes = [
        { id: '1', nome: 'João', email: 'joao@example.com', telefone: '123', endereco: 'Rua A', dataCadastro: '2026-04-20' },
        { id: '2', nome: 'Maria', email: 'maria@example.com', telefone: '456', endereco: 'Rua B', dataCadastro: '2026-04-20' },
        { id: '3', nome: 'Pedro', email: 'pedro@example.com', telefone: '789', endereco: 'Rua C', dataCadastro: '2026-04-20' }
      ];

      expect(clientes).toHaveLength(3);
    });

    it('deve calcular receita total', () => {
      const ordens = [
        { id: '1', cliente_id: '1', data_agendamento: '2026-04-20', descricao: 'Ordem 1', status: 'concluida' as const, valor_total: 500, servicos: [], data_criacao: '2026-04-20' },
        { id: '2', cliente_id: '2', data_agendamento: '2026-04-21', descricao: 'Ordem 2', status: 'concluida' as const, valor_total: 300, servicos: [], data_criacao: '2026-04-21' },
        { id: '3', cliente_id: '3', data_agendamento: '2026-04-22', descricao: 'Ordem 3', status: 'pendente' as const, valor_total: 200, servicos: [], data_criacao: '2026-04-22' }
      ];

      const receitaConcluida = ordens
        .filter(o => o.status === 'concluida')
        .reduce((acc, o) => acc + o.valor_total, 0);

      expect(receitaConcluida).toBe(800);
    });

    it('deve contar ordens por status', () => {
      const ordens = [
        { id: '1', cliente_id: '1', data_agendamento: '2026-04-20', descricao: 'Ordem 1', status: 'concluida' as const, valor_total: 500, servicos: [], data_criacao: '2026-04-20' },
        { id: '2', cliente_id: '2', data_agendamento: '2026-04-21', descricao: 'Ordem 2', status: 'em_progresso' as const, valor_total: 300, servicos: [], data_criacao: '2026-04-21' },
        { id: '3', cliente_id: '3', data_agendamento: '2026-04-22', descricao: 'Ordem 3', status: 'em_progresso' as const, valor_total: 200, servicos: [], data_criacao: '2026-04-22' }
      ];

      const emProgresso = ordens.filter(o => o.status === 'em_progresso').length;
      expect(emProgresso).toBe(2);
    });
  });
});
