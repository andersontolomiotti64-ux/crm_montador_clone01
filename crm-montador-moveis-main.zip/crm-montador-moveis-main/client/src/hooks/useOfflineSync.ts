import { useEffect, useState, useCallback } from 'react';

export interface SyncOperation {
  id: string;
  type: 'create' | 'update' | 'delete';
  entity: 'cliente' | 'servico' | 'ordem';
  data: any;
  timestamp: number;
  synced: boolean;
}

const SYNC_QUEUE_KEY = 'crm_sync_queue';

export function useOfflineSync() {
  const [syncQueue, setSyncQueue] = useState<SyncOperation[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);

  // Carregar fila do localStorage
  useEffect(() => {
    const savedQueue = localStorage.getItem(SYNC_QUEUE_KEY);
    if (savedQueue) {
      try {
        const queue = JSON.parse(savedQueue);
        setSyncQueue(queue);
        setPendingCount(queue.filter((op: SyncOperation) => !op.synced).length);
      } catch (error) {
        console.error('Erro ao carregar fila de sincronização:', error);
      }
    }
  }, []);

  // Salvar fila no localStorage
  useEffect(() => {
    localStorage.setItem(SYNC_QUEUE_KEY, JSON.stringify(syncQueue));
    setPendingCount(syncQueue.filter(op => !op.synced).length);
  }, [syncQueue]);

  // Adicionar operação à fila
  const addOperation = useCallback((
    type: 'create' | 'update' | 'delete',
    entity: 'cliente' | 'servico' | 'ordem',
    data: any
  ) => {
    const operation: SyncOperation = {
      id: `${Date.now()}-${Math.random()}`,
      type,
      entity,
      data,
      timestamp: Date.now(),
      synced: false
    };

    setSyncQueue(prev => [...prev, operation]);
    return operation;
  }, []);

  // Marcar operação como sincronizada
  const markAsSynced = useCallback((operationId: string) => {
    setSyncQueue(prev =>
      prev.map(op =>
        op.id === operationId ? { ...op, synced: true } : op
      )
    );
  }, []);

  // Limpar operações sincronizadas
  const clearSyncedOperations = useCallback(() => {
    setSyncQueue(prev => prev.filter(op => !op.synced));
  }, []);

  // Sincronizar quando voltar online
  const syncWhenOnline = useCallback(async () => {
    if (!navigator.onLine) {
      return;
    }

    const unsyncedOps = syncQueue.filter(op => !op.synced);
    if (unsyncedOps.length === 0) {
      return;
    }

    setIsSyncing(true);
    try {
      // Simular sincronização - em produção, fazer requisições reais
      for (const operation of unsyncedOps) {
        // Simular delay de rede
        await new Promise(resolve => setTimeout(resolve, 500));
        markAsSynced(operation.id);
      }

      // Limpar operações sincronizadas após sucesso
      clearSyncedOperations();
    } catch (error) {
      console.error('Erro ao sincronizar:', error);
    } finally {
      setIsSyncing(false);
    }
  }, [syncQueue, markAsSynced, clearSyncedOperations]);

  // Sincronizar quando voltar online
  useEffect(() => {
    const handleOnline = () => {
      syncWhenOnline();
    };

    window.addEventListener('online', handleOnline);
    return () => window.removeEventListener('online', handleOnline);
  }, [syncWhenOnline]);

  return {
    syncQueue,
    isSyncing,
    pendingCount,
    addOperation,
    markAsSynced,
    clearSyncedOperations,
    syncWhenOnline
  };
}
