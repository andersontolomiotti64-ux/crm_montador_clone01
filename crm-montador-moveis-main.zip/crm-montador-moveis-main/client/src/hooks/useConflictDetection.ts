import { useState, useCallback } from 'react';
import { ConflictItem } from '@/components/ConflictResolutionDialog';

export function useConflictDetection() {
  const [conflicts, setConflicts] = useState<ConflictItem[]>([]);

  const detectConflicts = useCallback((
    localData: any,
    serverData: any
  ): ConflictItem[] => {
    const detectedConflicts: ConflictItem[] = [];

    // Detectar conflitos em clientes
    if (localData.clientes && serverData.clientes) {
      serverData.clientes.forEach((serverCliente: any) => {
        const localCliente = localData.clientes.find((c: any) => c.id === serverCliente.id);
        if (localCliente) {
          // Comparar cada campo
          Object.keys(serverCliente).forEach(key => {
            if (JSON.stringify(localCliente[key]) !== JSON.stringify(serverCliente[key])) {
              detectedConflicts.push({
                id: `cliente-${serverCliente.id}-${key}`,
                type: 'cliente',
                localData: localCliente[key],
                serverData: serverCliente[key],
                field: key,
              });
            }
          });
        }
      });
    }

    // Detectar conflitos em ordens
    if (localData.ordens && serverData.ordens) {
      serverData.ordens.forEach((serverOrdem: any) => {
        const localOrdem = localData.ordens.find((o: any) => o.id === serverOrdem.id);
        if (localOrdem) {
          Object.keys(serverOrdem).forEach(key => {
            if (JSON.stringify(localOrdem[key]) !== JSON.stringify(serverOrdem[key])) {
              detectedConflicts.push({
                id: `ordem-${serverOrdem.id}-${key}`,
                type: 'ordem',
                localData: localOrdem[key],
                serverData: serverOrdem[key],
                field: key,
              });
            }
          });
        }
      });
    }

    // Detectar conflitos em serviços
    if (localData.servicos && serverData.servicos) {
      serverData.servicos.forEach((serverServico: any) => {
        const localServico = localData.servicos.find((s: any) => s.id === serverServico.id);
        if (localServico) {
          Object.keys(serverServico).forEach(key => {
            if (JSON.stringify(localServico[key]) !== JSON.stringify(serverServico[key])) {
              detectedConflicts.push({
                id: `servico-${serverServico.id}-${key}`,
                type: 'servico',
                localData: localServico[key],
                serverData: serverServico[key],
                field: key,
              });
            }
          });
        }
      });
    }

    // Detectar conflitos em atendimentos
    if (localData.atendimentos && serverData.atendimentos) {
      serverData.atendimentos.forEach((serverAtendimento: any) => {
        const localAtendimento = localData.atendimentos.find((a: any) => a.id === serverAtendimento.id);
        if (localAtendimento) {
          Object.keys(serverAtendimento).forEach(key => {
            if (JSON.stringify(localAtendimento[key]) !== JSON.stringify(serverAtendimento[key])) {
              detectedConflicts.push({
                id: `atendimento-${serverAtendimento.id}-${key}`,
                type: 'atendimento',
                localData: localAtendimento[key],
                serverData: serverAtendimento[key],
                field: key,
              });
            }
          });
        }
      });
    }

    setConflicts(detectedConflicts);
    return detectedConflicts;
  }, []);

  const resolveConflicts = useCallback((
    localData: any,
    serverData: any,
    resolution: { [key: string]: 'local' | 'server' }
  ): any => {
    const resolved = { ...serverData };

    Object.entries(resolution).forEach(([conflictId, choice]) => {
      const [type, id, field] = conflictId.split('-');
      
      if (choice === 'local') {
        // Usar dados locais
        if (type === 'cliente') {
          const localCliente = localData.clientes.find((c: any) => c.id === id);
          if (localCliente && resolved.clientes) {
            const index = resolved.clientes.findIndex((c: any) => c.id === id);
            if (index !== -1) {
              resolved.clientes[index][field] = localCliente[field];
            }
          }
        } else if (type === 'ordem') {
          const localOrdem = localData.ordens.find((o: any) => o.id === id);
          if (localOrdem && resolved.ordens) {
            const index = resolved.ordens.findIndex((o: any) => o.id === id);
            if (index !== -1) {
              resolved.ordens[index][field] = localOrdem[field];
            }
          }
        } else if (type === 'servico') {
          const localServico = localData.servicos.find((s: any) => s.id === id);
          if (localServico && resolved.servicos) {
            const index = resolved.servicos.findIndex((s: any) => s.id === id);
            if (index !== -1) {
              resolved.servicos[index][field] = localServico[field];
            }
          }
        } else if (type === 'atendimento') {
          const localAtendimento = localData.atendimentos.find((a: any) => a.id === id);
          if (localAtendimento && resolved.atendimentos) {
            const index = resolved.atendimentos.findIndex((a: any) => a.id === id);
            if (index !== -1) {
              resolved.atendimentos[index][field] = localAtendimento[field];
            }
          }
        }
      }
      // Se choice === 'server', já está usando dados do servidor
    });

    setConflicts([]);
    return resolved;
  }, []);

  return {
    conflicts,
    detectConflicts,
    resolveConflicts,
  };
}
