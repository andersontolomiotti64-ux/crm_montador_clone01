import { useEffect, useState, useCallback } from 'react';

export function useDarkModeAuto() {
  const [isDarkMode, setIsDarkMode] = useState(() => {
    // Verificar preferência salva
    const saved = localStorage.getItem('theme-preference');
    if (saved) {
      return saved === 'dark';
    }

    // Verificar preferência do sistema
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return true;
    }

    return false;
  });

  // Aplicar tema
  const applyTheme = useCallback((dark: boolean) => {
    if (dark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme-preference', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme-preference', 'light');
    }
    setIsDarkMode(dark);
  }, []);

  // Toggle tema
  const toggleTheme = useCallback(() => {
    applyTheme(!isDarkMode);
  }, [isDarkMode, applyTheme]);

  // Definir tema claro
  const setLightMode = useCallback(() => {
    applyTheme(false);
  }, [applyTheme]);

  // Definir tema escuro
  const setDarkMode = useCallback(() => {
    applyTheme(true);
  }, [applyTheme]);

  // Usar preferência do sistema
  const useSystemPreference = useCallback(() => {
    localStorage.removeItem('theme-preference');
    
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      applyTheme(true);
    } else {
      applyTheme(false);
    }
  }, [applyTheme]);

  // Monitorar mudanças de preferência do sistema
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    
    const handleChange = (e: MediaQueryListEvent) => {
      const saved = localStorage.getItem('theme-preference');
      if (!saved) {
        applyTheme(e.matches);
      }
    };

    // Suporte para navegadores antigos
    if (mediaQuery.addEventListener) {
      mediaQuery.addEventListener('change', handleChange);
      return () => mediaQuery.removeEventListener('change', handleChange);
    } else if (mediaQuery.addListener) {
      mediaQuery.addListener(handleChange);
      return () => mediaQuery.removeListener(handleChange);
    }
  }, [applyTheme]);

  // Aplicar tema ao montar
  useEffect(() => {
    applyTheme(isDarkMode);
  }, []);

  return {
    isDarkMode,
    toggleTheme,
    setLightMode,
    setDarkMode,
    useSystemPreference
  };
}
