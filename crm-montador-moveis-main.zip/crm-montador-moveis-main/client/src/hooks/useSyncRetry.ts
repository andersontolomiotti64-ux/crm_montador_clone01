import { useCallback, useRef } from 'react';

export interface RetryConfig {
  maxRetries?: number;
  initialDelayMs?: number;
  maxDelayMs?: number;
  backoffMultiplier?: number;
}

const DEFAULT_CONFIG: Required<RetryConfig> = {
  maxRetries: 3,
  initialDelayMs: 1000,
  maxDelayMs: 30000,
  backoffMultiplier: 5,
};

export function useSyncRetry() {
  const retryCountRef = useRef<{ [key: string]: number }>({});
  const lastErrorRef = useRef<{ [key: string]: Error | null }>({});

  const calculateDelay = (retryCount: number, config: Required<RetryConfig>): number => {
    const delay = config.initialDelayMs * Math.pow(config.backoffMultiplier, retryCount - 1);
    return Math.min(delay, config.maxDelayMs);
  };

  const executeWithRetry = useCallback(
    async <T,>(
      operation: () => Promise<T>,
      operationName: string = 'sync',
      config: RetryConfig = {}
    ): Promise<{ success: boolean; data?: T; error?: Error; retriesUsed: number }> => {
      const finalConfig = { ...DEFAULT_CONFIG, ...config };
      let lastError: Error | null = null;
      let retriesUsed = 0;

      for (let attempt = 1; attempt <= finalConfig.maxRetries + 1; attempt++) {
        try {
          console.log(`[Retry] ${operationName} - Tentativa ${attempt}/${finalConfig.maxRetries + 1}`);
          const data = await operation();
          
          // Sucesso - limpar contadores
          retryCountRef.current[operationName] = 0;
          lastErrorRef.current[operationName] = null;
          
          return {
            success: true,
            data,
            retriesUsed,
          };
        } catch (error) {
          lastError = error instanceof Error ? error : new Error(String(error));
          lastErrorRef.current[operationName] = lastError;
          retriesUsed = attempt - 1;

          if (attempt <= finalConfig.maxRetries) {
            const delay = calculateDelay(attempt, finalConfig);
            console.warn(
              `[Retry] ${operationName} - Tentativa ${attempt} falhou. Tentando novamente em ${delay}ms...`,
              lastError.message
            );
            
            // Aguardar antes de tentar novamente
            await new Promise(resolve => setTimeout(resolve, delay));
          } else {
            console.error(
              `[Retry] ${operationName} - Todas as ${finalConfig.maxRetries + 1} tentativas falharam`,
              lastError.message
            );
          }
        }
      }

      // Todas as tentativas falharam
      retryCountRef.current[operationName] = finalConfig.maxRetries + 1;
      
      return {
        success: false,
        error: lastError || new Error('Operação falhou após todas as tentativas'),
        retriesUsed,
      };
    },
    []
  );

  const getRetryCount = useCallback((operationName: string): number => {
    return retryCountRef.current[operationName] || 0;
  }, []);

  const getLastError = useCallback((operationName: string): Error | null => {
    return lastErrorRef.current[operationName] || null;
  }, []);

  const resetRetryCount = useCallback((operationName: string): void => {
    retryCountRef.current[operationName] = 0;
    lastErrorRef.current[operationName] = null;
  }, []);

  const resetAllRetries = useCallback((): void => {
    retryCountRef.current = {};
    lastErrorRef.current = {};
  }, []);

  return {
    executeWithRetry,
    getRetryCount,
    getLastError,
    resetRetryCount,
    resetAllRetries,
  };
}
