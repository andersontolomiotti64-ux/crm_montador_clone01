import { describe, it, expect, beforeEach, vi } from 'vitest';

describe('useSyncData Hook', () => {
  beforeEach(() => {
    // Reset localStorage antes de cada teste
    localStorage.clear();
  });

  it('deve sincronizar dados para o servidor', async () => {
    // Mock dos dados
    const mockData = {
      clientes: [{ id: '1', nome: 'João', email: 'joao@example.com', telefone: '123456789', endereco: 'Rua A', dataCadastro: '2026-04-20' }],
      ordens: [],
      servicos: [],
      atendimentos: []
    };

    // Simulação do upload
    const response = await fetch('/api/sync/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(mockData)
    });

    expect(response.status).toBe(200);
  });

  it('deve baixar dados do servidor', async () => {
    const response = await fetch('/api/sync/download');
    const data = await response.json();

    expect(response.status).toBe(200);
    expect(data).toHaveProperty('clientes');
    expect(data).toHaveProperty('ordens');
    expect(data).toHaveProperty('servicos');
    expect(data).toHaveProperty('atendimentos');
  });

  it('deve verificar status de sincronização', async () => {
    const response = await fetch('/api/sync/status');
    const data = await response.json();

    expect(response.status).toBe(200);
    expect(data).toHaveProperty('online');
    expect(data).toHaveProperty('lastSync');
  });

  it('deve armazenar dados em localStorage', () => {
    const testData = { teste: 'valor' };
    localStorage.setItem('crm-data', JSON.stringify(testData));

    const retrieved = JSON.parse(localStorage.getItem('crm-data') || '{}');
    expect(retrieved).toEqual(testData);
  });

  it('deve limpar dados de localStorage', () => {
    localStorage.setItem('crm-data', JSON.stringify({ teste: 'valor' }));
    localStorage.removeItem('crm-data');

    expect(localStorage.getItem('crm-data')).toBeNull();
  });
});
