import { useState, useCallback, useEffect } from 'react';

export interface ServiceCategory {
  id: string;
  nome: string;
  descricao?: string;
  cor?: string;
  icone?: string;
  criadoEm: Date;
}

const CATEGORIAS_PADRAO: ServiceCategory[] = [
  { id: 'montagem', nome: 'Montagem', descricao: 'Serviços de montagem', cor: '#3B82F6', criadoEm: new Date() },
  { id: 'desmontagem', nome: 'Desmontagem', descricao: 'Serviços de desmontagem', cor: '#EF4444', criadoEm: new Date() },
  { id: 'reparo', nome: 'Reparo', descricao: 'Serviços de reparo', cor: '#F59E0B', criadoEm: new Date() },
  { id: 'customizacao', nome: 'Customização', descricao: 'Serviços de customização', cor: '#8B5CF6', criadoEm: new Date() },
  { id: 'outro', nome: 'Outro', descricao: 'Outros serviços', cor: '#6B7280', criadoEm: new Date() }
];

export function useCategories() {
  const [categories, setCategories] = useState<ServiceCategory[]>(() => {
    const saved = localStorage.getItem('service-categories');
    return saved ? JSON.parse(saved) : CATEGORIAS_PADRAO;
  });

  // Salvar categorias no localStorage
  useEffect(() => {
    localStorage.setItem('service-categories', JSON.stringify(categories));
  }, [categories]);

  // Adicionar nova categoria
  const adicionarCategoria = useCallback((nome: string, descricao?: string, cor?: string) => {
    const novaCategoria: ServiceCategory = {
      id: `cat-${Date.now()}`,
      nome,
      descricao,
      cor: cor || '#6B7280',
      criadoEm: new Date()
    };

    setCategories(prev => [...prev, novaCategoria]);
    return novaCategoria;
  }, []);

  // Atualizar categoria
  const atualizarCategoria = useCallback((id: string, updates: Partial<ServiceCategory>) => {
    setCategories(prev => prev.map(cat => 
      cat.id === id ? { ...cat, ...updates } : cat
    ));
  }, []);

  // Deletar categoria
  const deletarCategoria = useCallback((id: string) => {
    setCategories(prev => prev.filter(cat => cat.id !== id));
  }, []);

  // Obter categoria por ID
  const obterCategoria = useCallback((id: string) => {
    return categories.find(cat => cat.id === id);
  }, [categories]);

  // Obter todas as categorias
  const obterTodasCategorias = useCallback(() => {
    return categories;
  }, [categories]);

  // Restaurar categorias padrão
  const restaurarPadrao = useCallback(() => {
    setCategories(CATEGORIAS_PADRAO);
  }, []);

  // Validar se categoria existe
  const categoriaExiste = useCallback((nome: string) => {
    return categories.some(cat => cat.nome.toLowerCase() === nome.toLowerCase());
  }, [categories]);

  // Contar categorias
  const contarCategorias = useCallback(() => {
    return categories.length;
  }, [categories]);

  return {
    categories,
    adicionarCategoria,
    atualizarCategoria,
    deletarCategoria,
    obterCategoria,
    obterTodasCategorias,
    restaurarPadrao,
    categoriaExiste,
    contarCategorias
  };
}
