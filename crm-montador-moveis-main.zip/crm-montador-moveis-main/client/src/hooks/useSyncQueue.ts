import { useState, useEffect, useCallback } from 'react';

export interface SyncOperation {
  id: string;
  type: 'create' | 'update' | 'delete';
  entity: 'cliente' | 'atendimento' | 'ordem' | 'servico';
  data: any;
  timestamp: number;
  synced: boolean;
}

export function useSyncQueue() {
  const [queue, setQueue] = useState<SyncOperation[]>([]);
  const [pendingCount, setPendingCount] = useState(0);
  const [isSyncing, setIsSyncing] = useState(false);

  // Carregar fila do localStorage ao iniciar
  useEffect(() => {
    const queueSalva = localStorage.getItem('crm_sync_queue');
    if (queueSalva) {
      try {
        const parsed = JSON.parse(queueSalva);
        setQueue(parsed);
        const pending = parsed.filter((op: SyncOperation) => !op.synced).length;
        setPendingCount(pending);
      } catch (e) {
        console.error('Erro ao carregar fila de sincronização:', e);
      }
    }
  }, []);

  // Salvar fila no localStorage sempre que mudar
  useEffect(() => {
    localStorage.setItem('crm_sync_queue', JSON.stringify(queue));
    const pending = queue.filter(op => !op.synced).length;
    setPendingCount(pending);
  }, [queue]);

  // Adicionar operação à fila
  const addToQueue = useCallback((
    type: 'create' | 'update' | 'delete',
    entity: 'cliente' | 'atendimento' | 'ordem' | 'servico',
    data: any
  ) => {
    const operation: SyncOperation = {
      id: `${Date.now()}-${Math.random()}`,
      type,
      entity,
      data,
      timestamp: Date.now(),
      synced: false
    };

    setQueue(prev => [...prev, operation]);
    return operation.id;
  }, []);

  // Marcar operação como sincronizada
  const markAsSynced = useCallback((operationId: string) => {
    setQueue(prev =>
      prev.map(op =>
        op.id === operationId ? { ...op, synced: true } : op
      )
    );
  }, []);

  // Remover operações sincronizadas
  const clearSyncedOperations = useCallback(() => {
    setQueue(prev => prev.filter(op => !op.synced));
  }, []);

  // Sincronizar fila (simular envio ao servidor)
  const syncQueue = useCallback(async () => {
    if (isSyncing || pendingCount === 0) return;

    setIsSyncing(true);
    const pendingOps = queue.filter(op => !op.synced);

    try {
      // Em produção, enviar para backend
      // await fetch('/api/sync', { method: 'POST', body: JSON.stringify(pendingOps) })

      // Simular sucesso
      await new Promise(resolve => setTimeout(resolve, 500));

      // Marcar todos como sincronizados
      pendingOps.forEach(op => markAsSynced(op.id));

      console.log(`✅ ${pendingOps.length} operações sincronizadas`);
    } catch (error) {
      console.error('Erro ao sincronizar fila:', error);
    } finally {
      setIsSyncing(false);
    }
  }, [queue, isSyncing, pendingCount, markAsSynced]);

  // Sincronizar quando voltar online
  useEffect(() => {
    const handleOnline = () => {
      console.log('🔄 Voltou online, sincronizando fila...');
      syncQueue();
    };

    window.addEventListener('online', handleOnline);
    return () => window.removeEventListener('online', handleOnline);
  }, [syncQueue]);

  return {
    queue,
    pendingCount,
    isSyncing,
    addToQueue,
    markAsSynced,
    clearSyncedOperations,
    syncQueue
  };
}
