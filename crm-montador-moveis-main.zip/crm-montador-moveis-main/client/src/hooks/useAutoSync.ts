import { useEffect, useRef } from 'react';
import { useSyncData } from './useSyncData';
import { useCRM } from '@/contexts/CRMContext';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

const AUTO_SYNC_INTERVAL = 5 * 60 * 1000; // 5 minutos

export function useAutoSync() {
  const { syncToServer, downloadFromServer } = useSyncData();
  const { usuarioLogado } = useAuth();
  const { sincronizarDados, clientes, ordens, servicos, atendimentos } = useCRM();
  const syncIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const lastSyncRef = useRef<number>(0);

  useEffect(() => {
    if (!usuarioLogado || !navigator.onLine) return;

    // Função para sincronizar
    const performSync = async () => {
      try {
        // Enviar dados locais
        const data = {
          clientes,
          ordens,
          servicos,
          atendimentos,
        };

        await syncToServer(usuarioLogado.id, data);

        // Baixar dados do servidor
        const serverData = await downloadFromServer(usuarioLogado.id);
        if (serverData) {
          sincronizarDados(serverData);
        }

        lastSyncRef.current = Date.now();
        console.log('[AutoSync] Sincronização automática concluída');
      } catch (error) {
        console.error('[AutoSync] Erro durante sincronização automática:', error);
      }
    };

    // Sincronizar imediatamente ao conectar
    const handleOnline = () => {
      console.log('[AutoSync] Voltou online, sincronizando...');
      performSync();
    };

    window.addEventListener('online', handleOnline);

    // Configurar intervalo de sincronização automática
    syncIntervalRef.current = setInterval(() => {
      if (navigator.onLine) {
        console.log('[AutoSync] Sincronização automática em background');
        performSync();
      }
    }, AUTO_SYNC_INTERVAL);

    return () => {
      window.removeEventListener('online', handleOnline);
      if (syncIntervalRef.current) {
        clearInterval(syncIntervalRef.current);
      }
    };
  }, [usuarioLogado, syncToServer, downloadFromServer, sincronizarDados, clientes, ordens, servicos, atendimentos]);

  return {
    lastSync: lastSyncRef.current,
  };
}
