import { useCallback } from 'react';
import { OrdemServico, Cliente } from '@/contexts/CRMContext';

export function useWhatsApp() {
  // Formatar número de telefone para WhatsApp
  const formatPhoneNumber = useCallback((phone: string): string => {
    // Remove caracteres não numéricos
    const cleaned = phone.replace(/\D/g, '');
    
    // Se começar com 0, remove
    if (cleaned.startsWith('0')) {
      return '55' + cleaned.substring(1);
    }
    
    // Se não começar com 55 (código do Brasil), adiciona
    if (!cleaned.startsWith('55')) {
      return '55' + cleaned;
    }
    
    return cleaned;
  }, []);

  // Enviar mensagem de nova ordem
  const enviarResumoOrdem = useCallback((ordem: OrdemServico, cliente: Cliente) => {
    const phone = formatPhoneNumber(cliente.telefone);
    
    const mensagem = `Olá ${cliente.nome}! 👋

Sua ordem de serviço foi criada com sucesso!

📋 *Detalhes da Ordem:*
• ID: ${ordem.id.slice(0, 8)}
• Data: ${new Date(ordem.data_agendamento).toLocaleDateString('pt-BR')}
• Valor: R$ ${ordem.valor_total.toFixed(2)}
• Status: ${ordem.status}

${ordem.descricao ? `• Descrição: ${ordem.descricao}` : ''}

${ordem.forma_pagamento ? `• Forma de Pagamento: ${ordem.forma_pagamento}` : ''}

Obrigado por escolher nossos serviços! 🙏`;

    const url = `https://wa.me/${phone}?text=${encodeURIComponent(mensagem)}`;
    window.open(url, '_blank');
  }, [formatPhoneNumber]);

  // Enviar mensagem de confirmação
  const enviarConfirmacao = useCallback((cliente: Cliente, data: string) => {
    const phone = formatPhoneNumber(cliente.telefone);
    
    const mensagem = `Olá ${cliente.nome}! 👋

Confirmamos seu agendamento para *${new Date(data).toLocaleDateString('pt-BR')}*

Qualquer dúvida, entre em contato conosco! 📞

Obrigado! 🙏`;

    const url = `https://wa.me/${phone}?text=${encodeURIComponent(mensagem)}`;
    window.open(url, '_blank');
  }, [formatPhoneNumber]);

  // Enviar mensagem de conclusão
  const enviarConclusao = useCallback((cliente: Cliente, valor: number) => {
    const phone = formatPhoneNumber(cliente.telefone);
    
    const mensagem = `Olá ${cliente.nome}! 👋

Seu serviço foi concluído com sucesso! ✅

Valor a pagar: *R$ ${valor.toFixed(2)}*

Formas de pagamento aceitas:
💵 Dinheiro
📱 PIX
💳 Cartão

Obrigado! 🙏`;

    const url = `https://wa.me/${phone}?text=${encodeURIComponent(mensagem)}`;
    window.open(url, '_blank');
  }, [formatPhoneNumber]);

  // Enviar mensagem de lembrete
  const enviarLembrete = useCallback((cliente: Cliente, data: string) => {
    const phone = formatPhoneNumber(cliente.telefone);
    
    const mensagem = `Olá ${cliente.nome}! 👋

Lembrete: Seu agendamento é para *${new Date(data).toLocaleDateString('pt-BR')}*

Confirme sua presença ou qualquer alteração! 📅

Obrigado! 🙏`;

    const url = `https://wa.me/${phone}?text=${encodeURIComponent(mensagem)}`;
    window.open(url, '_blank');
  }, [formatPhoneNumber]);

  // Enviar mensagem customizada
  const enviarMensagemCustomizada = useCallback((phone: string, mensagem: string) => {
    const phoneFormatted = formatPhoneNumber(phone);
    const url = `https://wa.me/${phoneFormatted}?text=${encodeURIComponent(mensagem)}`;
    window.open(url, '_blank');
  }, [formatPhoneNumber]);

  // Gerar link de contato
  const gerarLinkContato = useCallback((phone: string, mensagem?: string): string => {
    const phoneFormatted = formatPhoneNumber(phone);
    const mensagemEncodada = mensagem ? `?text=${encodeURIComponent(mensagem)}` : '';
    return `https://wa.me/${phoneFormatted}${mensagemEncodada}`;
  }, [formatPhoneNumber]);

  return {
    formatPhoneNumber,
    enviarResumoOrdem,
    enviarConfirmacao,
    enviarConclusao,
    enviarLembrete,
    enviarMensagemCustomizada,
    gerarLinkContato
  };
}
