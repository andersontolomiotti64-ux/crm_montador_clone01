import { useEffect, useCallback } from 'react';
import { toast } from 'sonner';

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: Date;
  read: boolean;
}

export function useNotifications() {
  // Solicitar permissão para notificações
  const requestPermission = useCallback(async () => {
    if (!('Notification' in window)) {
      console.log('Este navegador não suporta notificações');
      return false;
    }

    if (Notification.permission === 'granted') {
      return true;
    }

    if (Notification.permission !== 'denied') {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    }

    return false;
  }, []);

  // Enviar notificação
  const sendNotification = useCallback((title: string, options?: NotificationOptions) => {
    if (Notification.permission === 'granted') {
      new Notification(title, {
        icon: '/favicon.ico',
        badge: '/favicon.ico',
        ...options
      });
    }
  }, []);

  // Notificar nova ordem
  const notifyNovaOrdem = useCallback((clienteNome: string, valor: number) => {
    const message = `Nova ordem de ${clienteNome} - R$ ${valor.toFixed(2)}`;
    
    sendNotification('Nova Ordem de Serviço', {
      body: message,
      tag: 'nova-ordem',
      requireInteraction: true
    });

    toast.success(message);
  }, [sendNotification]);

  // Notificar novo cliente
  const notifyNovoCliente = useCallback((clienteNome: string) => {
    const message = `Novo cliente: ${clienteNome}`;
    
    sendNotification('Novo Cliente', {
      body: message,
      tag: 'novo-cliente'
    });

    toast.info(message);
  }, [sendNotification]);

  // Notificar ordem concluída
  const notifyOrdenConcluida = useCallback((clienteNome: string, valor: number) => {
    const message = `Ordem de ${clienteNome} concluída - R$ ${valor.toFixed(2)}`;
    
    sendNotification('Ordem Concluída', {
      body: message,
      tag: 'ordem-concluida'
    });

    toast.success(message);
  }, [sendNotification]);

  // Notificar pagamento recebido
  const notifyPagamentoRecebido = useCallback((clienteNome: string, valor: number, forma: string) => {
    const message = `Pagamento recebido de ${clienteNome} - R$ ${valor.toFixed(2)} via ${forma}`;
    
    sendNotification('Pagamento Recebido', {
      body: message,
      tag: 'pagamento-recebido'
    });

    toast.success(message);
  }, [sendNotification]);

  // Notificar lembrete
  const notifyLembrete = useCallback((titulo: string, descricao: string) => {
    sendNotification(titulo, {
      body: descricao,
      tag: 'lembrete',
      requireInteraction: false
    });

    toast.info(descricao);
  }, [sendNotification]);

  // Configurar notificações automáticas
  useEffect(() => {
    // Solicitar permissão ao carregar
    requestPermission();

    // Verificar se o navegador suporta Service Workers
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.ready.then(registration => {
        console.log('Service Worker pronto para notificações');
      });
    }
  }, [requestPermission]);

  return {
    requestPermission,
    sendNotification,
    notifyNovaOrdem,
    notifyNovoCliente,
    notifyOrdenConcluida,
    notifyPagamentoRecebido,
    notifyLembrete
  };
}
