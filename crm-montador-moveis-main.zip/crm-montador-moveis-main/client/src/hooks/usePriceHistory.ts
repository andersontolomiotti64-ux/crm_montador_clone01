import { useState, useCallback, useEffect } from 'react';

export interface PriceHistoryEntry {
  id: string;
  servicoId: string;
  precoAnterior: number;
  precoNovo: number;
  data: Date;
  motivo?: string;
}

export function usePriceHistory() {
  const [history, setHistory] = useState<PriceHistoryEntry[]>(() => {
    const saved = localStorage.getItem('price-history');
    return saved ? JSON.parse(saved) : [];
  });

  // Salvar histórico no localStorage
  useEffect(() => {
    localStorage.setItem('price-history', JSON.stringify(history));
  }, [history]);

  // Registrar mudança de preço
  const registrarMudanca = useCallback((servicoId: string, precoAnterior: number, precoNovo: number, motivo?: string) => {
    const entry: PriceHistoryEntry = {
      id: `${Date.now()}-${Math.random()}`,
      servicoId,
      precoAnterior,
      precoNovo,
      data: new Date(),
      motivo
    };

    setHistory(prev => [entry, ...prev]);
    return entry;
  }, []);

  // Obter histórico de um serviço
  const obterHistoricoServico = useCallback((servicoId: string) => {
    return history.filter(h => h.servicoId === servicoId).sort((a, b) => 
      new Date(b.data).getTime() - new Date(a.data).getTime()
    );
  }, [history]);

  // Obter histórico por período
  const obterHistoricoPeriodo = useCallback((dataInicio: Date, dataFim: Date) => {
    return history.filter(h => {
      const data = new Date(h.data);
      return data >= dataInicio && data <= dataFim;
    }).sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime());
  }, [history]);

  // Obter preço anterior de um serviço
  const obterPrecoAnterior = useCallback((servicoId: string): number | null => {
    const entrada = history.find(h => h.servicoId === servicoId);
    return entrada ? entrada.precoAnterior : null;
  }, [history]);

  // Calcular variação de preço
  const calcularVariacao = useCallback((servicoId: string): { percentual: number; valor: number } | null => {
    const entrada = history.find(h => h.servicoId === servicoId);
    if (!entrada) return null;

    const valor = entrada.precoNovo - entrada.precoAnterior;
    const percentual = (valor / entrada.precoAnterior) * 100;

    return { valor, percentual };
  }, [history]);

  // Obter estatísticas
  const obterEstatisticas = useCallback(() => {
    if (history.length === 0) {
      return {
        totalMudancas: 0,
        aumenosMedio: 0,
        reducoesMedio: 0,
        servicosMaisAlterados: []
      };
    }

    const aumentos = history.filter(h => h.precoNovo > h.precoAnterior);
    const reducoes = history.filter(h => h.precoNovo < h.precoAnterior);

    const aumentoMedio = aumentos.length > 0
      ? aumentos.reduce((acc, h) => acc + (h.precoNovo - h.precoAnterior), 0) / aumentos.length
      : 0;

    const reducaoMedia = reducoes.length > 0
      ? reducoes.reduce((acc, h) => acc + (h.precoAnterior - h.precoNovo), 0) / reducoes.length
      : 0;

    // Serviços mais alterados
    const servicosMap = new Map<string, number>();
    history.forEach(h => {
      servicosMap.set(h.servicoId, (servicosMap.get(h.servicoId) || 0) + 1);
    });

    const servicosMaisAlterados = Array.from(servicosMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([servicoId, count]) => ({ servicoId, count }));

    return {
      totalMudancas: history.length,
      aumentosMedio: aumentoMedio,
      reducoesMedio: reducaoMedia,
      servicosMaisAlterados
    };
  }, [history]);

  // Limpar histórico
  const limparHistorico = useCallback(() => {
    setHistory([]);
  }, []);

  // Exportar histórico como CSV
  const exportarCSV = useCallback(() => {
    const csv = [
      ['ID do Serviço', 'Preço Anterior', 'Preço Novo', 'Variação', 'Data', 'Motivo'],
      ...history.map(h => [
        h.servicoId,
        h.precoAnterior.toFixed(2),
        h.precoNovo.toFixed(2),
        ((h.precoNovo - h.precoAnterior) / h.precoAnterior * 100).toFixed(2) + '%',
        new Date(h.data).toLocaleDateString('pt-BR'),
        h.motivo || ''
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `historico-precos-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  }, [history]);

  return {
    history,
    registrarMudanca,
    obterHistoricoServico,
    obterHistoricoPeriodo,
    obterPrecoAnterior,
    calcularVariacao,
    obterEstatisticas,
    limparHistorico,
    exportarCSV
  };
}
