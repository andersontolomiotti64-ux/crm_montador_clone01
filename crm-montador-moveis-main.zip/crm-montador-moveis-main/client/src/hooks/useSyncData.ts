import { useState, useCallback } from 'react';
import { toast } from 'sonner';
import { useSyncRetry } from './useSyncRetry';

interface SyncStatus {
  isSyncing: boolean;
  lastSync: Date | null;
  pendingChanges: number;
  error: string | null;
}

export function useSyncData() {
  const [syncStatus, setSyncStatus] = useState<SyncStatus>({
    isSyncing: false,
    lastSync: null,
    pendingChanges: 0,
    error: null,
  });

  const { executeWithRetry } = useSyncRetry();

  const syncToServer = useCallback(async (userId: string, data: any) => {
    setSyncStatus(prev => ({ ...prev, isSyncing: true, error: null }));
    
    const result = await executeWithRetry(
      async () => {
        const response = await fetch('/api/sync/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId, data }),
        });

        if (!response.ok) {
          throw new Error(`Erro HTTP: ${response.status}`);
        }

        return await response.json();
      },
      'sync-upload',
      {
        maxRetries: 3,
        initialDelayMs: 1000,
        maxDelayMs: 30000,
        backoffMultiplier: 5,
      }
    );

    if (result.success) {
      setSyncStatus(prev => ({
        ...prev,
        isSyncing: false,
        lastSync: new Date(),
        pendingChanges: 0,
      }));

      if (result.retriesUsed > 0) {
        toast.success(`Dados sincronizados! (${result.retriesUsed} tentativa${result.retriesUsed > 1 ? 's' : ''})`);
      } else {
        toast.success('Dados sincronizados com sucesso!');
      }
      return result.data;
    } else {
      const errorMessage = result.error?.message || 'Erro ao sincronizar';
      setSyncStatus(prev => ({
        ...prev,
        isSyncing: false,
        error: errorMessage,
      }));
      toast.error(`Erro na sincronização após ${result.retriesUsed + 1} tentativa${result.retriesUsed + 1 > 1 ? 's' : ''}: ${errorMessage}`);
      return null;
    }
  }, [executeWithRetry]);

  const downloadFromServer = useCallback(async (userId: string) => {
    setSyncStatus(prev => ({ ...prev, isSyncing: true, error: null }));
    
    const result = await executeWithRetry(
      async () => {
        const response = await fetch(`/api/sync/download?userId=${userId}`);
        if (!response.ok) throw new Error(`Erro HTTP: ${response.status}`);
        
        const data = await response.json();

        if (!data.success) {
          throw new Error(data.error || 'Erro ao baixar dados');
        }

        return data.data;
      },
      'sync-download',
      {
        maxRetries: 3,
        initialDelayMs: 1000,
        maxDelayMs: 30000,
        backoffMultiplier: 5,
      }
    );

    if (result.success) {
      setSyncStatus(prev => ({
        ...prev,
        isSyncing: false,
        lastSync: new Date(),
      }));

      if (result.retriesUsed > 0) {
        toast.success(`Dados baixados! (${result.retriesUsed} tentativa${result.retriesUsed > 1 ? 's' : ''})`);
      } else {
        toast.success('Dados baixados com sucesso!');
      }
      return result.data;
    } else {
      const errorMessage = result.error?.message || 'Erro ao baixar dados';
      setSyncStatus(prev => ({
        ...prev,
        isSyncing: false,
        error: errorMessage,
      }));
      toast.error(`Erro ao baixar após ${result.retriesUsed + 1} tentativa${result.retriesUsed + 1 > 1 ? 's' : ''}: ${errorMessage}`);
      return null;
    }
  }, [executeWithRetry]);

  const getSyncStatus = useCallback(async (userId: string) => {
    try {
      const response = await fetch(`/api/sync/status?userId=${userId}`);
      if (!response.ok) throw new Error(`Erro HTTP: ${response.status}`);
      
      const result = await response.json();
      return result.status;
    } catch (error) {
      console.error('Erro ao obter status de sincronização:', error);
      return null;
    }
  }, []);

  return {
    syncStatus,
    syncToServer,
    downloadFromServer,
    getSyncStatus,
  };
}
