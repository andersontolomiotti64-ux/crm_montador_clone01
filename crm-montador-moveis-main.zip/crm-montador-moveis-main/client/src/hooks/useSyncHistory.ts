import { useState, useCallback, useEffect } from 'react';

export interface SyncHistoryEntry {
  id: string;
  timestamp: number;
  type: 'upload' | 'download' | 'conflict_resolution';
  status: 'success' | 'failed' | 'pending';
  itemsCount: number;
  conflictsResolved?: number;
  resolutions?: { [key: string]: 'local' | 'server' };
  errorMessage?: string;
  duration: number; // em ms
}

const STORAGE_KEY = 'sync_history';
const MAX_HISTORY_ENTRIES = 100;

export function useSyncHistory() {
  const [history, setHistory] = useState<SyncHistoryEntry[]>([]);

  // Carregar histórico do localStorage ao iniciar
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setHistory(JSON.parse(stored));
      } catch (error) {
        console.error('Erro ao carregar histórico de sincronizações:', error);
      }
    }
  }, []);

  // Salvar histórico no localStorage sempre que mudar
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
  }, [history]);

  const addEntry = useCallback((entry: Omit<SyncHistoryEntry, 'id'>) => {
    const newEntry: SyncHistoryEntry = {
      ...entry,
      id: Date.now().toString(),
    };

    setHistory(prev => {
      const updated = [newEntry, ...prev];
      // Manter apenas os últimos MAX_HISTORY_ENTRIES
      return updated.slice(0, MAX_HISTORY_ENTRIES);
    });

    return newEntry;
  }, []);

  const updateEntry = useCallback((id: string, updates: Partial<SyncHistoryEntry>) => {
    setHistory(prev =>
      prev.map(entry =>
        entry.id === id ? { ...entry, ...updates } : entry
      )
    );
  }, []);

  const clearHistory = useCallback(() => {
    setHistory([]);
    localStorage.removeItem(STORAGE_KEY);
  }, []);

  const getLastSync = useCallback(() => {
    const successfulSync = history.find(entry => entry.status === 'success');
    return successfulSync ? new Date(successfulSync.timestamp) : null;
  }, [history]);

  const getSuccessRate = useCallback(() => {
    if (history.length === 0) return 100;
    const successful = history.filter(e => e.status === 'success').length;
    return Math.round((successful / history.length) * 100);
  }, [history]);

  const getTotalItemsSynced = useCallback(() => {
    return history.reduce((total, entry) => total + entry.itemsCount, 0);
  }, [history]);

  const getTotalConflictsResolved = useCallback(() => {
    return history.reduce((total, entry) => total + (entry.conflictsResolved || 0), 0);
  }, [history]);

  return {
    history,
    addEntry,
    updateEntry,
    clearHistory,
    getLastSync,
    getSuccessRate,
    getTotalItemsSynced,
    getTotalConflictsResolved,
  };
}
