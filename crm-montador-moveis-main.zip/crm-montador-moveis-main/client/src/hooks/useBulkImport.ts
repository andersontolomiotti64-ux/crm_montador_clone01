import { useCallback } from 'react';
import { Servico } from '@/contexts/CRMContext';

export interface ImportResult {
  sucesso: number;
  erro: number;
  total: number;
  erros: string[];
}

export function useBulkImport() {
  // Importar de CSV
  const importarCSV = useCallback((arquivo: File): Promise<Partial<Servico>[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = (e) => {
        try {
          const csv = e.target?.result as string;
          const linhas = csv.split('\n').filter(l => l.trim());
          const servicos: Partial<Servico>[] = [];

          // Pular cabeçalho
          for (let i = 1; i < linhas.length; i++) {
            const [nome, descricao, preco, tempo] = linhas[i].split(',');

            if (nome && preco) {
              servicos.push({
                nome: nome.trim(),
                descricao: descricao?.trim() || '',
                preco: parseFloat(preco),
                tempo_estimado: tempo ? parseInt(tempo) : 60
              });
            }
          }

          resolve(servicos);
        } catch (error) {
          reject(new Error('Erro ao processar CSV'));
        }
      };

      reader.onerror = () => reject(new Error('Erro ao ler arquivo'));
      reader.readAsText(arquivo);
    });
  }, []);

  // Importar de JSON
  const importarJSON = useCallback((arquivo: File): Promise<Partial<Servico>[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = (e) => {
        try {
          const json = JSON.parse(e.target?.result as string);
          const servicos = Array.isArray(json) ? json : json.servicos || [];
          resolve(servicos);
        } catch (error) {
          reject(new Error('Erro ao processar JSON'));
        }
      };

      reader.onerror = () => reject(new Error('Erro ao ler arquivo'));
      reader.readAsText(arquivo);
    });
  }, []);

  // Validar serviços
  const validarServicos = useCallback((servicos: Partial<Servico>[]): { validos: Partial<Servico>[]; erros: string[] } => {
    const validos: Partial<Servico>[] = [];
    const erros: string[] = [];

    servicos.forEach((servico, index) => {
      if (!servico.nome) {
        erros.push(`Linha ${index + 1}: Nome é obrigatório`);
        return;
      }

      if (!servico.preco || servico.preco <= 0) {
        erros.push(`Linha ${index + 1}: Preço deve ser maior que 0`);
        return;
      }

      validos.push(servico);
    });

    return { validos, erros };
  }, []);

  // Importar em lote
  const importarEmLote = useCallback(
    async (arquivo: File, tipo: 'csv' | 'json'): Promise<ImportResult> => {
      try {
        let servicos: Partial<Servico>[] = [];

        if (tipo === 'csv') {
          servicos = await importarCSV(arquivo);
        } else {
          servicos = await importarJSON(arquivo);
        }

        const { validos, erros } = validarServicos(servicos);

        return {
          sucesso: validos.length,
          erro: erros.length,
          total: servicos.length,
          erros
        };
      } catch (error) {
        return {
          sucesso: 0,
          erro: 1,
          total: 1,
          erros: [(error as Error).message]
        };
      }
    },
    [importarCSV, importarJSON, validarServicos]
  );

  // Exportar para CSV
  const exportarCSV = useCallback((servicos: Servico[]) => {
    const csv = [
      ['Nome', 'Descrição', 'Preço', 'Tempo Estimado (min)'],
      ...servicos.map(s => [
        s.nome,
        s.descricao || '',
        s.preco?.toFixed(2) || '0.00',
        s.tempo_estimado || '60'
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `servicos-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  }, []);

  // Exportar para JSON
  const exportarJSON = useCallback((servicos: Servico[]) => {
    const json = JSON.stringify({ servicos }, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `servicos-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  }, []);

  return {
    importarCSV,
    importarJSON,
    validarServicos,
    importarEmLote,
    exportarCSV,
    exportarJSON
  };
}
