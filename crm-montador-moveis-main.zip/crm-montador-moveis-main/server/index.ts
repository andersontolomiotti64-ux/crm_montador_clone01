import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Caminho para armazenar dados sincronizados
const SYNC_DATA_DIR = path.join(__dirname, "..", ".sync-data");
if (!fs.existsSync(SYNC_DATA_DIR)) {
  fs.mkdirSync(SYNC_DATA_DIR, { recursive: true });
}

function getUserSyncFile(userId: string) {
  return path.join(SYNC_DATA_DIR, `${userId}.json`);
}

function loadUserData(userId: string) {
  const filePath = getUserSyncFile(userId);
  if (fs.existsSync(filePath)) {
    try {
      return JSON.parse(fs.readFileSync(filePath, "utf-8"));
    } catch (error) {
      console.error(`Erro ao ler arquivo de sincronização para ${userId}:`, error);
      return { clientes: [], ordens: [], servicos: [], atendimentos: [] };
    }
  }
  return { clientes: [], ordens: [], servicos: [], atendimentos: [] };
}

function saveUserData(userId: string, data: any) {
  const filePath = getUserSyncFile(userId);
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error(`Erro ao salvar arquivo de sincronização para ${userId}:`, error);
    return false;
  }
}

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Middleware
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // ========== ENDPOINTS DE SINCRONIZAÇÃO ==========

  // Upload de dados (enviar dados do dispositivo para servidor)
  app.post("/api/sync/upload", (req, res) => {
    try {
      const { userId, data } = req.body;

      if (!userId) {
        return res.status(400).json({ error: "userId é obrigatório" });
      }

      // Carregar dados existentes
      const existingData = loadUserData(userId);

      // Mesclar dados (substituir com dados mais recentes)
      const mergedData = {
        clientes: [...(data.clientes || []), ...existingData.clientes].reduce((acc, item) => {
          const existing = acc.find((i: any) => i.id === item.id);
          if (!existing) acc.push(item);
          return acc;
        }, []),
        ordens: [...(data.ordens || []), ...existingData.ordens].reduce((acc, item) => {
          const existing = acc.find((i: any) => i.id === item.id);
          if (!existing) acc.push(item);
          return acc;
        }, []),
        servicos: [...(data.servicos || []), ...existingData.servicos].reduce((acc, item) => {
          const existing = acc.find((i: any) => i.id === item.id);
          if (!existing) acc.push(item);
          return acc;
        }, []),
        atendimentos: [...(data.atendimentos || []), ...existingData.atendimentos].reduce((acc, item) => {
          const existing = acc.find((i: any) => i.id === item.id);
          if (!existing) acc.push(item);
          return acc;
        }, []),
        lastSync: new Date().toISOString(),
      };

      // Salvar dados mesclados
      if (saveUserData(userId, mergedData)) {
        res.json({
          success: true,
          message: "Dados sincronizados com sucesso",
          timestamp: new Date().toISOString(),
        });
      } else {
        res.status(500).json({ error: "Erro ao salvar dados" });
      }
    } catch (error) {
      console.error("Erro no upload de sincronização:", error);
      res.status(500).json({ error: "Erro ao processar sincronização" });
    }
  });

  // Download de dados (baixar dados do servidor para dispositivo)
  app.get("/api/sync/download", (req, res) => {
    try {
      const userId = req.query.userId as string;

      if (!userId) {
        return res.status(400).json({ error: "userId é obrigatório" });
      }

      const userData = loadUserData(userId);
      res.json({
        success: true,
        data: userData,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error("Erro no download de sincronização:", error);
      res.status(500).json({ error: "Erro ao buscar dados" });
    }
  });

  // Status de sincronização
  app.get("/api/sync/status", (req, res) => {
    try {
      const userId = req.query.userId as string;

      if (!userId) {
        return res.status(400).json({ error: "userId é obrigatório" });
      }

      const userData = loadUserData(userId);
      res.json({
        success: true,
        status: {
          clientesCount: userData.clientes?.length || 0,
          ordensCount: userData.ordens?.length || 0,
          servicosCount: userData.servicos?.length || 0,
          atendimentosCount: userData.atendimentos?.length || 0,
          lastSync: userData.lastSync || null,
        },
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error("Erro ao obter status:", error);
      res.status(500).json({ error: "Erro ao obter status" });
    }
  });

  // ========== SERVIR ARQUIVOS ESTÁTICOS ==========

  // Servir arquivos compilados (funciona em desenvolvimento e produção)
  const staticPath = path.resolve(__dirname, "..", "dist", "public");
  
  // Verificar se os arquivos compilados existem
  if (fs.existsSync(staticPath)) {
    app.use(express.static(staticPath));

    // Handle client-side routing - serve index.html for all routes
    app.get("*", (_req, res) => {
      res.sendFile(path.join(staticPath, "index.html"));
    });
  } else {
    // Se não existem arquivos compilados, retornar erro
    app.get("*", (_req, res) => {
      res.status(500).send(`
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8" />
            <title>Erro</title>
          </head>
          <body>
            <h1>Erro: Arquivos compilados não encontrados</h1>
            <p>Execute: pnpm build</p>
          </body>
        </html>
      `);
    });
  }

  const port = process.env.PORT || 3000;

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
    console.log(`Sync data directory: ${SYNC_DATA_DIR}`);
    if (process.env.NODE_ENV !== "production") {
      console.log(`Dev server: Open http://localhost:5173 in browser or use this server with Vite dev server`);
    }
  });
}

startServer().catch(console.error);
