CREATE TABLE `atendimentos` (
	`id` varchar(255) NOT NULL,
	`user_id` varchar(255) NOT NULL,
	`nome_cliente` varchar(255) NOT NULL,
	`telefone` varchar(20) NOT NULL,
	`whatsapp` varchar(20),
	`bairro` varchar(100),
	`cidade` varchar(100) NOT NULL,
	`origem` enum('whatsapp','indicacao','instagram','facebook','marketplace','google','loja_parceira','grupo_montadores','cliente_antigo','outro') NOT NULL,
	`tipo_servico` varchar(255) NOT NULL,
	`descricao` text NOT NULL,
	`urgencia` enum('baixa','media','alta') DEFAULT 'media',
	`data_preferencial` datetime,
	`valor_estimado` decimal(10,2),
	`observacoes` text,
	`status` enum('novo_contato','aguardando_info','orcamento_enviado','aguardando_confirmacao','agendado','convertido_os','perdido','cancelado') DEFAULT 'novo_contato',
	`data_criacao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`data_conversao` datetime,
	`updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT `atendimentos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `clientes` (
	`id` varchar(255) NOT NULL,
	`user_id` varchar(255) NOT NULL,
	`nome` varchar(255) NOT NULL,
	`telefone` varchar(20),
	`email` varchar(255),
	`endereco` varchar(255),
	`cidade` varchar(100),
	`origem` enum('whatsapp','indicacao','instagram','facebook','marketplace','google','loja_parceira','grupo_montadores','cliente_antigo','outro'),
	`indicado_por` varchar(255),
	`observacoes` text,
	`data_cadastro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT `clientes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ordens` (
	`id` varchar(255) NOT NULL,
	`user_id` varchar(255) NOT NULL,
	`cliente_id` varchar(255) NOT NULL,
	`numero` varchar(50),
	`status` enum('agendada','confirmada','em_andamento','concluida','pendente','cancelada') DEFAULT 'agendada',
	`data_agendamento` datetime NOT NULL,
	`data_criacao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`data_conclusao` datetime,
	`turno` enum('manha','tarde','noite'),
	`observacoes` text,
	`valor_total` decimal(10,2) NOT NULL,
	`valor_extra` decimal(10,2),
	`taxa_deslocamento` decimal(10,2),
	`forma_pagamento` enum('dinheiro','pix','cartao','transferencia','outro') DEFAULT 'dinheiro',
	`status_pagamento` enum('pendente','pago','parcial') DEFAULT 'pendente',
	`descricao_forma_pagamento` text,
	`montador_responsavel` varchar(255),
	`servicos` json,
	`checklist` json,
	`updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT `ordens_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `servicos` (
	`id` varchar(255) NOT NULL,
	`user_id` varchar(255) NOT NULL,
	`nome` varchar(255) NOT NULL,
	`descricao` text,
	`preco` decimal(10,2) NOT NULL,
	`tempo_estimado` int NOT NULL,
	`exige_dupla` boolean DEFAULT false,
	`exige_deslocamento_especial` boolean DEFAULT false,
	`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT `servicos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sync_history` (
	`id` varchar(255) NOT NULL,
	`user_id` varchar(255) NOT NULL,
	`type` enum('upload','download','conflict_resolution') NOT NULL,
	`status` enum('success','failed','pending') NOT NULL,
	`items_count` int NOT NULL,
	`conflicts_resolved` int,
	`resolutions` json,
	`error_message` text,
	`duration` int NOT NULL,
	`timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT `sync_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` varchar(255) NOT NULL,
	`email` varchar(255) NOT NULL,
	`name` varchar(255) NOT NULL,
	`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE INDEX `user_id_idx` ON `atendimentos` (`user_id`);--> statement-breakpoint
CREATE INDEX `user_id_idx` ON `clientes` (`user_id`);--> statement-breakpoint
CREATE INDEX `user_id_idx` ON `ordens` (`user_id`);--> statement-breakpoint
CREATE INDEX `cliente_id_idx` ON `ordens` (`cliente_id`);--> statement-breakpoint
CREATE INDEX `user_id_idx` ON `servicos` (`user_id`);--> statement-breakpoint
CREATE INDEX `user_id_idx` ON `sync_history` (`user_id`);--> statement-breakpoint
CREATE INDEX `timestamp_idx` ON `sync_history` (`timestamp`);--> statement-breakpoint
CREATE INDEX `email_idx` ON `users` (`email`);