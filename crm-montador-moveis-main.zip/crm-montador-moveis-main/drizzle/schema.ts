import { mysqlTable, varchar, text, int, decimal, datetime, mysqlEnum, json, boolean, index } from 'drizzle-orm/mysql-core';
import { relations, sql } from 'drizzle-orm';

// Tabela de Usuários
export const users = mysqlTable('users', {
  id: varchar('id', { length: 255 }).primaryKey(),
  email: varchar('email', { length: 255 }).notNull().unique(),
  name: varchar('name', { length: 255 }).notNull(),
  createdAt: datetime('created_at').default(sql`CURRENT_TIMESTAMP`).notNull(),
}, (table) => ({
  emailIdx: index('email_idx').on(table.email),
}));

// Tabela de Clientes
export const clientes = mysqlTable('clientes', {
  id: varchar('id', { length: 255 }).primaryKey(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  nome: varchar('nome', { length: 255 }).notNull(),
  telefone: varchar('telefone', { length: 20 }),
  email: varchar('email', { length: 255 }),
  endereco: varchar('endereco', { length: 255 }),
  cidade: varchar('cidade', { length: 100 }),
  origem: mysqlEnum('origem', ['whatsapp', 'indicacao', 'instagram', 'facebook', 'marketplace', 'google', 'loja_parceira', 'grupo_montadores', 'cliente_antigo', 'outro']),
  indicadoPor: varchar('indicado_por', { length: 255 }),
  observacoes: text('observacoes'),
  dataCadastro: datetime('data_cadastro').default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: datetime('updated_at').default(sql`CURRENT_TIMESTAMP`).notNull(),
}, (table) => ({
  userIdIdx: index('user_id_idx').on(table.userId),
}));

// Tabela de Serviços
export const servicos = mysqlTable('servicos', {
  id: varchar('id', { length: 255 }).primaryKey(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  nome: varchar('nome', { length: 255 }).notNull(),
  descricao: text('descricao'),
  preco: decimal('preco', { precision: 10, scale: 2 }).notNull(),
  tempoEstimado: int('tempo_estimado').notNull(), // em minutos
  exigeDupla: boolean('exige_dupla').default(false),
  exigeDeslocamentoEspecial: boolean('exige_deslocamento_especial').default(false),
  createdAt: datetime('created_at').default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: datetime('updated_at').default(sql`CURRENT_TIMESTAMP`).notNull(),
}, (table) => ({
  userIdIdx: index('user_id_idx').on(table.userId),
}));

// Tabela de Ordens de Serviço
export const ordens = mysqlTable('ordens', {
  id: varchar('id', { length: 255 }).primaryKey(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  clienteId: varchar('cliente_id', { length: 255 }).notNull(),
  numero: varchar('numero', { length: 50 }),
  status: mysqlEnum('status', ['agendada', 'confirmada', 'em_andamento', 'concluida', 'pendente', 'cancelada']).default('agendada'),
  dataAgendamento: datetime('data_agendamento').notNull(),
  dataCriacao: datetime('data_criacao').default(sql`CURRENT_TIMESTAMP`).notNull(),
  dataConclusao: datetime('data_conclusao'),
  turno: mysqlEnum('turno', ['manha', 'tarde', 'noite']),
  observacoes: text('observacoes'),
  valorTotal: decimal('valor_total', { precision: 10, scale: 2 }).notNull(),
  valorExtra: decimal('valor_extra', { precision: 10, scale: 2 }),
  taxaDeslocamento: decimal('taxa_deslocamento', { precision: 10, scale: 2 }),
  formaPagamento: mysqlEnum('forma_pagamento', ['dinheiro', 'pix', 'cartao', 'transferencia', 'outro']).default('dinheiro'),
  statusPagamento: mysqlEnum('status_pagamento', ['pendente', 'pago', 'parcial']).default('pendente'),
  descricaoFormaPagamento: text('descricao_forma_pagamento'),
  montadorResponsavel: varchar('montador_responsavel', { length: 255 }),
  servicos: json('servicos').$type<Array<{ servico_id: string; quantidade: number; preco_unitario: number }>>(),
  checklist: json('checklist').$type<{
    volumes_completos?: boolean;
    tem_manual?: boolean;
    ferragens_completas?: boolean;
    fixar_parede?: boolean;
    tem_escada?: boolean;
    tem_elevador?: boolean;
    precisa_ajudante?: boolean;
    local_pronto?: boolean;
  }>(),
  updatedAt: datetime('updated_at').default(sql`CURRENT_TIMESTAMP`).notNull(),
}, (table) => ({
  userIdIdx: index('user_id_idx').on(table.userId),
  clienteIdIdx: index('cliente_id_idx').on(table.clienteId),
}));

// Tabela de Atendimentos
export const atendimentos = mysqlTable('atendimentos', {
  id: varchar('id', { length: 255 }).primaryKey(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  nomeCliente: varchar('nome_cliente', { length: 255 }).notNull(),
  telefone: varchar('telefone', { length: 20 }).notNull(),
  whatsapp: varchar('whatsapp', { length: 20 }),
  bairro: varchar('bairro', { length: 100 }),
  cidade: varchar('cidade', { length: 100 }).notNull(),
  origem: mysqlEnum('origem', ['whatsapp', 'indicacao', 'instagram', 'facebook', 'marketplace', 'google', 'loja_parceira', 'grupo_montadores', 'cliente_antigo', 'outro']).notNull(),
  tipoServico: varchar('tipo_servico', { length: 255 }).notNull(),
  descricao: text('descricao').notNull(),
  urgencia: mysqlEnum('urgencia', ['baixa', 'media', 'alta']).default('media'),
  dataPreferencial: datetime('data_preferencial'),
  valorEstimado: decimal('valor_estimado', { precision: 10, scale: 2 }),
  observacoes: text('observacoes'),
  status: mysqlEnum('status', ['novo_contato', 'aguardando_info', 'orcamento_enviado', 'aguardando_confirmacao', 'agendado', 'convertido_os', 'perdido', 'cancelado']).default('novo_contato'),
  dataCriacao: datetime('data_criacao').default(sql`CURRENT_TIMESTAMP`).notNull(),
  dataConversao: datetime('data_conversao'),
  updatedAt: datetime('updated_at').default(sql`CURRENT_TIMESTAMP`).notNull(),
}, (table) => ({
  userIdIdx: index('user_id_idx').on(table.userId),
}));

// Tabela de Histórico de Sincronizações
export const syncHistory = mysqlTable('sync_history', {
  id: varchar('id', { length: 255 }).primaryKey(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  type: mysqlEnum('type', ['upload', 'download', 'conflict_resolution']).notNull(),
  status: mysqlEnum('status', ['success', 'failed', 'pending']).notNull(),
  itemsCount: int('items_count').notNull(),
  conflictsResolved: int('conflicts_resolved'),
  resolutions: json('resolutions').$type<{ [key: string]: 'local' | 'server' }>(),
  errorMessage: text('error_message'),
  duration: int('duration').notNull(), // em ms
  timestamp: datetime('timestamp').default(sql`CURRENT_TIMESTAMP`).notNull(),
}, (table) => ({
  userIdIdx: index('user_id_idx').on(table.userId),
  timestampIdx: index('timestamp_idx').on(table.timestamp),
}));

// Relações
export const clientesRelations = relations(clientes, ({ many }) => ({
  ordens: many(ordens),
}));

export const ordensRelations = relations(ordens, ({ one }) => ({
  cliente: one(clientes, {
    fields: [ordens.clienteId],
    references: [clientes.id],
  }),
}));
