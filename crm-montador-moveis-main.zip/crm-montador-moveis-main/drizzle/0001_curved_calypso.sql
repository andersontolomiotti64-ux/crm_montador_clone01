CREATE TABLE `clientes` (
	`id` varchar(36) NOT NULL,
	`userId` int NOT NULL,
	`nome` varchar(255) NOT NULL,
	`telefone` varchar(20),
	`email` varchar(320),
	`endereco` varchar(255),
	`cidade` varchar(100),
	`dataCadastro` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `clientes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ordemItens` (
	`id` varchar(36) NOT NULL,
	`ordemId` varchar(36) NOT NULL,
	`servicoId` varchar(36) NOT NULL,
	`quantidade` int NOT NULL DEFAULT 1,
	`precoUnitario` decimal(10,2) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ordemItens_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ordens` (
	`id` varchar(36) NOT NULL,
	`userId` int NOT NULL,
	`clienteId` varchar(36) NOT NULL,
	`status` enum('pendente','em_progresso','concluida','cancelada') NOT NULL DEFAULT 'pendente',
	`dataAgendamento` varchar(10),
	`observacoes` text,
	`valorTotal` decimal(10,2) NOT NULL DEFAULT '0',
	`dataCriacao` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ordens_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `passwordResetTokens` (
	`id` varchar(36) NOT NULL,
	`userId` int NOT NULL,
	`token` varchar(255) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`used` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `passwordResetTokens_id` PRIMARY KEY(`id`),
	CONSTRAINT `passwordResetTokens_token_unique` UNIQUE(`token`)
);
--> statement-breakpoint
CREATE TABLE `servicos` (
	`id` varchar(36) NOT NULL,
	`userId` int NOT NULL,
	`nome` varchar(255) NOT NULL,
	`descricao` text,
	`preco` decimal(10,2) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `servicos_id` PRIMARY KEY(`id`)
);
